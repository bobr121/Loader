"""Same-origin HTTP bridge. Start with python server.py; stop with Ctrl+C."""
import json
import threading
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from automation import Panel
from key_jobs import KeyJobs
from emulators import EmulatorFlow
from official_sources import open_official

HERE = Path(__file__).resolve().parent
PORT = 8777
panel = None
key_jobs = None
emulator_flow = None
control_center = None
recovery = None
updates = None


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(HERE / 'app'), **kwargs)

    def log_message(self, *args):
        pass

    def valid_host(self):
        return self.headers.get('Host') in {f'127.0.0.1:{PORT}', f'localhost:{PORT}'}

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' blob:; frame-ancestors 'none'")
        super().end_headers()

    def reply(self, data, code=200, content='application/json; charset=utf-8'):
        body = json.dumps(data, ensure_ascii=False).encode() if isinstance(data, dict) else data
        self.send_response(code)
        self.send_header('Content-Type', content)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if not self.valid_host():
            return self.reply({'error': 'Invalid host'}, 403)
        url = urlparse(self.path)
        if url.path == '/api/ping':
            return self.reply({'ok': True, 'app': 'moyapanel'})
        if url.path == '/api/status':
            data = panel.snapshot()
            data['keyJob'] = key_jobs.snapshot() if key_jobs else None
            data['emulators'] = emulator_flow.snapshot() if emulator_flow else None
            data['controlCenter'] = control_center.snapshot() if control_center else None
            data['recovery'] = recovery.snapshot() if recovery else None
            data['updates'] = updates.snapshot() if updates else None
            return self.reply(data)
        if url.path == '/api/frame':
            serial = parse_qs(url.query).get('serial', [''])[0]
            with panel.lock:
                frame = panel.frames.get(serial)
            return self.reply(frame, content='image/png') if frame else self.reply({'error': 'Кадр ще не готовий'}, 404)
        if url.path not in {'/', '/index.html', '/panel.js', '/panel.css'}:
            return self.reply({'error': 'Not found'}, 404)
        super().do_GET()

    def do_POST(self):
        origin = self.headers.get('Origin')
        if (not self.valid_host() or self.headers.get('X-Panel') != '1'
                or origin not in {None, f'http://127.0.0.1:{PORT}', f'http://localhost:{PORT}' }
                or self.headers.get('Sec-Fetch-Site') == 'cross-site'):
            return self.reply({'error': 'Forbidden'}, 403)
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 <= size <= 65536:
                return self.reply({'error': 'Body too large'}, 413)
            body = json.loads(self.rfile.read(size) or b'{}')
            if not isinstance(body, dict):
                raise ValueError('Expected JSON object')
            action = urlparse(self.path).path.removeprefix('/api/')
            if action == 'update_healthy':
                return self.reply({'ok':bool(updates and updates.mark_healthy())})
            if action == 'update_restart':
                if not updates or not updates.restart_callback: raise ValueError('Потрібне десктопне вікно')
                if not panel.suspended or control_center.snapshot()['stage']!='stopped':
                    raise ValueError('Спочатку повністю припиніть роботу у Центрі керування')
                if updates.snapshot()['stage']!='pending': raise ValueError('Немає підготовленого оновлення')
                updates.restart=True
                threading.Timer(.5,updates.restart_callback).start()
                return self.reply({'ok':True})
            if action == 'recovery_set':
                return self.reply(recovery.set_enabled(body))
            if action == 'center_action':
                return self.reply(control_center.action(body),202)
            if action == 'stop_all':
                return self.reply(control_center.stop_all(),202)
            if action == 'resume_all':
                return self.reply(control_center.resume(),202)
            if panel.suspended and action in {'key_start','launch','emulator_start','emulator_restore'}:
                raise ValueError('Роботу припинено; натисніть Відновити роботу')
            if action == 'emulator_download':
                return self.reply(open_official(body.get('id')))
            if action == 'emulator_path':
                return self.reply(emulator_flow.add_path(body))
            if action == 'emulator_scan':
                return self.reply(emulator_flow.refresh(), 202)
            if action == 'emulator_start':
                return self.reply(emulator_flow.start(body), 202)
            if action == 'emulator_restore':
                return self.reply(emulator_flow.restore(body), 202)
            if action == 'emulator_stop':
                return self.reply(emulator_flow.stop())
            if action == 'key_start':
                with panel.lock:
                    if panel.suspended: raise ValueError('Роботу припинено')
                    result=key_jobs.start(body)
                return self.reply(result, 202)
            if action == 'key_stop':
                return self.reply(key_jobs.stop())
            if action == 'launch':
                panel.enqueue(str(body.get('serial', '')), launch=True)
                return self.reply({'ok': True, 'queued': True}, 202)
            if action not in {'settings', 'config', 'activate', 'account', 'delete_account'}:
                return self.reply({'error': 'Not found'}, 404)
            return self.reply(panel.mutate(action, body))
        except (ValueError, TypeError, ImportError) as e:
            return self.reply({'error': str(e)}, 400)
        except Exception:
            return self.reply({'error': 'Операція не завершена: перевірте доступ до файлів або Credential Manager'}, 500)


def main():
    global panel, key_jobs, emulator_flow, control_center, recovery
    panel = Panel(HERE)
    key_jobs = KeyJobs(HERE)
    emulator_flow = EmulatorFlow(panel)
    from control_center import ControlCenter
    control_center = ControlCenter(panel,emulator_flow,key_jobs)
    from recovery import RecoveryWatchdog
    recovery = RecoveryWatchdog(panel,emulator_flow)
    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    server.daemon_threads = True
    panel.start()
    emulator_flow.refresh()
    recovery.start()
    threading.Timer(0.7, lambda: webbrowser.open(f'http://127.0.0.1:{PORT}')).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        if recovery: recovery.close()
        if control_center: control_center.close()
        emulator_flow.close()
        panel.close()
        key_jobs.close()


if __name__ == '__main__':
    main()
