"""Stable entry point. Do not replace this file in automatic update payloads."""
import json,logging,os,shutil,subprocess,sys,time
from pathlib import Path,PurePosixPath

ROOT=Path(__file__).resolve().parent

def read(path,default=None):return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default

def rollback(root):
    folder=root/'.update';journal=read(folder/'journal.json')
    if not journal:return
    for name,existed in journal['originals'].items():
        if '\\' in name or ':' in name or name.startswith('/') or any(p in {'..','.',''} for p in name.split('/')) or name in {'bootstrap.py','update_config.json'}:raise ValueError('Invalid recovery path')
        target=root/name
        if not target.resolve().is_relative_to(root):raise ValueError('Recovery path outside app')
        if existed:
            tmp=target.with_name(target.name+'.rollback');shutil.copy2(folder/'backup'/name,tmp);os.replace(tmp,target)
        else:target.unlink(missing_ok=True)
    (folder/'active-env.json').write_text(json.dumps(journal['oldEnv']))
    failures=read(folder/'failed.json',[]);(folder/'failed.json').write_text(json.dumps(list(set(failures+[journal['sequence']]))))
    pending=read(folder/'pending.json',{})
    if pending.get('payload',{}).get('sequence')==journal['sequence']:(folder/'pending.json').unlink(missing_ok=True)
    (folder/'journal.json').unlink()

def spawn(python,trial=None,runtime=False):
    command=[str(python),str(ROOT/'bootstrap.py')]
    if trial:command+=['--update-trial',str(trial)]
    if runtime:command+=['--runtime']
    subprocess.Popen(command,cwd=str(ROOT),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))

def main():
    folder=ROOT/'.update';folder.mkdir(exist_ok=True)
    logging.basicConfig(filename=str(ROOT/'desktop.log'),level=logging.ERROR)
    handle=(folder/'app.lock').open('a+b');handle.write(b'0');handle.flush()
    try:
        deadline=time.monotonic()+5
        while True:
            try:
                handle.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic()>=deadline:raise RuntimeError('MoyaPanel вже відкрита у цій папці')
                time.sleep(.1)
        trial=sys.argv[sys.argv.index('--update-trial')+1] if '--update-trial' in sys.argv else None
        journal=read(folder/'journal.json')
        valid_trial=journal and journal.get('phase')=='trial' and str(journal['sequence'])==str(trial)
        if journal and not valid_trial:rollback(ROOT)
        try:
            from updater import UpdateManager
            manager=UpdateManager(ROOT)
            try:applied,sequence=manager.startup(trial)
            except Exception:
                logging.exception('Update preparation failed')
                if read(folder/'journal.json'):raise
                applied=False;sequence=None
            python=manager.environment()
            if not python.is_file():python=Path(sys.executable)
            if applied or python.resolve()!=Path(sys.executable).resolve():
                spawn(python,sequence,runtime=True);return 0
            import desktop
            if desktop.run():spawn(python)
            return 0
        except Exception:
            logging.exception('Application startup failed')
            if read(folder/'journal.json'):
                rollback(ROOT)
                stable=ROOT/'.venv/Scripts/pythonw.exe' if os.name=='nt' else Path(sys.executable)
                spawn(stable);return 0
            raise
    except Exception as error:
        logging.exception('Bootstrap failed')
        if os.name=='nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,str(error)+'\nДеталі: desktop.log','MoyaPanel',0x10)
        return 1
    finally:handle.close()

if __name__=='__main__':sys.exit(main())
