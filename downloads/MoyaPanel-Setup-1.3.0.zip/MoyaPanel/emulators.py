"""Windows installation discovery and explicit emulator -> ADB -> app workflow."""
import copy
import hashlib
import os
import re
import subprocess
import threading
import time
from pathlib import Path
from performance import MuMuTuner, host_budget, tune_android, restore_android
from vendor_adapters import LDPlayerTuner, MEmuTuner, NoxTuner, capabilities
from official_sources import catalogue

PLAYERS = {'mumunxmain.exe': 'MuMu Player', 'mumuplayer.exe': 'MuMu Player', 'nemuplayer.exe': 'MuMu Player',
           'hd-player.exe': 'BlueStacks', 'dnplayer.exe': 'LDPlayer',
           'ldplayer.exe': 'LDPlayer', 'nox.exe': 'Nox', 'memu.exe': 'MEmu'}
NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def installation(executable):
    path = Path(executable).resolve()
    name = PLAYERS.get(path.name.lower())
    if not name or not path.is_file():
        return None
    root = path.parent.parent if path.parent.name.lower() in {'shell', 'nx_main', 'bin'} else path.parent
    return {'id': hashlib.sha256(str(path).lower().encode()).hexdigest()[:20],
            'name': name, 'path': str(path), 'root': str(root)}


def registry_roots():
    if os.name != 'nt':
        return []
    import winreg
    roots = []
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for flag in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
            try:
                with winreg.OpenKey(hive, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 0,
                                    winreg.KEY_READ | flag) as parent:
                    for index in range(winreg.QueryInfoKey(parent)[0]):
                        try:
                            with winreg.OpenKey(parent, winreg.EnumKey(parent, index)) as key:
                                name = str(winreg.QueryValueEx(key, 'DisplayName')[0])
                                if not re.search(r'mumu|nemu|bluestacks|ldplayer|nox|memu', name, re.I):
                                    continue
                                for field in ('InstallLocation', 'DisplayIcon', 'UninstallString'):
                                    try:
                                        value = os.path.expandvars(str(winreg.QueryValueEx(key, field)[0]))
                                        if value.startswith('"'):
                                            value = value.split('"')[1]
                                        elif '.exe' in value.lower():
                                            value = value[:value.lower().index('.exe')+4]
                                        p = Path(value)
                                        roots.append(p.parent if p.suffix.lower() == '.exe' else p)
                                    except OSError:
                                        pass
                        except OSError:
                            pass
            except OSError:
                pass
    return roots


def discover(on_found=None, budget_seconds=8):
    """Probe known layouts rather than recursively walking emulator data/VM folders."""
    try:
        import psutil
    except ImportError as e:
        raise RuntimeError('Потрібна залежність psutil. Запустіть Install.bat.') from e
    deadline=time.monotonic()+budget_seconds
    found={}
    def accept(path):
        if not Path(path).is_file(): return
        item=installation(path)
        if item and item['id'] not in found:
            found[item['id']]=item
            if on_found: on_found(copy.deepcopy(item))
    # Running processes are the fastest and strongest installation-location hint.
    for process in psutil.process_iter(['name','exe']):
        if time.monotonic()>=deadline: break
        try:
            path=process.info.get('exe')
            if path and Path(path).name.lower() in PLAYERS: accept(path)
        except (psutil.Error,OSError): pass
    roots=registry_roots()
    suffixes=('Netease/MuMuPlayer','Netease/MuMu','Netease/MuMuPlayerGlobal-12.0',
              'MuMuPlayerGlobal-12.0','MuMuPlayer-12.0','MuMuPlayer','MuMu Player 12','MuMu',
              'Nemu','BlueStacks_nxt','BlueStacks','LDPlayer/LDPlayer9','LDPlayer','Nox','Microvirt/MEmu')
    for base in filter(None,(os.environ.get('ProgramFiles'),os.environ.get('ProgramW6432'),
                            os.environ.get('ProgramFiles(x86)'),os.environ.get('LOCALAPPDATA'))):
        roots.extend(Path(base)/suffix for suffix in suffixes)
    for drive in ('C:/','D:/','E:/','F:/'):
        roots.extend(Path(drive)/suffix for suffix in suffixes)
    seen=set();count=0
    for root in roots:
        if time.monotonic()>=deadline: break
        if str(root).startswith('\\\\'): continue  # Do not probe network shares.
        folders=[root,root/'shell',root/'nx_main',root/'bin']
        for folder in folders:
            if time.monotonic()>=deadline or count>=240: break
            normalized=str(folder).lower()
            if normalized in seen: continue
            seen.add(normalized)
            if not folder.is_dir(): continue
            count+=1
            # A fixed list of file probes avoids expensive directory enumeration of VM trees.
            for name in PLAYERS:
                if time.monotonic()>=deadline: break
                try: accept(folder/name)
                except OSError: pass
    return sorted(found.values(),key=lambda item:(item['name'],item['path']))


def owned_ports(item):
    import psutil
    root_path=Path(item['root'])
    folders=[root_path]
    if item['name']=='MEmu':
        folders.extend([root_path.parent/'MEmuHyperv',root_path/'MEmuHyperv'])
    if item['name']=='MuMu Player':
        folders.extend([root_path.parent/'MuMuVMM',root_path/'MuMuVMM'])
    roots=[os.path.normcase(os.path.realpath(p)) for p in folders if p.is_dir()]
    pids = set()
    for process in psutil.process_iter(['pid', 'exe']):
        try:
            exe = process.info['exe']
            if exe and any(os.path.commonpath([root,os.path.normcase(os.path.realpath(exe))])==root for root in roots):
                pids.add(process.info['pid'])
        except (psutil.Error, OSError, ValueError):
            pass
    ports = set()
    for connection in psutil.net_connections(kind='tcp'):
        if (connection.pid in pids and connection.status == psutil.CONN_LISTEN and connection.laddr
                and connection.laddr.ip in {'127.0.0.1', '0.0.0.0', '::', '::1'}
                and 1024 <= connection.laddr.port <= 65535 and connection.laddr.port != 5037):
            ports.add(connection.laddr.port)
    return sorted(ports)


def serial_port(serial):
    if re.fullmatch(r'emulator-\d+', serial):
        return int(serial.split('-')[1])+1
    if re.fullmatch(r'(127\.0\.0\.1|localhost):\d+', serial):
        return int(serial.rsplit(':', 1)[1])
    return None


def selected_devices(raw, ports):
    by_port = {}
    for line in raw.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[1] == 'device':
            port = serial_port(parts[0])
            if port in ports:
                # A TCP alias and emulator-N may refer to the same Android session.
                by_port.setdefault(port, parts[0])
    return list(by_port.values())


def make_tuner(item,directory):
    adapter={'MuMu Player':MuMuTuner,'LDPlayer':LDPlayerTuner,'MEmu':MEmuTuner,'Nox':NoxTuner}.get(item['name'],MuMuTuner)
    return adapter(item,directory)


class EmulatorFlow:
    def __init__(self, panel, detector=discover, port_reader=owned_ports, launcher=subprocess.Popen):
        self.panel = panel
        self.detector = detector
        self.port_reader = port_reader
        self.launcher = launcher
        from managed_resources import ManagedResources
        self.managed = ManagedResources()
        self.closing_all = False
        self.generation = 0
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None
        self.items = []
        self.state = {'running': False, 'stage': 'idle', 'detail': '', 'serials': [], 'profile': None, 'tuning': [], 'sessionKeys': {}}

    def snapshot(self):
        with self.lock:
            return {'installed': copy.deepcopy(self.items), 'workflow': copy.deepcopy(self.state),
                    'selected': self.panel.data.get('emulator', ''),'officialSources':catalogue(), 'managed':self.managed.snapshot()}

    def stage(self, name, detail):
        with self.lock:
            self.state.update(stage=name, detail=detail)

    def key_state(self, serial, account_id, stage, detail, **extra):
        with self.lock:
            self.state.setdefault('sessionKeys', {})[serial] = dict(
                self.state.get('sessionKeys', {}).get(serial, {}),
                serial=serial, accountId=account_id, stage=stage, detail=detail, **extra)
        self.stage('session_key', serial + ': ' + detail)

    def refresh(self):
        self._begin(self._refresh,allow_paused=True)
        return {'ok': True}

    def _refresh(self):
        self.stage('discovering', 'Шукаю емулятори в реєстрі, стандартних папках і запущених процесах…')
        def partial(item):
            item['capabilities']=capabilities(item)
            with self.lock:
                if not any(v['id']==item['id'] for v in self.items): self.items.append(item)
            self.stage('discovering','Знайдено емуляторів: '+str(len(self.items))+'. Завершую швидкий пошук…')
        items = discover(on_found=partial) if self.detector is discover else self.detector()
        with self.panel.lock:
            manual=list(self.panel.data.get('manualEmulators',[]))
        for path in manual:
            item=installation(path)
            if item and not any(v['id']==item['id'] for v in items): items.append(item)
        for item in items:
            item['capabilities']=capabilities(item)
        with self.lock:
            self.items = items
        self.stage('choose_emulator' if items else 'not_found',
                   'Виберіть емулятор і натисніть «Запустити та оптимізувати».' if items else
                   'Швидкий пошук не знайшов емулятор. Запустіть MuMu й повторіть пошук або вкажіть шлях до його exe вручну нижче.')

    def add_path(self,body):
        raw=str(body.get('path','')).strip().strip('"')
        if not raw or len(raw)>2048 or raw.startswith('\\\\'):
            raise ValueError('Вкажіть локальний шлях до exe емулятора')
        item=installation(raw)
        if item is None: raise ValueError('Файл не знайдено або це не підтримуваний exe емулятора')
        item['capabilities']=capabilities(item)
        with self.lock:
            if self.state['running']: raise ValueError('Дочекайтеся завершення поточної операції')
            self.items=[v for v in self.items if v['id']!=item['id']]+[item]
        with self.panel.lock:
            paths=self.panel.data.setdefault('manualEmulators',[])
            if item['path'] not in paths: paths.append(item['path'])
            self.panel.data['emulator']=item['id']
            self.panel.save()
        self.stage('choose_emulator','Емулятор додано: '+item['path'])
        return {'ok':True}

    def _begin(self, operation, reset=True, allow_paused=False):
        with self.lock:
            if self.closing_all or (self.panel.suspended and not allow_paused):
                raise ValueError('Роботу припинено; використайте Відновити роботу')
            if self.state['running']:
                raise ValueError('Операція вже виконується')
            self.stop_event.clear()
            self.state.update(running=True, detail='')
            if reset:
                self.state.update(serials=[], sessionKeys={})
            self.thread = threading.Thread(target=self._run, args=(operation,), daemon=True)
            self.thread.start()

    def _run(self, operation):
        try:
            operation()
        except Exception as e:
            self.stage('error', str(e)[:800])
        finally:
            with self.lock:
                if self.stop_event.is_set():
                    self.state.update(stage='stopped', detail='Сценарій зупинено. Вікна емулятора залишаються відкритими.')
                self.state['running'] = False

    def start(self, body):
        with self.lock:
            item = next((copy.deepcopy(x) for x in self.items if x['id'] == body.get('id')), None)
        if item is None:
            raise ValueError('Спочатку виберіть знайдений емулятор')
        from automation import PACKAGE
        package = str(body.get('package') or '').strip()
        if package and not PACKAGE.fullmatch(package):
            raise ValueError('Некоректна назва Android package')
        setup = bool(body.get('setupDelta', False))
        if setup and package and package != 'com.roblox.client':
            raise ValueError('Підготовка Delta сумісна лише з com.roblox.client')
        if setup:
            with self.panel.lock:
                if not any(a['enabled'] for a in self.panel.data['accounts']):
                    raise ValueError('Додайте увімкнені акаунти та їхні режими перед запуском Delta')
        auto_keys = bool(body.get('autoKeys', False))
        if auto_keys and not setup:
            raise ValueError('Етап ключа працює разом зі сценарієм Delta')
        run_script = bool(body.get('runScript', False))
        if run_script and not auto_keys:
            raise ValueError('Запуск скрипта потребує етапу підтвердження ключа')
        options = {'id':item['id'], 'package':package, 'optimize':bool(body.get('optimize',True)), 'setupDelta':setup, 'autoKeys':auto_keys, 'runScript':run_script}
        def launch():
            with self.panel.lock:
                self.panel.data['lastRun'] = options
                self.panel.save()
            with self.lock: self.generation += 1
            self.workflow(item, package, options['optimize'], setup, auto_keys, run_script)
        self._begin(launch)
        return {'ok': True}

    def restore(self,body):
        with self.lock:
            item=next((copy.deepcopy(x) for x in self.items if x['id']==body.get('id')),None)
        if item is None:
            raise ValueError('Виберіть емулятор')
        self._begin(lambda:self._restore(item))
        return {'ok':True}

    def _restore(self,item):
        self.stage('restoring','Відновлюю збережені налаштування. Інстанси вибраного емулятора можуть перезапуститися…')
        raw=self.panel.adb('devices','-l').decode('utf-8','replace')
        serials=selected_devices(raw,self.port_reader(item))
        restored=[]
        for serial in serials:
            if restore_android(self.panel,serial,self.panel.path.parent,item['id']):
                restored.append(serial)
        tuner=make_tuner(item,self.panel.path.parent)
        if tuner.manager:
            restored.extend(map(str,tuner.restore(self.stop_event)))
        if not restored:
            raise RuntimeError('Немає доступних резервних копій для відновлення')
        self.stage('restored','Попередні налаштування відновлено: '+', '.join(restored))

    def workflow(self, item, package, optimize=True, setup_delta=False, auto_keys=False, run_script=False):
        with self.panel.lock:
            script_config = copy.deepcopy(next(c for c in self.panel.data['configs'] if c['id'] == self.panel.data['active']))
            self.panel.allowed_serials = set()
            self.panel.data['emulator'] = item['id']
            self.panel.save()
        selected_indices=None
        tuner=None
        process=None
        if optimize:
            self.stage('analyzing_pc','Аналізую CPU, RAM, GPU та поточне навантаження цього ПК…')
            profile=host_budget()
            tuner=make_tuner(item,self.panel.path.parent)
            if tuner.manager:
                profile=tuner.profile_for_host(profile)
            with self.lock:
                self.state.update(profile=profile,tuning=[])
            if profile['estimatedInstances']<1:
                raise RuntimeError('За консервативною оцінкою бракує RAM для інстанса з резервом. Автозапуск скасовано.')
            self.stage('optimizing','Профіль '+profile.get('tier','Авто')+': '+str(profile['cores'])+' vCPU, '+str(profile['guestGB'])+' ГБ, ціль '+str(profile['fps'])+' FPS…')
            if tuner.manager:
                instances=tuner.instances()
                if sum(x['running'] for x in instances)>profile['estimatedInstances']:
                    raise RuntimeError('Зараз запущено більше інстансів, ніж консервативний бюджет '+str(profile['estimatedInstances'])+'. Додаткові не запускаються; чужі сесії не закривалися.')
                limit = profile['estimatedInstances']
                if setup_delta:
                    with self.panel.lock:
                        limit = min(limit, sum(a['enabled'] for a in self.panel.data['accounts']))
                picked=sorted(instances,key=lambda x:(not x['running'],x['index']))[:limit]
                selected_indices=set()
                for instance in picked:
                    if selected_indices and not instance['running']:
                        self.stage('checking_load','Перевіряю навантаження перед наступним інстансом (15 секунд)…')
                        from load_guard import can_add_instance
                        if not can_add_instance(profile['guestGB'], self.stop_event):
                            with self.lock:
                                self.state['tuning'].append('Ліміт запуску: навантаження або резерв RAM; наступні інстанси залишено вимкненими.')
                            break
                    if self.stop_event.is_set():
                        return
                    self.stage('optimizing','Налаштовую '+item['name']+' #'+str(instance['index'])+'; за потреби перезапускаю…')
                    if not instance['running']:
                        self.managed.native_launch(item,tuner,instance['index'])
                    tuner.apply(instance,profile,self.stop_event)
                    tuner.wait_ready(instance['index'],self.stop_event)
                    selected_indices.add(instance['index'])
                    with self.lock:
                        self.state['tuning'].append(item['name']+' #'+str(instance['index'])+': '+','.join(tuner.native_fields)+' підтверджено; '+('FPS керується окремо виробником' if 'FPS' not in tuner.native_fields else ''))
            else:
                with self.lock:
                    self.state['tuning'].append('Частковий профіль: CPU/RAM/FPS не змінені — немає сумісного адаптера/CLI цієї версії.')
        if not tuner:
            candidate=make_tuner(item,self.panel.path.parent)
            if candidate.manager:
                entries=candidate.instances()
                running=[v for v in entries if v['running']]
                chosen=running or entries[:1]
                tuner=candidate
                selected_indices={v['index'] for v in chosen}
                for instance in chosen:
                    if not instance['running']:
                        self.managed.native_launch(item,tuner,instance['index'])
                        tuner.start_instance(instance['index'])
                        tuner.wait_ready(instance['index'],self.stop_event)
        if (not tuner or not tuner.manager) and not self.port_reader(item):
            if optimize and host_budget()['availableGB']<profile['guestGB']+2 and not self.port_reader(item):
                raise RuntimeError('Бракує вільної RAM з резервом 2 ГБ; запуск емулятора призупинено.')
            self.stage('launching_emulator','Запускаю '+item['name']+'…')
            process=self.launcher([item['path']],cwd=str(Path(item['path']).parent),
                                  stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL,creationflags=NO_WINDOW,shell=False)
            self.managed.process_launch(process)
        # Keep the Popen object until the workflow finishes; do not terminate the user's emulator.
        self.stage('waiting_adb', 'Очікую Android/ADB. Перша загрузка може тривати до 3 хвилин…')
        deadline = time.monotonic()+180
        attempted = {}
        serials = []
        last_error = ''
        while time.monotonic() < deadline and not self.stop_event.is_set():
            ports = self.port_reader(item)
            if tuner and tuner.manager and selected_indices is not None:
                entries=tuner.instances()
                mapped=[x['port'] for x in entries if x['index'] in selected_indices and x['port']]
                if mapped:
                    ports=[p for p in ports if p in mapped]
                elif len(selected_indices)!=len(entries):
                    raise RuntimeError('Не вдалося зіставити порти оптимізованих інстансів')
            # Only ports owned by processes inside the chosen emulator installation are eligible.
            for port in ports:
                if self.stop_event.is_set():
                    return
                if time.monotonic()-attempted.get(port, 0) < 20:
                    continue
                attempted[port] = time.monotonic()
                try:
                    self.panel.adb('connect', '127.0.0.1:'+str(port), timeout=1)
                except (OSError, RuntimeError, subprocess.TimeoutExpired):
                    pass
            try:
                raw = self.panel.adb('devices', '-l').decode('utf-8', 'replace')
                connected = selected_devices(raw, ports)
                serials = [s for s in connected if self.panel.adb('shell', 'getprop', 'sys.boot_completed', serial=s).strip() == b'1']
                if serials:
                    break
            except (OSError, RuntimeError, subprocess.TimeoutExpired) as e:
                last_error = str(e)
            self.stop_event.wait(3)
        if self.stop_event.is_set():
            return
        if optimize:
            serials=serials[:profile['estimatedInstances']]
        if not serials:
            raise RuntimeError('Не вдалося зіставити ADB із вибраним емулятором. Увімкніть у ньому ADB; '
                               'перевірте доступ до списку процесів/портів. Інші емулятори не використовувалися. '+last_error[:200])
        with self.lock:
            self.state['serials'] = serials
        with self.panel.lock:
            self.panel.allowed_serials = set(serials)
        if setup_delta and tuner and tuner.manager:
            entries=tuner.instances()
            live={str(entry['index']):next((s for s in serials if serial_port(s)==entry.get('port')),None) for entry in entries}
            with self.panel.lock:
                for account in self.panel.data['accounts']:
                    if account.get('emulatorId')==item['id'] and str(account.get('instanceIndex')) in live:
                        mapped=live[str(account['instanceIndex'])]
                        if mapped and not any(a['id']!=account['id'] and a['serial']==mapped for a in self.panel.data['accounts']):
                            account['serial']=mapped
        if setup_delta:
            with self.panel.lock:
                bound_serials = {a['serial'] for a in self.panel.data['accounts'] if a['serial']}
                unassigned = iter(a for a in self.panel.data['accounts'] if a['enabled'] and not a['serial'])
                for serial in serials:
                    if serial not in bound_serials:
                        account = next(unassigned, None)
                        if account:
                            account['serial'] = serial
                            bound_serials.add(serial)
                if tuner and tuner.manager:
                    for account in self.panel.data['accounts']:
                        matched=next((v for v in entries if serial_port(account['serial'])==v.get('port') and account['serial'] in serials),None)
                        if matched:
                            account.update(emulatorId=item['id'],instanceIndex=matched['index'])
                self.panel.save()
        apk = None
        if setup_delta:
            from android_setup import download_delta
            apk = download_delta(self.panel.path.parent, self.stop_event, self.stage)
        pending = []
        self.stage('launching_app', 'Відкриваю додаток у '+str(len(serials))+' сесіях вибраного емулятора…')
        for serial in serials:
            if self.stop_event.is_set():
                return
            actual = package
            if setup_delta:
                from android_setup import install_delta
                install_delta(self.panel, serial, apk, self.stage)
                actual = 'com.roblox.client'
            if not actual:
                packages = self.panel.adb('shell', 'pm', 'list', 'packages', serial=serial).decode('utf-8', 'replace')
                matches = [line[8:].strip() for line in packages.splitlines()
                           if line.startswith('package:') and 'roblox' in line.lower()]
                if 'com.roblox.client' in matches:
                    actual = 'com.roblox.client'
                elif len(matches) == 1:
                    actual = matches[0]
                else:
                    raise RuntimeError('Roblox не знайдено однозначно в '+serial+'. Встановіть додаток або вкажіть його Android package.')
            if optimize:
                self.stage('optimizing_android','Зменшую навантаження Android у '+serial+'…')
                try:
                    tune_android(self.panel,serial,self.panel.path.parent,item['id'],profile=profile)
                except Exception:
                    restore_android(self.panel,serial,self.panel.path.parent,item['id'])
                    raise
                with self.lock:
                    self.state['tuning'].append(serial+': '+profile['resolution']+', DPI '+str(profile.get('density',160))+', анімації вимкнено')
            self.stage('launching_app','Запускаю '+actual+' у '+serial+'…')
            self.panel.launch_package(serial, actual)
            with self.panel.lock:
                cfg = next(c for c in self.panel.data['configs'] if c['id'] == self.panel.data['active'])
                cfg['package'] = actual
                self.panel.save()
            self.panel.event(serial, 'workflow_app_started', item['name']+': '+actual)
            if setup_delta:
                with self.panel.lock:
                    bound = [copy.deepcopy(a) for a in self.panel.data['accounts'] if a['serial'] == serial and a['enabled']]
                if len(bound) != 1:
                    pending.append(serial + ': прив’яжіть один увімкнений акаунт у вкладці Акаунти')
                    continue
                from android_setup import prepare_account
                try:
                    result = prepare_account(self.panel, serial, bound[0], self.stop_event, self.stage)
                    if result == 'cancelled':
                        return
                    if auto_keys:
                        from session_keys import SessionKeys
                        key_result = SessionKeys(self.panel, self.key_state).run(serial, bound[0], self.stop_event)
                        if key_result == 'stopped':
                            return
                        if key_result == 'needs_attention':
                            pending.append(serial + ': етап ключа потребує уваги; дивіться статус сесії')
                        elif run_script:
                            from script_step import ScriptStep
                            with self.panel.lock:
                                chosen_config = copy.deepcopy(next((c for c in self.panel.data['configs'] if c['id'] == bound[0].get('configId')), script_config))
                            script_result = ScriptStep(self.panel, self.key_state).run(serial, bound[0], chosen_config, self.stop_event)
                            if script_result == 'stopped':
                                return
                            if script_result == 'needs_attention':
                                pending.append(serial + ': перевірте налаштування/редактор скрипта')
                except Exception:
                    # Do not expose RPC exceptions: they may contain typed text.
                    pending.append(serial + ': вхід не підтверджено; перевірте прев’ю та збережений пароль')
                    self.panel.event(serial, 'login_pending', 'Вхід не підтверджено; деталі RPC приховані')
        self.stage('monitoring', 'Додаток запущений. Моніторинг активний. Вхід у гру, ключ і Lua автоматично не виконуються.')
        if setup_delta:
            self.stage('needs_attention' if pending else 'awaiting_game', '; '.join(pending) if pending else 'Акаунти видимі у UI; посилання вибраних режимів надіслані. Фактичне завантаження гри перевірте у прев’ю.')
        if setup_delta and auto_keys and not pending:
            self.stage('keys_ready', 'Етап ключа завершено для вибраних сесій. Подальших дій немає.')
        if setup_delta and auto_keys and run_script and not pending:
            self.stage('script_stage_complete', 'Етап скрипта завершено: Execute надіслано або пропущено через автоінжект. Результат виконання перевірте у прев’ю.')
        # Polling is subsequently owned by Panel; this launch workflow is complete.
        if process:
            process.poll()

    def stop(self):
        self.stop_event.set()
        return {'ok': True}

    def close(self):
        with self.lock: self.closing_all=True
        self.stop()
        if self.thread:
            self.thread.join(timeout=15)
