import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from automation import Panel
from emulators import EmulatorFlow, installation, selected_devices, serial_port
from test_panel import FakeADB, SERIAL


class EmulatorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.adb=FakeADB()
        self.panel=Panel(self.temp.name,self.adb)
        player=Path(self.temp.name)/'vendor/shell/MuMuPlayer.exe'
        player.parent.mkdir(parents=True)
        player.write_bytes(b'fake executable for discovery only')
        self.item=installation(player)
        self.launcher=Mock(return_value=Mock(poll=Mock(return_value=0)))
        self.flow=EmulatorFlow(self.panel,detector=lambda:[self.item],port_reader=lambda item:[16384],launcher=self.launcher)
        self.flow.items=[self.item]

    def tearDown(self):
        self.flow.close()
        self.panel.close()
        self.temp.cleanup()

    def test_installation_and_vendor_root(self):
        self.assertEqual(self.item['name'],'MuMu Player')
        self.assertEqual(Path(self.item['root']).name,'vendor')
        self.assertIsNone(installation(Path(self.temp.name)/'random.exe'))

    def test_serial_alias_mapping_and_other_emulator_exclusion(self):
        raw='emulator-5554 device\n127.0.0.1:5555 device\n127.0.0.1:16384 device\nphone device\n'
        self.assertEqual(selected_devices(raw,[5555]),['emulator-5554'])
        self.assertEqual(serial_port('emulator-5554'),5555)
        self.assertEqual(selected_devices(raw,[8888]),[])

    def test_workflow_launches_selected_player_and_app(self):
        self.flow.start({'id':self.item['id'],'package':'com.example.game','optimize':False})
        self.flow.thread.join(3)
        state=self.flow.snapshot()['workflow']
        self.assertFalse(state['running'])
        self.assertEqual(state['stage'],'monitoring',state)
        self.assertEqual(state['serials'],[SERIAL])
        self.assertEqual(self.panel.allowed_serials,{SERIAL})
        self.launcher.assert_not_called()  # Existing owned ADB ports: reuse the already open player.
        self.assertTrue(any('start' in c for c in self.adb.calls))

    def test_roblox_autodetection(self):
        base=self.adb
        def runner(cmd,**kwargs):
            import subprocess
            if cmd[-4:]==['shell','pm','list','packages']:
                return subprocess.CompletedProcess(cmd,0,b'package:com.example.game\n',b'')
            return base(cmd,**kwargs)
        self.panel.runner=runner
        self.flow.start({'id':self.item['id'],'optimize':False})
        self.flow.thread.join(3)
        self.assertEqual(self.flow.snapshot()['workflow']['stage'],'error')
        self.assertFalse(any('start' in c for c in self.adb.calls))

    def test_scan_returns_choices(self):
        self.flow.refresh()
        self.flow.thread.join(3)
        state=self.flow.snapshot()
        self.assertEqual(state['installed'][0]['id'],self.item['id'])
        self.assertEqual(state['workflow']['stage'],'choose_emulator')

    def test_one_click_native_tuning_then_app(self):
        profile={'estimatedInstances':2,'cores':2,'guestGB':3,'fps':30,'resolution':'960x540'}
        tuner=Mock(manager=True)
        tuner.native_fields=('CPU','RAM','FPS')
        tuner.profile_for_host.return_value=profile
        tuner.instances.return_value=[{'index':0,'running':False,'ready':True,'port':16384}]
        with patch('emulators.host_budget',return_value=profile),patch('emulators.make_tuner',return_value=tuner),patch('emulators.tune_android') as android:
            self.flow.start({'id':self.item['id'],'package':'com.example.game'})
            self.flow.thread.join(3)
        self.assertEqual(self.flow.snapshot()['workflow']['stage'],'monitoring')
        tuner.apply.assert_called_once()
        tuner.wait_ready.assert_called_once()
        android.assert_called_once()
        self.launcher.assert_not_called()

    def test_no_emulator_offers_only_official_catalogue(self):
        self.flow.detector=lambda:[]
        self.flow.refresh()
        self.flow.thread.join(3)
        result=self.flow.snapshot()
        self.assertEqual(result['workflow']['stage'],'not_found')
        self.assertEqual(len(result['officialSources']),5)
        self.assertTrue(all(item['url'].startswith('https://'+item['domain']+'/') for item in result['officialSources']))

    def test_delta_setup_assigns_account_installs_and_prepares(self):
        self.panel.mutate('account', {'login':'Player', 'serial':'', 'placeId':'123'})
        with patch('android_setup.download_delta',return_value=Path('download.apk')) as download, patch('android_setup.install_delta') as install, patch('android_setup.prepare_account',return_value='account_visible') as prepare, patch.object(self.panel,'launch_package') as launch:
            self.flow.start({'id':self.item['id'],'setupDelta':True,'optimize':False})
            self.flow.thread.join(3)
        state=self.flow.snapshot()['workflow']
        self.assertEqual(state['stage'],'awaiting_game',state)
        download.assert_called_once()
        install.assert_called_once()
        launch.assert_called_once_with(SERIAL,'com.roblox.client')
        self.assertEqual(prepare.call_args.args[2]['login'],'Player')
        self.assertEqual(prepare.call_args.args[2]['placeId'],'123')
        self.assertEqual(self.panel.data['accounts'][0]['serial'],SERIAL)

    def test_delta_runs_bound_key_stage_after_account(self):
        self.panel.mutate('account', {'login':'Player', 'serial':'', 'placeId':'123'})
        keys=Mock()
        keys.run.return_value='accepted'
        with patch('android_setup.download_delta',return_value=Path('download.apk')), patch('android_setup.install_delta'), patch('android_setup.prepare_account',return_value='account_visible'), patch.object(self.panel,'launch_package'), patch('session_keys.SessionKeys',return_value=keys):
            self.flow.start({'id':self.item['id'],'setupDelta':True,'autoKeys':True,'optimize':False})
            self.flow.thread.join(3)
        self.assertEqual(self.flow.snapshot()['workflow']['stage'],'keys_ready')
        self.assertEqual(keys.run.call_args.args[0],SERIAL)
        self.assertEqual(keys.run.call_args.args[1]['login'],'Player')

    def test_execute_stage_runs_only_after_key_access(self):
        self.panel.mutate('account', {'login':'Player', 'serial':'', 'placeId':'123'})
        keys=Mock();script=Mock()
        keys.run.return_value='accepted';script.run.return_value='execute_sent'
        with patch('android_setup.download_delta',return_value=Path('download.apk')), patch('android_setup.install_delta'), patch('android_setup.prepare_account',return_value='account_visible'), patch.object(self.panel,'launch_package'), patch('session_keys.SessionKeys',return_value=keys), patch('script_step.ScriptStep',return_value=script):
            self.flow.start({'id':self.item['id'],'setupDelta':True,'autoKeys':True,'runScript':True,'optimize':False})
            self.flow.thread.join(3)
        self.assertEqual(self.flow.snapshot()['workflow']['stage'],'script_stage_complete')
        script.run.assert_called_once()
        self.assertEqual(script.run.call_args.args[0],SERIAL)

    def test_delta_requires_accounts_before_starting(self):
        with self.assertRaises(ValueError):
            self.flow.start({'id':self.item['id'],'setupDelta':True})
        self.launcher.assert_not_called()

    def test_reject_unknown_selection(self):
        with self.assertRaises(ValueError):
            self.flow.start({'id':'not installed'})
        self.launcher.assert_not_called()

