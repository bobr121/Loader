import json
import tempfile
import unittest
from unittest.mock import patch
from urllib.request import urlopen
from pathlib import Path
import desktop
import server


class DesktopTests(unittest.TestCase):
    def test_native_window_uses_own_server_and_closes_workers(self):
        with tempfile.TemporaryDirectory() as temp:
            old_port=server.PORT
            record={}
            class FakeWebview:
                @staticmethod
                def create_window(title,url,**options):
                    record['url']=url
                    record['options']=options
                    with urlopen(url+'/api/status') as response:
                        record['state']=json.load(response)
                    with urlopen(url) as response:
                        record['html']=response.read().decode()
                @staticmethod
                def start(**options):
                    record['start']=options
            try:
                with patch.object(desktop,'HERE',Path(temp)),patch('automation.Panel.start'),patch('webbrowser.open') as browser:
                    desktop.run(FakeWebview)
                    browser.assert_not_called()
                self.assertTrue(record['url'].startswith('http://127.0.0.1:'))
                self.assertIn('keyJob',record['state'])
                self.assertEqual(record['start']['gui'],'edgechromium')
                self.assertTrue(server.panel.halt.is_set())
            finally:
                server.PORT=old_port

    def test_cleanup_on_window_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            old_port=server.PORT
            class FailingWebview:
                @staticmethod
                def create_window(*args,**kwargs):
                    raise RuntimeError('No WebView2')
            try:
                with patch.object(desktop,'HERE',Path(temp)),patch('automation.Panel.start'):
                    with self.assertRaises(RuntimeError):
                        desktop.run(FailingWebview)
                self.assertTrue(server.panel.halt.is_set())
            finally:
                server.PORT=old_port
