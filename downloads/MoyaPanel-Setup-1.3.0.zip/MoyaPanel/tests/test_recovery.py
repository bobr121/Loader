import copy
import tempfile
import time
import unittest
from unittest.mock import Mock,patch
from automation import Panel
from emulators import EmulatorFlow
from recovery import RecoveryWatchdog, ui_problem
from test_panel import SERIAL

ITEM={'id':'mumu','name':'MuMu Player','path':'/fake/MuMuPlayer.exe','root':'/fake'}

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.panel=Panel(self.temp.name)
        self.panel.mutate('account',{'login':'Player','serial':SERIAL,'placeId':'123'})
        self.account=self.panel.data['accounts'][0]
        self.account.update(emulatorId='mumu',instanceIndex=0)
        self.panel.allowed_serials={SERIAL};self.panel.controlled_apps[SERIAL]='com.roblox.client'
        self.panel.data['lastRun']={'id':'mumu','setupDelta':True,'autoKeys':True,'runScript':True}
        self.flow=EmulatorFlow(self.panel,port_reader=lambda item:[16384,5555]);self.flow.items=[ITEM]
        self.now=100.;self.probe=Mock(return_value=None)
        self.watch=RecoveryWatchdog(self.panel,self.flow,clock=lambda:self.now,probe=self.probe)
        self.flow._begin=Mock()
    def tearDown(self):
        self.watch.close();self.flow.close();self.panel.close();self.temp.cleanup()
    def device(self,process='running'):
        return {'state':'device','process':process,'checked':int(time.time()*1000)}
    def polls(self,n=3):
        for _ in range(n): self.watch.tick();self.now+=5

    def test_three_misses_required_before_recovery(self):
        self.panel.devices[SERIAL]=self.device('stopped')
        self.polls(2);self.flow._begin.assert_not_called()
        self.polls(1);self.flow._begin.assert_called_once()
        self.assertEqual(self.watch.snapshot()['sessions'][0]['attempts'],1)

    def test_healthy_account_never_restarted(self):
        self.panel.devices[SERIAL]=self.device()
        self.polls(10)
        self.flow._begin.assert_not_called()

    def test_no_recovery_after_full_stop_or_scenario_cancel(self):
        self.panel.suspended=True;self.polls(4);self.flow._begin.assert_not_called()
        self.panel.suspended=False;self.flow.stop_event.set();self.polls(4)
        self.flow._begin.assert_not_called()

    def test_disabled_or_unmanaged_account_not_targeted(self):
        self.account['enabled']=False;self.polls(4);self.flow._begin.assert_not_called()
        self.account['enabled']=True;self.panel.controlled_apps.clear();self.polls(4)
        self.flow._begin.assert_not_called()

    def test_busy_operation_and_memory_pressure_prevent_new_restart(self):
        self.flow.state['running']=True;self.polls(4);self.flow._begin.assert_not_called()
        self.flow.state['running']=False;self.panel.resources['pauseNewLaunches']=True
        self.polls(4);self.flow._begin.assert_not_called()
        self.assertEqual(self.watch.snapshot()['sessions'][0]['stage'],'waiting_resources')

    def test_six_unstable_restarts_trip_circuit_breaker(self):
        self.panel.devices[SERIAL]=self.device('stopped')
        for _ in range(6): self.polls(3);self.now+=400
        self.polls(3)
        self.assertEqual(self.flow._begin.call_count,6)
        self.assertTrue(self.watch.snapshot()['sessions'][0]['blocked'])

    def test_backoff_prevents_fast_repeated_restarts(self):
        self.panel.devices[SERIAL]=self.device('stopped')
        self.polls(3)
        self.now=101.;self.polls(3)
        self.assertEqual(self.flow._begin.call_count,1)

    def test_three_real_ui_probes_detect_disconnect(self):
        self.panel.devices[SERIAL]=self.device();self.probe.return_value='disconnected'
        self.polls(3)
        self.assertEqual(self.probe.call_count,3)
        self.flow._begin.assert_called_once()

    def test_transient_disconnect_does_not_restart(self):
        self.panel.devices[SERIAL]=self.device();self.probe.side_effect=['disconnected',None,None]
        self.polls(5)
        self.flow._begin.assert_not_called()

    def test_ui_checks_do_not_starve_other_accounts(self):
        other='127.0.0.1:5555'
        self.panel.mutate('account',{'login':'Other','serial':other,'placeId':'456'})
        self.panel.allowed_serials.add(other);self.panel.controlled_apps[other]='com.roblox.client'
        self.panel.devices={SERIAL:self.device(),other:self.device()}
        self.polls(2)
        self.assertEqual({c.args[0] for c in self.probe.call_args_list},{SERIAL,other})

    def test_stable_two_minutes_reset_crash_budget(self):
        self.panel.devices[SERIAL]=self.device();self.watch.tick()
        rec=self.watch.records[self.account['id']];rec['attempts']=4
        self.now+=121;self.watch.tick()
        self.assertEqual(self.watch.records[self.account['id']]['attempts'],0)

    def test_new_manual_start_rearms_blocked_session(self):
        self.panel.devices[SERIAL]=self.device();self.watch.tick()
        self.watch.records[self.account['id']]['blocked']=True
        self.flow.generation+=1;self.watch.tick()
        self.assertFalse(self.watch.records[self.account['id']]['blocked'])

    def test_native_reconnect_starts_only_lost_index(self):
        tuner=Mock(manager=True)
        tuner.instances.return_value=[{'index':0,'port':16384,'running':False},{'index':1,'port':5555,'running':True}]
        def adb(*args,**kwargs):
            if args==('devices','-l'): return (SERIAL+' device\n127.0.0.1:5555 device\n').encode()
            if args==('shell','getprop','sys.boot_completed'): return b'1'
            return b''
        self.panel.adb=Mock(side_effect=adb)
        with patch('recovery.make_tuner',return_value=tuner):
            self.assertEqual(self.watch.reconnect(copy.deepcopy(self.account),ITEM),SERIAL)
        tuner.start_instance.assert_called_once_with(0)
        self.assertEqual(len(self.flow.managed.snapshot()['native']),1)

    def test_full_pipeline_relaunches_login_key_and_script_for_same_account(self):
        self.panel.launch_package=Mock();self.panel.adb=Mock(return_value=b'')
        key=Mock();key.run.return_value='accepted'
        script=Mock();script.run.return_value='execute_sent'
        with patch('recovery.prepare_account',return_value='account_visible') as login,patch('recovery.SessionKeys') as keys,patch('recovery.ScriptStep',return_value=script):
            keys.return_value=key
            self.watch.recover(copy.deepcopy(self.account),'client_closed')
        self.panel.launch_package.assert_called_once_with(SERIAL,'com.roblox.client')
        login.assert_called_once()
        self.assertEqual(key.run.call_args.args[1]['id'],self.account['id'])
        script.run.assert_called_once()

    def test_key_failure_does_not_run_script(self):
        self.panel.launch_package=Mock()
        key=Mock();key.run.return_value='needs_attention'
        with patch('recovery.prepare_account',return_value='account_visible'),patch('recovery.SessionKeys',return_value=key),patch('recovery.ScriptStep') as script:
            self.watch.recover(copy.deepcopy(self.account),'client_closed')
        script.assert_not_called()

    def test_only_failed_account_is_scheduled(self):
        other='127.0.0.1:5555'
        self.panel.mutate('account',{'login':'Other','serial':other,'placeId':'456'})
        self.panel.allowed_serials.add(other);self.panel.controlled_apps[other]='com.roblox.client'
        self.panel.devices={SERIAL:self.device('stopped'),other:self.device()}
        self.polls(3)
        callback=self.flow._begin.call_args.args[0]
        with patch.object(self.watch,'recover') as recover: callback()
        self.assertEqual(recover.call_args.args[0]['id'],self.account['id'])

    def test_stop_during_ui_probe_does_not_schedule_recovery(self):
        self.panel.devices[SERIAL]=self.device();self.watch.tick()
        self.watch.records[self.account['id']]['misses']=2
        self.now+=31
        def probe(serial): self.panel.suspended=True;return 'disconnected'
        self.watch.probe=probe;self.watch.tick()
        self.flow._begin.assert_not_called()

    def test_unknown_native_port_cannot_borrow_healthy_instances_port(self):
        tuner=Mock(manager=True)
        tuner.instances.return_value=[{'index':0,'port':None,'running':True},{'index':1,'port':5555,'running':True}]
        self.flow.port_reader=lambda item:[5555]
        self.flow.stop_event=Mock(is_set=Mock(return_value=False),wait=Mock(return_value=False))
        self.panel.adb=Mock(return_value=b'127.0.0.1:5555 device')
        clock=iter([0,0,181]);self.watch.clock=lambda:next(clock)
        with patch('recovery.make_tuner',return_value=tuner):
            with self.assertRaises(RuntimeError): self.watch.reconnect(copy.deepcopy(self.account),ITEM)
        self.assertFalse(any(c.args and c.args[0]=='connect' for c in self.panel.adb.call_args_list))
        self.assertEqual(self.account['serial'],SERIAL)

    def test_recovery_toggle_persists(self):
        self.watch.set_enabled({'enabled':False});self.polls(4)
        self.flow._begin.assert_not_called()
        self.assertFalse(self.watch.snapshot()['enabled'])
        with self.assertRaises(ValueError): self.watch.set_enabled({'enabled':'false'})

    def test_ui_problem_requires_recognized_foreground_controls(self):
        ui=Mock()
        ui.device.app_current.return_value={'package':'com.roblox.client'}
        ui.device.dump_hierarchy.return_value='<hierarchy><node package="com.roblox.client" text="Disconnected"/></hierarchy>'
        with patch('recovery.AndroidKeyUI',return_value=ui): self.assertEqual(ui_problem(SERIAL),'disconnected')
        ui.device.app_current.return_value={'package':'other.app'}
        with patch('recovery.AndroidKeyUI',return_value=ui): self.assertIsNone(ui_problem(SERIAL))
