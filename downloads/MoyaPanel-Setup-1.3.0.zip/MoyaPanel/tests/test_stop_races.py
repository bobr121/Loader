import subprocess
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import Mock,patch
from automation import Panel
from control_center import ControlCenter
from emulators import EmulatorFlow
from android_setup import download_delta

SERIAL='127.0.0.1:16384'

class StopRaceTests(unittest.TestCase):
    def test_scan_result_received_after_pause_cannot_repopulate_devices(self):
        with tempfile.TemporaryDirectory() as d:
            panel=Panel(d)
            def runner(cmd,**kwargs):
                panel.suspended=True
                return subprocess.CompletedProcess(cmd,0,(SERIAL+' device\n').encode(),b'')
            panel.runner=runner
            try:
                panel.scan()
                self.assertFalse(panel.devices)
                self.assertFalse(panel.busy)
            finally: panel.close()

    def test_stop_waits_for_admitted_adb_before_closing_windows(self):
        with tempfile.TemporaryDirectory() as d:
            admitted=threading.Event();finish=threading.Event();closed=threading.Event()
            def runner(cmd,**kwargs):
                admitted.set();finish.wait(3)
                return subprocess.CompletedProcess(cmd,0,b'',b'')
            panel=Panel(d,runner)
            flow=EmulatorFlow(panel);center=ControlCenter(panel,flow,Mock())
            thread=threading.Thread(target=lambda:panel.adb('devices'));thread.start()
            self.assertTrue(admitted.wait(1))
            try:
                with patch.object(flow.managed,'close_all',side_effect=lambda:closed.set() or []):
                    center.stop_all()
                    self.assertFalse(closed.wait(.05))
                    finish.set();thread.join(2);center.thread.join(2)
                self.assertTrue(closed.is_set())
                self.assertEqual(center.snapshot()['stage'],'stopped')
            finally:
                finish.set();thread.join(3);flow.close();panel.close()

    def test_download_browser_tree_is_cancelled_on_stop(self):
        with tempfile.TemporaryDirectory() as d:
            proc=Mock(pid=123)
            proc.poll.return_value=None
            stop=threading.Event();stop.set()
            with patch('subprocess.Popen',return_value=proc),patch('os.name','posix'),patch('os.killpg') as kill:
                with self.assertRaises(RuntimeError): download_delta(d,stop,Mock())
            kill.assert_called_once()
            proc.wait.assert_called_once()

    def test_pause_persistence_failure_still_cancels_work(self):
        with tempfile.TemporaryDirectory() as d:
            panel=Panel(d);flow=EmulatorFlow(panel);jobs=Mock();center=ControlCenter(panel,flow,jobs)
            try:
                with patch.object(panel,'save',side_effect=OSError('read only')):
                    center.stop_all();center.thread.join(3)
                self.assertTrue(panel.suspended)
                jobs.stop.assert_called_once()
                self.assertEqual(center.snapshot()['stage'],'stop_incomplete')
            finally: flow.close();panel.close()
