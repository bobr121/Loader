import copy
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from automation import Panel
from emulators import EmulatorFlow
from control_center import ControlCenter
from managed_resources import ManagedResources

SERIAL='127.0.0.1:16384'
ITEM={'id':'installed','name':'MuMu Player','root':'/fake','path':'/fake/MuMuPlayer.exe'}

class ControlCenterTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.runner=Mock()
        self.panel=Panel(self.tmp.name,self.runner)
        self.panel.mutate('account',{'login':'Player','serial':SERIAL,'placeId':'123'})
        self.account=self.panel.data['accounts'][0]
        self.panel.allowed_serials={SERIAL}
        self.flow=EmulatorFlow(self.panel,detector=lambda:[ITEM])
        self.flow.items=[copy.deepcopy(ITEM)]
        self.jobs=Mock()
        self.center=ControlCenter(self.panel,self.flow,self.jobs)
    def tearDown(self):
        self.flow.stop()
        if self.center.thread: self.center.thread.join(3)
        self.flow.close();self.panel.close();self.tmp.cleanup()

    def body(self,operation='save'):
        return {'id':self.account['id'],'operation':operation,'placeId':'456','luaScript':'print("new")','executorAutoInject':False}

    def stop(self):
        self.center.stop_all();self.center.thread.join(3)
        self.assertFalse(self.center.snapshot()['running'])

    def test_account_override_does_not_change_global_or_other_account(self):
        self.panel.mutate('account',{'login':'Other','serial':'127.0.0.1:5555'})
        active=self.panel.data['active']
        self.center.action(self.body())
        self.assertEqual(self.panel.data['active'],active)
        self.assertEqual(self.account['placeId'],'456')
        self.assertNotIn('configId',self.panel.data['accounts'][1])
        cfg=next(c for c in self.panel.data['configs'] if c['id']==self.account['configId'])
        self.assertEqual(cfg['luaScript'],'print("new")')
        self.assertNotIn('luaScript',next(c for c in self.panel.data['configs'] if c['id']==active))

    def test_invalid_game_does_not_partially_save(self):
        before=copy.deepcopy(self.panel.data)
        with self.assertRaises(ValueError): self.center.action(dict(self.body(),placeId='https://evil.test/games/123'))
        self.assertEqual(before,self.panel.data)

    def test_full_stop_disables_adb_and_cancels_owned_jobs(self):
        self.stop()
        self.jobs.stop.assert_called_once()
        self.assertTrue(self.panel.suspended)
        self.assertTrue(self.panel.data['runtimePaused'])
        self.assertEqual(self.panel.allowed_serials,set())
        self.assertEqual(self.center.snapshot()['stage'],'stopped')
        with self.assertRaises(RuntimeError): self.panel.adb('devices')
        self.runner.assert_not_called()
        with self.assertRaises(ValueError): self.flow.start({'id':ITEM['id']})

    def test_waits_for_worker_before_closing_owned_emulators(self):
        worker_finished=threading.Event()
        def work():
            self.flow.stop_event.wait(2);worker_finished.set()
        self.flow._begin(work)
        with patch.object(self.flow.managed,'close_all',side_effect=lambda:[] if worker_finished.is_set() else ['race']):
            self.stop()
        self.assertEqual(self.center.snapshot()['stage'],'stopped')

    def test_failed_close_never_claims_full_stop(self):
        with patch.object(self.flow.managed,'close_all',return_value=['Instance still running']): self.stop()
        self.assertEqual(self.center.snapshot()['stage'],'stop_incomplete')
        self.assertTrue(self.center.snapshot()['errors'])

    def test_resume_uses_saved_options_and_rolls_back_on_error(self):
        self.panel.data['lastRun']={'id':ITEM['id'],'setupDelta':True,'autoKeys':True,'runScript':True}
        self.stop()
        with patch.object(self.flow,'start',side_effect=ValueError('missing config')):
            with self.assertRaises(ValueError): self.center.resume()
        self.assertTrue(self.panel.suspended)
        with patch.object(self.flow,'start') as start:
            self.center.resume()
        self.assertFalse(self.panel.suspended)
        self.assertEqual(start.call_args.args[0]['id'],ITEM['id'])
        self.assertTrue(start.call_args.args[0]['runScript'])

    def test_game_action_uses_bound_serial_and_key_then_script(self):
        self.panel.adb=Mock(return_value=b'Status: ok')
        key=Mock();key.run.return_value='already_unlocked'
        script=Mock();script.run.return_value='execute_sent'
        with patch('control_center.SessionKeys',return_value=key),patch('control_center.ScriptStep',return_value=script):
            self.center.action(self.body('game'));self.flow.thread.join(3)
        self.assertEqual(self.panel.adb.call_args.kwargs['serial'],SERIAL)
        self.assertIn('roblox://placeId=456',self.panel.adb.call_args.args)
        script.run.assert_called_once()
        self.assertEqual(script.run.call_args.args[2]['luaScript'],'print("new")')

    def test_key_failure_does_not_execute_new_script(self):
        key=Mock();key.run.return_value='needs_attention'
        with patch('control_center.SessionKeys',return_value=key),patch('control_center.ScriptStep') as script:
            self.center.action(self.body('script'));self.flow.thread.join(3)
        script.assert_not_called()

    def test_stop_also_force_stops_controlled_game(self):
        self.panel.controlled_apps[SERIAL]='com.roblox.client'
        self.panel.adb=Mock(return_value=b'')
        self.stop()
        self.assertEqual(self.panel.adb.call_args_list[0].args,('shell','am','force-stop','com.roblox.client'))
        self.assertTrue(self.panel.adb.call_args_list[0].kwargs['allow_suspended'])
        self.assertFalse(self.panel.controlled_apps)

    def test_pause_before_first_run_can_be_released_without_last_run(self):
        self.stop()
        self.assertTrue(self.center.snapshot()['canResume'])
        result=self.center.resume()
        self.assertTrue(result['selectionRequired'])
        self.assertFalse(self.panel.suspended)
        self.assertFalse(self.flow.closing_all)

    def test_paused_state_survives_panel_restart(self):
        self.stop()
        reloaded=Panel(self.tmp.name)
        try: self.assertTrue(reloaded.suspended)
        finally: reloaded.close()

class ManagedResourceTests(unittest.TestCase):
    def test_native_shutdown_targets_only_registered_instance(self):
        owned=ManagedResources();tuner=Mock()
        tuner.instances.return_value=[{'index':0,'running':True},{'index':1,'running':True}]
        owned.native_launch(ITEM,tuner,1)
        self.assertEqual(owned.close_all(),[])
        self.assertEqual(tuner.stop_instance.call_args.args[0],1)
        self.assertEqual(tuner.stop_instance.call_count,1)
        self.assertFalse(owned.snapshot()['native'])

    def test_reused_process_id_is_never_terminated(self):
        owned=ManagedResources();owned.processes[123]=1.0
        process=Mock();process.create_time.return_value=2.0
        fake=SimpleNamespace(Process=Mock(return_value=process),NoSuchProcess=ProcessLookupError,wait_procs=Mock(return_value=([],[])))
        with patch.dict(sys.modules,{'psutil':fake}): self.assertEqual(owned.close_all(),[])
        process.terminate.assert_not_called();process.kill.assert_not_called()

    def test_failed_native_shutdown_retains_ownership_for_retry(self):
        owned=ManagedResources();tuner=Mock()
        tuner.instances.return_value=[{'index':0,'running':True}]
        tuner.stop_instance.side_effect=RuntimeError('blocked')
        owned.native_launch(ITEM,tuner,0)
        self.assertTrue(owned.close_all())
        self.assertEqual(len(owned.snapshot()['native']),1)
