import base64,hashlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from updater import UpdateManager,canonical,safe_name,verify,fetch,ApplicationLock

class UpdateTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.key=Ed25519PrivateKey.generate()
  self.config={'manifestUrl':'https://raw.githubusercontent.com/bobr121/Loader/main/updates/stable.json','publicKey':base64.b64encode(self.key.public_key().public_bytes_raw()).decode()}
  (self.root/'update_config.json').write_text(json.dumps(self.config))
  self.old={'desktop.py':b'# old desktop','updater.py':b'# old updater','requirements.txt':b'stable\n','version.json':canonical({'version':'1.0.0','sequence':1})}
  for name,data in self.old.items():(self.root/name).write_bytes(data)
  (self.root/'panel_state.json').write_text('USER ACCOUNTS');(self.root/'key.txt').write_text('USER KEY')
  self.manager=UpdateManager(self.root)
  self.files=dict(self.old,**{'desktop.py':b'# new desktop','version.json':canonical({'version':'1.0.1','sequence':2})})
 def tearDown(self):self.temp.cleanup()
 def release(self,files=None):
  files=files or self.files;buffer=io.BytesIO()
  with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
   for name,value in files.items():z.writestr(name,value)
  data=buffer.getvalue();payload={'version':'1.0.1','sequence':2,'archiveUrl':'https://raw.githubusercontent.com/bobr121/Loader/main/updates/releases/test.zip','size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'files':{k:hashlib.sha256(v).hexdigest() for k,v in files.items()}}
  return {'payload':payload,'signature':base64.b64encode(self.key.sign(canonical(payload))).decode()},data
 def stage(self):
  release,data=self.release()
  with patch('updater.fetch',side_effect=[canonical(release),data]):self.manager.check()
 def test_stage_does_not_change_running_source_or_accounts(self):
  self.stage();self.assertEqual((self.root/'desktop.py').read_bytes(),self.old['desktop.py']);self.assertEqual(self.manager.snapshot()['stage'],'pending');self.assertEqual((self.root/'panel_state.json').read_text(),'USER ACCOUNTS')
 def test_apply_and_ui_health_preserve_accounts(self):
  self.stage();self.assertEqual(self.manager.startup(),(True,2));self.assertEqual((self.root/'desktop.py').read_bytes(),self.files['desktop.py']);self.assertFalse(self.manager.mark_healthy())
  self.manager.window_ready();self.assertTrue(self.manager.mark_healthy());self.assertFalse((self.root/'.update/journal.json').exists());self.assertEqual(self.manager.startup(),(False,None));self.assertEqual((self.root/'panel_state.json').read_text(),'USER ACCOUNTS');self.assertEqual((self.root/'key.txt').read_text(),'USER KEY')
 def test_failed_trial_rolls_back_and_requires_reexec(self):
  self.stage();self.manager.startup();self.assertEqual(self.manager.startup(),(True,None))
  for name,value in self.old.items():self.assertEqual((self.root/name).read_bytes(),value)
  self.assertEqual(json.loads((self.root/'.update/failed.json').read_text()),[2])
 def test_trial_child_allowed_before_ui_ack(self):
  self.stage();self.manager.startup();self.assertEqual(self.manager.startup(trial=2),(False,2));self.assertTrue((self.root/'.update/journal.json').exists())
 def test_tampered_manifest_rejected(self):
  release,data=self.release();release['payload']['version']='9.9.9'
  with patch('updater.fetch',return_value=canonical(release)):
   with self.assertRaises(Exception):self.manager.check()
  self.assertEqual((self.root/'desktop.py').read_bytes(),self.old['desktop.py'])
 def test_wrong_publisher_key_rejected(self):
  release,_=self.release();other=dict(self.config,publicKey=base64.b64encode(Ed25519PrivateKey.generate().public_key().public_bytes_raw()).decode())
  with self.assertRaises(Exception):verify(release,other)
 def test_archive_hash_mismatch(self):
  release,data=self.release()
  with patch('updater.fetch',side_effect=[canonical(release),data+b'bad']):
   with self.assertRaises(ValueError):self.manager.check()
  self.assertFalse((self.root/'.update/pending.json').exists())
 def test_mutated_stage_rejected(self):
  self.stage();(self.root/'.update/stage-2/desktop.py').write_text('tampered')
  with self.assertRaises(ValueError):self.manager.startup()
  self.assertEqual((self.root/'desktop.py').read_bytes(),self.old['desktop.py'])
 def test_protected_paths_and_traversal_rejected(self):
  for name in ['../desktop.py','app/../panel_state.json','C:/evil.py','app\\bad.js','panel_state.json','.venv/Scripts/python.exe','update_config.json','publisher.key']:
   with self.assertRaises(ValueError):safe_name(name)
 def test_future_modules_and_assets_supported(self):
  self.assertEqual(safe_name('new_feature.py'),'new_feature.py');self.assertEqual(safe_name('app/icons/new.svg'),'app/icons/new.svg')
 def test_duplicate_case_archive_rejected(self):
  files=dict(self.files);files['Desktop.py']=b'collision';release,data=self.release(files)
  with patch('updater.fetch',side_effect=[canonical(release),data]):
   with self.assertRaises(ValueError):self.manager.check()
 def test_downgrade_does_not_download_payload(self):
  release,_=self.release();(self.root/'version.json').write_bytes(canonical({'version':'2.0.0','sequence':10}))
  with patch('updater.fetch',return_value=canonical(release)) as network:self.manager.check()
  self.assertEqual(network.call_count,1)
 def test_https_and_repository_fixed(self):
  for url in ['http://raw.githubusercontent.com/bobr121/Loader/main/x','https://evil.test/update.zip','https://raw.githubusercontent.com/other/repo/main/x']:
   with self.assertRaises(ValueError):fetch(url,10)
 def test_dependency_changes_use_separate_environment(self):
  stage=self.root/'stage';stage.mkdir();(stage/'requirements.txt').write_text('new-dependency')
  with patch('updater.subprocess.run') as process:self.assertEqual(self.manager.runtime_for(stage,2),'.update/env-2')
  self.assertEqual(process.call_count,3);self.assertIn('env-2',process.call_args_list[0].args[0][-1]);self.assertFalse((self.root/'.venv').exists())
 def test_single_folder_lock(self):
  with ApplicationLock(self.root):
   with patch('updater.time.monotonic',side_effect=[0,10]):
    with self.assertRaises(RuntimeError):
     with ApplicationLock(self.root):pass
 def test_failed_copy_rolls_back_all_changed_files(self):
  self.stage()
  import updater
  original=updater.os.replace;count=[0]
  def replace(source,target):
   count[0]+=1
   if count[0]==3:raise OSError('simulated write failure')
   return original(source,target)
  with patch('updater.os.replace',side_effect=replace):
   with self.assertRaises(OSError):self.manager.startup()
  for name,value in self.old.items():self.assertEqual((self.root/name).read_bytes(),value)
  self.assertEqual((self.root/'panel_state.json').read_text(),'USER ACCOUNTS')
 def test_stable_bootstrap_recovers_broken_new_updater(self):
  self.files['updater.py']=b'not valid python : :'
  self.stage();self.manager.startup()
  from bootstrap import rollback
  rollback(self.root)
  self.assertEqual((self.root/'updater.py').read_bytes(),self.old['updater.py'])
  self.assertEqual((self.root/'desktop.py').read_bytes(),self.old['desktop.py'])
 def test_bootstrap_and_trust_config_cannot_be_updated_by_payload(self):
  for name in ['bootstrap.py','update_config.json']:
   with self.assertRaises(ValueError):safe_name(name)
