import threading
import tempfile
import unittest
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import Mock, patch
from session_keys import SessionKeys, AndroidKeyUI, key_url, KeyAttention

SERIAL='127.0.0.1:16384'
ACCOUNT={'id':'one','login':'Player','serial':SERIAL,'enabled':True}

def view(accepted=False, field=True, copy=True, verify=True):
    return {'accepted':accepted,'field':{'id':'field'} if field else None,
            'copy':{'id':'copy'} if copy else None,'verify':{'id':'verify'} if verify else None}

class SessionKeyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.panel=SimpleNamespace(path=Path(self.temp.name)/'panel_state.json',lock=threading.RLock(),
                                   data={'accounts':[dict(ACCOUNT)]},event=Mock())
        self.ui=Mock()
        self.ui.copy_url.return_value='https://example.com/device-one'
        self.jobs=Mock()
        self.jobs.snapshot.return_value={'running':False,'stage':'succeeded','key':'SECRET_ONE'}
        self.states=[]
        self.flow=SessionKeys(self.panel,lambda *args,**kwargs:self.states.append((args,kwargs)),
                              ui_factory=lambda serial:self.ui,jobs_factory=lambda directory:self.jobs)
        self.stop=threading.Event()
    def tearDown(self): self.temp.cleanup()

    def test_already_unlocked_does_nothing(self):
        self.ui.view.return_value=view(accepted=True)
        self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop),'already_unlocked')
        self.ui.copy_url.assert_not_called()
        self.ui.insert.assert_not_called()
        self.jobs.start.assert_not_called()

    def test_return_key_to_original_session_and_auto_accept_without_verify(self):
        self.ui.view.side_effect=[view(),view(),view(accepted=True)]
        self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop),'accepted')
        self.ui.insert.assert_called_once_with({'id':'field'},'SECRET_ONE')
        self.ui.verify.assert_not_called()
        self.assertFalse(self.jobs.start.call_args.args[0]['saveKey'])
        self.assertNotIn('SECRET_ONE',str(self.states))
        self.jobs.close.assert_called_once()

    def test_button_clicked_once_only_if_automatic_acceptance_did_not_happen(self):
        self.ui.view.side_effect=[view(),view(),view(),view(),view(accepted=True)]
        with patch('session_keys.time.monotonic',side_effect=[0,0,0,0,0,4,4,5]):
            self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop),'accepted')
        self.ui.verify.assert_called_once()

    def test_rebinding_during_key_generation_prevents_insertion(self):
        self.ui.view.return_value=view()
        def start(body): self.panel.data['accounts'][0]['serial']='127.0.0.1:5555'
        self.jobs.start.side_effect=start
        self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop),'needs_attention')
        self.ui.insert.assert_not_called()
        self.jobs.close.assert_called_once()

    def test_no_key_or_lost_field_never_inserts(self):
        self.ui.view.side_effect=[view(),view(field=False)]
        self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop),'needs_attention')
        self.ui.insert.assert_not_called()

    def test_access_opened_during_wait_is_left_untouched(self):
        self.ui.view.side_effect=[view(),view(accepted=True)]
        self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop),'already_unlocked')
        self.ui.insert.assert_not_called()
        self.ui.verify.assert_not_called()

    def test_stop_cancels_owned_browser_job(self):
        self.ui.view.return_value=view()
        self.jobs.snapshot.return_value={'running':True}
        self.jobs.start.side_effect=lambda body:self.stop.set()
        self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop),'stopped')
        self.jobs.stop.assert_called_once()
        self.ui.insert.assert_not_called()

    def test_unknown_ui_is_not_success(self):
        self.ui.view.return_value=view(field=False,copy=False)
        self.assertEqual(self.flow.run(SERIAL,ACCOUNT,self.stop,timeout=0),'needs_attention')
        self.ui.insert.assert_not_called()

    def test_private_or_stale_non_url_clipboard_is_rejected(self):
        for value in ['old-key','http://example.com','https://127.0.0.1/path','https://localhost/path','https://10.0.0.1/key','https://user:password@example.com']:
            with self.assertRaises(KeyAttention): key_url(value)

    def test_inserted_text_does_not_make_background_editor_count_as_success(self):
        adapter=AndroidKeyUI.__new__(AndroidKeyUI)
        adapter.pid=None;adapter.field_id=None
        adapter.device=Mock()
        adapter.device.app_current.return_value={'package':'com.roblox.client','pid':42}
        def xml(value):
            return '<hierarchy><node package="com.roblox.client" class="android.widget.EditText" resource-id="delta:key" text="'+value+'"/><node package="com.roblox.client" class="android.widget.EditText" text="Enter script here"/></hierarchy>'
        adapter.device.dump_hierarchy.side_effect=[xml('Enter Key'),xml('SECRET_ONE')]
        self.assertFalse(adapter.view()['accepted'])
        after=adapter.view()
        self.assertIsNotNone(after['field'])
        self.assertFalse(after['accepted'])

    def test_filled_script_editor_still_counts_as_unlocked_for_later_controls(self):
        adapter=AndroidKeyUI.__new__(AndroidKeyUI)
        adapter.pid=None;adapter.field_id=None;adapter.device=Mock()
        adapter.device.app_current.return_value={'package':'com.roblox.client','pid':42}
        adapter.device.dump_hierarchy.return_value='<hierarchy><node package="com.roblox.client" class="android.widget.EditText" resource-id="delta:id/script_editor" text="print(123)"/></hierarchy>'
        self.assertTrue(adapter.view()['accepted'])

    def test_process_restart_rejects_old_result(self):
        adapter=AndroidKeyUI.__new__(AndroidKeyUI)
        adapter.pid=42;adapter.field_id=None;adapter.device=Mock()
        adapter.device.app_current.return_value={'package':'com.roblox.client','pid':43}
        with self.assertRaises(KeyAttention): adapter.view()

    def test_android_copy_clears_clipboard_before_reading_new_url(self):
        adapter=AndroidKeyUI.__new__(AndroidKeyUI)
        adapter.device=Mock(clipboard='stale')
        adapter.control=Mock()
        adapter.control.return_value.click.side_effect=lambda:setattr(adapter.device,'clipboard','https://example.com/device-one')
        self.assertEqual(adapter.copy_url({},self.stop),'https://example.com/device-one')
        adapter.control.return_value.click.assert_called_once()
