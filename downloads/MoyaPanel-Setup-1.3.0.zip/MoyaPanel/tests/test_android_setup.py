import sys
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from android_setup import place_id, validate_apk, install_delta, prepare_account, PACKAGE
from automation import Panel
from load_guard import can_add_instance

SERIAL = '127.0.0.1:16384'


class AndroidSetupTests(unittest.TestCase):
    def test_place_id_normalizes_and_rejects_other_destinations(self):
        self.assertEqual(place_id('https://www.roblox.com/games/123/Test'), '123')
        self.assertEqual(place_id('000123'), '123')
        for invalid in ['https://evil.test/games/123', '123;id', '0', '-1', '١٢٣']:
            with self.assertRaises(ValueError):
                place_id(invalid)

    def test_apk_structure_and_digest(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'a.apk'
            path.write_bytes(b'<html>Not an APK</html>')
            with self.assertRaises(RuntimeError):
                validate_apk(path)
            with zipfile.ZipFile(path, 'w') as archive:
                archive.writestr('AndroidManifest.xml', b'M' * 1024)
                archive.writestr('classes.dex', b'D' * 1024)
            self.assertEqual(len(validate_apk(path)), 64)

    def test_account_login_survives_snapshot_and_duplicate_binding_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Panel(d)
            try:
                p.mutate('account', {'login': 'MyUsername', 'serial': SERIAL, 'placeId': '123'})
                item = p.snapshot()['accounts'][0]
                self.assertEqual(item['login'], 'MyUsername')
                self.assertEqual(item['placeId'], '123')
                self.assertEqual(item['loginState'], 'unverified')
                with self.assertRaises(ValueError):
                    p.mutate('account', {'login': 'Different', 'serial': SERIAL})
                with self.assertRaises(ValueError):
                    p.mutate('account', {'id': item['id'], 'login':'MyUsername', 'serial': SERIAL, 'placeId':'https://evil.test/'})
            finally:
                p.close()

    def test_install_rejects_wrong_package_before_adb(self):
        panel = Mock()
        module = SimpleNamespace(APK=Mock(return_value=SimpleNamespace(get_package=lambda:'wrong.package')))
        with patch.dict(sys.modules, {'androguard':Mock(), 'androguard.core':Mock(), 'androguard.core.apk':module}):
            with self.assertRaises(RuntimeError):
                install_delta(panel, SERIAL, 'a.apk', Mock())
        panel.adb.assert_not_called()

    def test_install_all_files_only_when_requested(self):
        module = SimpleNamespace(APK=Mock(return_value=SimpleNamespace(get_package=lambda: PACKAGE)))
        for permission in [False, True]:
            panel = Mock()
            responses = [b'Success', b'package:/data/app/a.apk', (b'requested permissions:\n android.permission.MANAGE_EXTERNAL_STORAGE\ninstall permissions:' if permission else b'requested permissions:\ninstall permissions:')]
            if permission:
                responses += [b'', b'MANAGE_EXTERNAL_STORAGE: allow']
            panel.adb.side_effect = responses
            with patch.dict(sys.modules, {'androguard':Mock(), 'androguard.core':Mock(), 'androguard.core.apk':module}):
                install_delta(panel, SERIAL, 'a.apk', Mock())
            self.assertEqual(any('appops' in c.args for c in panel.adb.call_args_list), permission)

    def test_unrecognized_login_never_reads_or_sends_password(self):
        device = Mock()
        device.app_current.return_value = {'package': PACKAGE}
        device.dump_hierarchy.return_value = '<hierarchy/>'
        field = Mock(count=0, exists=False)
        device.return_value = field
        stop = Mock()
        stop.is_set.side_effect = [False, True, True]
        panel = Mock()
        with patch.dict(sys.modules, {'uiautomator2': SimpleNamespace(connect=Mock(return_value=device)), 'adbutils':Mock()}):
            self.assertEqual(prepare_account(panel, SERIAL, {'id':'a','login':'User'}, stop, Mock()), 'cancelled')
        panel.vault.assert_not_called()
        field.set_text.assert_not_called()
        panel.adb.assert_not_called()

    def test_visible_account_sends_own_place_only(self):
        device = Mock()
        device.app_current.return_value = {'package': PACKAGE}
        device.dump_hierarchy.return_value = '<hierarchy/>'
        field = Mock(count=0, exists=False)
        device.side_effect = lambda **kw: Mock(exists=True) if kw.get('text') == 'User' else field
        panel=Mock()
        with patch.dict(sys.modules, {'uiautomator2':SimpleNamespace(connect=Mock(return_value=device)), 'adbutils':Mock()}):
            result=prepare_account(panel,SERIAL,{'id':'a','login':'User','placeId':'123'},threading.Event(),Mock())
        self.assertEqual(result,'account_visible')
        self.assertIn('roblox://placeId=123', panel.adb.call_args.args)
        panel.vault.assert_not_called()

    def test_recognized_form_submits_secret_once_and_not_via_adb(self):
        device=Mock()
        device.app_current.return_value={'package':PACKAGE}
        device.dump_hierarchy.side_effect=['<hierarchy><node package="com.roblox.client" class="android.widget.EditText" resource-id="com.roblox.client:id/username" text="Username"/><node package="com.roblox.client" class="android.widget.EditText" resource-id="com.roblox.client:id/password" password="true"/></hierarchy>', '<hierarchy/>']
        username=Mock(count=1)
        password=Mock(count=1)
        submit=Mock(count=1)
        def selector(**kw):
            if kw.get('resourceId','').endswith('/username'): return username
            if kw.get('resourceId','').endswith('/password'): return password
            if kw.get('text')=='Player': return Mock(exists=True)
            return submit
        device.side_effect=selector
        panel=Mock()
        panel.vault.return_value.get_password.return_value='PRIVATE_PASSWORD'
        stop=Mock(is_set=Mock(return_value=False))
        with patch.dict(sys.modules, {'uiautomator2':SimpleNamespace(connect=Mock(return_value=device)), 'adbutils':Mock()}):
            self.assertEqual(prepare_account(panel,SERIAL,{'id':'account','login':'Player'},stop,Mock()),'account_visible')
        username.set_text.assert_called_once_with('Player')
        password.set_text.assert_called_once_with('PRIVATE_PASSWORD')
        submit.click.assert_called_once()
        panel.adb.assert_not_called()

    def test_load_guard_denies_low_ram_and_high_cpu(self):
        stop=Mock(wait=Mock(return_value=False))
        for cpu, free, expected in [(10,4,False),(95,12,False),(40,12,True)]:
            with patch('load_guard.time.monotonic',side_effect=[0,0,1]):
                self.assertEqual(can_add_instance(3,stop,seconds=1,sample=lambda:(cpu,free)),expected)

    def test_load_guard_obeys_cancellation(self):
        stop=Mock(wait=Mock(return_value=True))
        with patch('load_guard.time.monotonic',return_value=0):
            self.assertFalse(can_add_instance(3,stop,sample=lambda:(10,12)))
