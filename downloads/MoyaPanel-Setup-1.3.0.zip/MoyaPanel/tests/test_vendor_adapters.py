import json
import subprocess
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import Mock
from vendor_adapters import LDPlayerTuner, MEmuTuner, NoxTuner, capabilities
from official_sources import open_official, catalogue


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.budget=lambda:{'availableGB':16}

    def tearDown(self):
        self.temp.cleanup()

    def item(self,name,exe):
        (self.root/exe).write_bytes(b'fake')
        return {'id':'test','name':name,'root':str(self.root),'path':str(self.root/'player.exe')}

    def result(self,cmd,output='ok'):
        return subprocess.CompletedProcess(cmd,0,output.encode(),b'')

    def test_ld_modify_readback_and_restore(self):
        item=self.item('LDPlayer','ldconsole.exe')
        config=self.root/'vms/config/leidian0.config'
        config.parent.mkdir(parents=True)
        original={'advancedSettings.cpuCount':4,'advancedSettings.memorySize':4096}
        config.write_text(json.dumps(original))
        calls=[]
        def runner(cmd,**kw):
            calls.append(cmd)
            if cmd[1]=='list2':return self.result(cmd,'0,LDPlayer,0,0,0,0,0\n')
            if cmd[1]=='modify':
                data=json.loads(config.read_text())
                key='advancedSettings.cpuCount' if '--cpu' in cmd else 'advancedSettings.memorySize'
                data[key]=int(cmd[-1]);config.write_text(json.dumps(data))
            return self.result(cmd)
        tuner=LDPlayerTuner(item,self.root,runner=runner,budget=self.budget)
        self.assertEqual(tuner.instances()[0]['port'],5555)
        tuner.apply({'index':0,'running':False},{'cores':2,'guestGB':2},threading.Event())
        self.assertEqual(tuner.read(0),{'cpu':'2','memory':'2048'})
        tuner.restore(threading.Event())
        self.assertEqual(json.loads(config.read_text()),original)
        self.assertFalse(any('--imei' in c or '--mac' in c for c in calls))

    def test_ld_compact_list2_format(self):
        item=self.item('LDPlayer','ldconsole.exe')
        tuner=LDPlayerTuner(item,self.root,runner=lambda cmd,**kw:self.result(cmd,'2,LDPlayer,1,960,540,160\n'))
        instance=tuner.instances()[0]
        self.assertEqual(instance['index'],2)
        self.assertTrue(instance['running'])
        self.assertEqual(instance['port'],5559)

    def test_ld_unknown_schema_refuses_changes(self):
        item=self.item('LDPlayer','ldconsole.exe')
        config=self.root/'vms/config/leidian0.config'
        config.parent.mkdir(parents=True);config.write_text('{}')
        runner=Mock()
        tuner=LDPlayerTuner(item,self.root,runner=runner,budget=self.budget)
        with self.assertRaisesRegex(RuntimeError,'невідома схема'):
            tuner.apply({'index':0,'running':False},{'cores':2,'guestGB':2},threading.Event())
        runner.assert_not_called()

    def test_memu_get_set_config_roundtrip(self):
        item=self.item('MEmu','memuc.exe')
        values={'cpus':'4','memory':'4096'}
        def runner(cmd,**kw):
            if cmd[1]=='listvms':return self.result(cmd,'0,MEmu,0,0,0\n')
            if cmd[1]=='getconfigex':return self.result(cmd,values[cmd[-1]])
            if cmd[1]=='setconfigex':values[cmd[-2]]=cmd[-1]
            return self.result(cmd)
        tuner=MEmuTuner(item,self.root,runner=runner,budget=self.budget)
        self.assertFalse(tuner.instances()[0]['running'])
        tuner.apply({'index':0,'running':False},{'cores':2,'guestGB':3},threading.Event())
        self.assertEqual(values,{'cpus':'2','memory':'3072'})
        self.assertNotIn('FPS',tuner.native_fields)
        tuner.restore(threading.Event())
        self.assertEqual(values,{'cpus':'4','memory':'4096'})

    def test_nox_reads_namespaced_config_and_uses_named_instance(self):
        item=self.item('Nox','NoxConsole.exe')
        config=self.root/'BignoxVMS/Nox/Nox.vbox'
        config.parent.mkdir(parents=True)
        template='<VirtualBox xmlns="urn:test"><Machine><Hardware><CPU count="{cpu}"/><Memory RAMSize="{memory}"/><Network><Forwarding guestport="5555" hostport="62001"/></Network></Hardware></Machine></VirtualBox>'
        data={'cpu':4,'memory':4096};config.write_text(template.format(**data))
        calls=[]
        def runner(cmd,**kw):
            calls.append(cmd)
            if cmd[1]=='list':return self.result(cmd,'Nox,NoxPlayer,0,0,0,0\n')
            if cmd[1]=='modify':
                key,value=cmd[-1][1:].split(':');data[key]=int(value);config.write_text(template.format(**data))
            return self.result(cmd)
        tuner=NoxTuner(item,self.root,runner=runner,budget=self.budget)
        self.assertEqual(tuner.instances()[0]['port'],62001)
        tuner.apply({'index':'Nox','running':False},{'cores':2,'guestGB':2},threading.Event())
        self.assertEqual(tuner.read('Nox'),{'cpu':'2','memory':'2048'})
        self.assertTrue(any('-name:Nox' in cmd for cmd in calls))
        tuner.restore(threading.Event())
        self.assertEqual(tuner.read('Nox'),{'cpu':'4','memory':'4096'})

    def test_vendor_memory_quantization_recomputes_capacity(self):
        item=self.item('LDPlayer','ldconsole.exe')
        tuner=LDPlayerTuner(item,self.root)
        profile=tuner.profile_for_host({'totalGB':16,'availableGB':12,'reserveGB':4,
                                       'logicalCPU':12,'cores':2,'guestGB':3})
        self.assertEqual(profile['guestGB'],4)
        self.assertEqual(profile['estimatedInstances'],2)

    def test_bluestacks_not_advertised_as_native_tuner(self):
        item=self.item('BlueStacks','HD-Player.exe')
        self.assertEqual(capabilities(item)['nativeFields'],[])

    def test_downloads_only_open_catalogue_urls(self):
        opener=Mock(return_value=True)
        for item in catalogue():
            open_official(item['id'],opener)
            opener.assert_called_with(item['url'])
            self.assertTrue(item['url'].startswith('https://'+item['domain']+'/'))
        count=opener.call_count
        with self.assertRaises(ValueError):open_official('https://evil.example',opener)
        self.assertEqual(opener.call_count,count)
