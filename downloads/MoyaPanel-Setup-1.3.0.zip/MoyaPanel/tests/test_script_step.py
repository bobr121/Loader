import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
from script_step import ScriptStep
from automation import Panel

SERIAL='127.0.0.1:16384'
ACCOUNT={'id':'a','login':'Player','serial':SERIAL,'enabled':True}
CONFIG={'id':'cfg','luaScript':'print("demo")','executorAutoInject':False}
EDITOR={'class':'android.widget.EditText','resource-id':'delta:id/script_editor'}
BUTTON={'class':'android.widget.Button','text':'Execute'}
VIEW={'keyGate':False,'editor':EDITOR,'execute':BUTTON,'tab':None}

class ScriptStepTests(unittest.TestCase):
    def setUp(self):
        self.config=dict(CONFIG)
        self.panel=SimpleNamespace(lock=threading.RLock(),data={'accounts':[dict(ACCOUNT)],'active':'cfg','configs':[self.config]},event=Mock())
        self.ui=Mock()
        self.ui.script_view.return_value=dict(VIEW)
        self.ui.read.return_value=CONFIG['luaScript']
        self.factory=Mock(return_value=self.ui)
        self.states=[]
        self.step=ScriptStep(self.panel,lambda *args:self.states.append(args),self.factory)
        self.stop=threading.Event()

    def test_executor_autoinject_means_no_android_calls(self):
        self.config['executorAutoInject']=True
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'skipped')
        self.factory.assert_not_called()

    def test_account_specific_config_does_not_need_global_activation(self):
        self.panel.data['active']='global'
        self.panel.data['configs'].append({'id':'global','luaScript':'different'})
        self.panel.data['accounts'][0]['configId']='cfg'
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'execute_sent')

    def test_empty_script_means_no_android_calls(self):
        self.config['luaScript']=''
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'needs_attention')
        self.factory.assert_not_called()

    def test_verified_paste_then_single_execute(self):
        editor=Mock();button=Mock()
        self.ui.control.side_effect=[editor,button]
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'execute_sent')
        editor.set_text.assert_called_once_with(CONFIG['luaScript'])
        button.click.assert_called_once()
        self.assertNotIn(CONFIG['luaScript'],str(self.states))

    def test_readback_mismatch_never_clicks(self):
        self.ui.read.return_value='truncated'
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'needs_attention')
        self.ui.control.return_value.click.assert_not_called()

    def test_unknown_editor_is_not_success(self):
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop,timeout=0),'needs_attention')
        self.ui.control.assert_not_called()

    def test_stop_prevents_all_interaction(self):
        self.stop.set()
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'stopped')
        self.factory.assert_not_called()

    def test_rebound_account_prevents_all_interaction(self):
        self.panel.data['accounts'][0]['serial']='127.0.0.1:5555'
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'needs_attention')
        self.factory.assert_not_called()

    def test_config_change_after_paste_prevents_execute(self):
        pinned=dict(self.config)
        self.ui.control.return_value.set_text.side_effect=lambda text:self.config.update(luaScript='different script')
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,pinned,self.stop),'needs_attention')
        self.ui.control.return_value.click.assert_not_called()

    def test_reappearing_key_gate_prevents_execute(self):
        self.ui.script_view.return_value=dict(VIEW,keyGate=True)
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'needs_attention')
        self.ui.control.assert_not_called()

    def test_execute_exception_does_not_retry_or_leak_script(self):
        editor=Mock();button=Mock()
        button.click.side_effect=RuntimeError(CONFIG['luaScript'])
        self.ui.control.side_effect=[editor,button]
        self.assertEqual(self.step.run(SERIAL,ACCOUNT,self.config,self.stop),'needs_attention')
        button.click.assert_called_once()
        self.assertNotIn(CONFIG['luaScript'],str(self.states))

    def test_config_persists_script_and_autoinject_validates_size(self):
        with tempfile.TemporaryDirectory() as d:
            panel=Panel(d)
            try:
                panel.mutate('config',{'name':'Test','luaScript':'print(1)','executorAutoInject':True})
                config=next(c for c in panel.snapshot()['configs'] if c['id']==panel.data['active'])
                self.assertEqual(config['luaScript'],'print(1)')
                self.assertTrue(config['executorAutoInject'])
                with self.assertRaises(ValueError): panel.mutate('config',{'name':'bad','luaScript':'x'*32769})
                with self.assertRaises(ValueError): panel.mutate('config',{'name':'bad','luaScript':'x\0'})
            finally: panel.close()
