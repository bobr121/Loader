import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
from emulators import discover,installation,EmulatorFlow
from automation import Panel

class DiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.exe=self.root/'MuMuPlayerGlobal-12.0/nx_main/mumunxmain.exe'
        self.exe.parent.mkdir(parents=True);self.exe.write_bytes(b'fixture')
        self.psutil=SimpleNamespace(process_iter=lambda fields:[],Error=RuntimeError)
    def tearDown(self): self.tmp.cleanup()

    def test_new_mumu_main_name_has_correct_vendor_root(self):
        item=installation(self.exe)
        self.assertEqual(item['name'],'MuMu Player')
        self.assertEqual(Path(item['root']),self.exe.parent.parent)

    def test_registry_hint_finds_nx_main_without_recursive_walk(self):
        updates=[]
        with patch.dict(sys.modules,{'psutil':self.psutil}),patch('emulators.registry_roots',return_value=[self.exe.parent.parent]),patch.object(Path,'iterdir',side_effect=AssertionError('recursive enumeration forbidden')):
            found=discover(on_found=updates.append)
        self.assertEqual(len(found),1)
        self.assertEqual(found[0]['path'],str(self.exe))
        self.assertEqual(len(updates),1)

    def test_running_mumu_is_reported_immediately(self):
        self.psutil.process_iter=lambda fields:[SimpleNamespace(info={'exe':str(self.exe),'name':'MuMuNxMain.exe'})]
        observed=[]
        with patch.dict(sys.modules,{'psutil':self.psutil}),patch('emulators.registry_roots',return_value=[]):
            found=discover(on_found=observed.append)
        self.assertEqual(len(found),1);self.assertEqual(len(observed),1)

    def test_time_budget_stops_further_probes(self):
        with patch.dict(sys.modules,{'psutil':self.psutil}),patch('emulators.registry_roots',return_value=[self.exe.parent.parent]),patch('emulators.time.monotonic',side_effect=[0,10]):
            self.assertEqual(discover(budget_seconds=1),[])

    def test_manual_path_is_saved_and_rediscovered(self):
        panel=Panel(self.tmp.name)
        flow=EmulatorFlow(panel,detector=lambda:[])
        try:
            flow.add_path({'path':str(self.exe)})
            self.assertEqual(panel.data['manualEmulators'],[str(self.exe)])
            self.assertEqual(flow.items[0]['name'],'MuMu Player')
            flow.refresh();flow.thread.join(2)
            self.assertEqual(flow.items[0]['path'],str(self.exe))
        finally: flow.close();panel.close()

    def test_manual_path_rejects_installer_and_missing_file(self):
        panel=Panel(self.tmp.name);flow=EmulatorFlow(panel)
        try:
            bad=self.root/'MuMuInstaller.exe';bad.write_bytes(b'fixture')
            for name in [str(bad),str(self.root/'MuMuNxMain.exe')]:
                with self.assertRaises(ValueError):flow.add_path({'path':name})
        finally:flow.close();panel.close()
