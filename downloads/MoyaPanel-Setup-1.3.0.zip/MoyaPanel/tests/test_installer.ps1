# Run on Windows: powershell -NoProfile -File tests\test_installer.ps1
# No downloads/installations. Temporary fixture keys/files are removed in finally.
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$tokens = $null; $parseErrors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'install.ps1'), [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count) { throw ($parseErrors | Out-String) }
foreach ($name in @('Get-PythonInfo','Get-PythonCandidates','Find-CompatiblePython')) {
    $definition = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name }, $true)
    if (-not $definition) { throw "Missing installer function: $name" }
    Invoke-Expression $definition.Extent.Text
}
function Assert([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw $Message }
}
$fixture = Join-Path ([IO.Path]::GetTempPath()) ('moya-installer-' + [guid]::NewGuid().ToString('N'))
$tag = 'MoyaTest-' + [guid]::NewGuid().ToString('N')
$registryPath = 'Software\Python\PythonCore\' + $tag
$registry = $null
try {
    New-Item -ItemType Directory -Path $fixture | Out-Null
    $fake = Join-Path $fixture 'probe.cmd'
    $metadata = Join-Path $fixture 'metadata.json'
    # ASCII JSON matches CPython json.dumps defaults and works with all OEM code pages.
    $info = @{ version=@(3,13); bits=64; machine='AMD64'; implementation='cpython'; executable=$fake; release='final' }
    function Save-Metadata {
        $json = $info | ConvertTo-Json -Compress
        $json = [regex]::Replace($json, '[^\x00-\x7F]', { param($m) '\u{0:x4}' -f [int][char]$m.Value })
        Set-Content -LiteralPath $metadata -Value $json -Encoding Ascii
    }
    Save-Metadata
    Set-Content -LiteralPath $fake -Encoding Ascii -Value ("@echo off`r`ntype `"$metadata`"`r`nexit /b 0")
    Assert ([bool](Get-PythonInfo $fake)) 'A usable x64 release must be accepted'
    $info.version = @(3,11); Save-Metadata
    Assert ([bool](Get-PythonInfo $fake)) 'Installed Python 3.11 x64 must not be rejected'
    $info.bits = 32; Save-Metadata
    Assert (-not (Get-PythonInfo $fake)) 'An x86 interpreter must be rejected'
    $info.bits = 64; $info.version = @(3,14); Save-Metadata
    Assert (-not (Get-PythonInfo $fake)) 'Unsupported Python minor must be rejected'
    $info.version = @(3,13); $info.release = 'candidate'; Save-Metadata
    Assert (-not (Get-PythonInfo $fake)) 'Pre-release Python must be rejected'
    $info.release = 'final'; Save-Metadata
    # Simulate a standard-library load failure from a broken installation.
    Set-Content -LiteralPath $fake -Encoding Ascii -Value "@echo off`r`necho SSL load failed 1>&2`r`nexit /b 1"
    Assert (-not (Get-PythonInfo $fake)) 'A broken interpreter must be rejected'
    Set-Content -LiteralPath $fake -Encoding Ascii -Value ("@echo off`r`ntype `"$metadata`"`r`nexit /b 0")
    # An install outside .runtime must be discovered without a py.exe launcher.
    $registry = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($registryPath + '\InstallPath')
    $registry.SetValue('ExecutablePath', $fake)
    $registry.SetValue('', $fixture)
    $registry.Close(); $registry = $null
    $candidates = @(Get-PythonCandidates)
    Assert ($candidates -contains $fake) 'Registry installation outside .runtime was not discovered'
    $script:fakeCandidate = $fake
    function Get-PythonCandidates { return $script:fakeCandidate }
    Assert ((Find-CompatiblePython) -eq $fake) 'Discovery must return a verified custom install before invoking the launcher'
    Write-Host 'Installer regression checks passed (Windows fixture tests).'
} finally {
    if ($registry) { $registry.Close() }
    [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($registryPath, $false)
    Remove-Item -LiteralPath $fixture -Recurse -Force -ErrorAction SilentlyContinue
}
