import tempfile
import time
import unittest
from pathlib import Path
from key_jobs import KeyJobs


class KeyJobTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.script = Path(self.tmp.name)/'worker.py'
        self.jobs = KeyJobs(self.tmp.name, self.script)

    def tearDown(self):
        self.jobs.close()
        self.tmp.cleanup()

    def wait(self):
        deadline=time.monotonic()+5
        while self.jobs.snapshot()['running'] and time.monotonic()<deadline:
            time.sleep(.02)
        self.assertFalse(self.jobs.snapshot()['running'])

    def test_extract_result_and_redact_duplicate(self):
        self.script.write_text('print("[УСПІХ] Знайдено ключ: demo-secret")\nprint(\'[KEY] "demo-secret"\')\n',encoding='utf-8')
        self.jobs.start({'url':'https://example.com'})
        self.wait()
        state=self.jobs.snapshot()
        self.assertEqual(state['key'],'demo-secret')
        self.assertEqual(state['stage'],'succeeded')
        self.assertNotIn('demo-secret',str(state['lines']))

    def test_zero_exit_without_key_is_failure(self):
        self.script.write_text('print("no result")\n')
        self.jobs.start({'url':'https://example.com','mode':'key'})
        self.wait()
        self.assertEqual(self.jobs.snapshot()['stage'],'failed')

    def test_stop_and_no_double_start(self):
        self.script.write_text('import time\ntime.sleep(60)\n')
        self.jobs.start({'url':'https://example.com'})
        with self.assertRaises(ValueError):
            self.jobs.start({'url':'https://example.com'})
        self.jobs.stop()
        self.wait()
        self.assertEqual(self.jobs.snapshot()['stage'],'stopped')

    def test_invalid_url(self):
        for url in ['file:///etc/passwd','javascript:alert(1)','https://user:secret@example.com']:
            with self.assertRaises(ValueError):
                self.jobs.start({'url':url})


if __name__=='__main__':
    unittest.main()
