import json
import subprocess
import tempfile
import threading
import unittest
from http.client import HTTPConnection
from unittest.mock import patch
from http.server import ThreadingHTTPServer
from automation import Panel
import server

SERIAL = '127.0.0.1:16384'
PNG = b'\x89PNG\r\n\x1a\n' + b'fake-frame'


class FakeADB:
    def __init__(self):
        self.calls = []
        self.running = False
        self.present = True

    def __call__(self, cmd, **kwargs):
        self.calls.append(cmd)
        self.last_kwargs = kwargs
        out = b''
        if cmd[1:3] == ['devices', '-l']:
            out = ('List of devices attached\n' + (SERIAL+' device model:MuMu\n' if self.present else '') + 'phone device\n').encode()
        elif 'getprop' in cmd:
            out = b'1\n'
        elif cmd[-2:] == ['ps', '-A']:
            out = b'USER PID NAME\nu0 123 com.example.game\n' if self.running else b'USER PID NAME\n'
        elif 'resolve-activity' in cmd:
            out = b'com.example.game/.MainActivity\n'
        elif 'start' in cmd:
            self.running = True
            out = b'Status: ok\n'
        elif 'screencap' in cmd:
            out = PNG
        return subprocess.CompletedProcess(cmd, 0, out, b'')


class PanelTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.adb = FakeADB()
        self.panel = Panel(self.tmp.name, self.adb)
        self.panel.devices[SERIAL] = {'serial':SERIAL, 'state':'device', 'process':'unknown'}
        self.panel.mutate('config', {'name':'Test', 'package':'com.example.game', 'restart':True})

    def tearDown(self):
        self.panel.close()
        self.tmp.cleanup()

    def test_launch_preview_and_status(self):
        self.panel.inspect(SERIAL, True)
        self.assertEqual(self.panel.devices[SERIAL]['process'], 'running')
        self.assertEqual(self.panel.frames[SERIAL], PNG)
        self.assertEqual(self.panel.data['history'][0]['stage'], 'app_started')
        self.assertFalse(self.adb.last_kwargs['shell'])
        self.assertTrue(any(cmd[1:3] == ['-s', SERIAL] for cmd in self.adb.calls))

    def test_auto_restart_has_backoff(self):
        self.panel.mutate('settings', {'adb':'adb', 'ports':[], 'auto':True})
        self.panel.inspect(SERIAL)
        self.adb.running = False
        self.panel.inspect(SERIAL)
        self.assertEqual(sum('start' in c for c in self.adb.calls), 1)

    def test_disabled_account_prevents_automatic_launch(self):
        self.panel.mutate('settings', {'auto':True})
        self.panel.mutate('account', {'login':'one', 'serial':SERIAL, 'enabled':False})
        self.panel.inspect(SERIAL)
        self.assertFalse(any('start' in c for c in self.adb.calls))
        self.assertEqual(self.panel.snapshot()['accounts'][0]['status'], 'disabled')

    def test_resource_pressure_blocks_automatic_relaunch(self):
        self.panel.mutate('settings', {'auto':True})
        self.panel.resources={'pauseNewLaunches':True}
        self.panel.inspect(SERIAL)
        self.assertFalse(any('start' in c for c in self.adb.calls))

    def test_discovery_and_disconnection(self):
        with patch.object(self.panel, 'enqueue') as enqueue:
            self.panel.scan()
            enqueue.assert_called_once_with(SERIAL)
            self.assertNotIn('phone', self.panel.devices)
        self.panel.frames[SERIAL] = PNG
        self.adb.present = False
        self.panel.scan()
        self.assertFalse(self.panel.devices)
        self.assertFalse(self.panel.frames)

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            self.panel.mutate('config', {'name':'Bad','package':'com.game;reboot'})
        with self.assertRaises(ValueError):
            self.panel.mutate('settings', {'ports':[True]})
        with self.assertRaises(ValueError):
            self.panel.enqueue('unlisted', True)

    def test_password_stays_out_of_json_and_api(self):
        class Vault:
            def set_password(self, service, ident, value):
                self.value = value
            def get_password(self, service, ident):
                return self.value
        vault=Vault()
        with patch.object(self.panel,'vault', return_value=vault):
            self.panel.mutate('account', {'login':'one', 'serial':SERIAL, 'password':'TOPSECRET'})
            self.assertNotIn('TOPSECRET', self.panel.path.read_text())
            self.assertNotIn('TOPSECRET', json.dumps(self.panel.snapshot()))
            self.assertTrue(self.panel.snapshot()['accounts'][0]['hasPassword'])

    def test_http_origin_and_routes(self):
        server.panel = self.panel
        httpd = ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        old_port = server.PORT
        server.PORT = httpd.server_port
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        def request(method, path, headers=None, data=None):
            c=HTTPConnection('127.0.0.1',httpd.server_port)
            c.request(method,path,body=data,headers=headers or {})
            r=c.getresponse(); status=r.status; body=r.read(); c.close()
            return status,body
        try:
            self.assertEqual(request('GET','/api/status')[0],200)
            self.assertEqual(request('GET','/../panel_state.json')[0],404)
            self.assertEqual(request('GET','/',{'Host':'attacker.example'})[0],403)
            self.assertEqual(request('POST','/api/launch',data='{}')[0],403)
            self.assertEqual(request('POST','/api/launch',{'X-Panel':'1','Origin':'https://evil.example'},'{}')[0],403)
            self.assertEqual(request('POST','/api/config',{'X-Panel':'1'},'[]')[0],400)
            self.assertEqual(request('POST','/api/start',{'X-Panel':'1'},'{}')[0],404)
            self.assertEqual(request('GET','/api/frame?serial='+SERIAL)[0],404)
        finally:
            httpd.shutdown();httpd.server_close();thread.join();server.PORT=old_port


if __name__=='__main__':
    unittest.main()
