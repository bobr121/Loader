import json
import subprocess
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from performance import MuMuTuner, host_budget, instances_from_info, tune_android, restore_android


class NativeCLI:
    def __init__(self):
        self.values={'performance_mode':'high','performance_cpu.custom':'4',
                     'performance_mem.custom':'6','max_frame_rate':'60'}
        self.running=False
        self.fail_once=None
        self.calls=[]

    def __call__(self,cmd,**kwargs):
        self.calls.append(cmd)
        if cmd[1]=='setting':
            if '-aw' in cmd:
                output=json.dumps(self.values)
            else:
                key=cmd[cmd.index('-k')+1]
                value=cmd[cmd.index('-val')+1]
                if self.fail_once==key:
                    self.fail_once=None
                    raise RuntimeError('write rejected')
                self.values[key]=value
                output='ok'
        elif cmd[1]=='info':
            output=json.dumps({'0':{'index':0,'is_process_started':self.running,'is_android_started':self.running,'adb_port':16384}})
        else:
            self.running=cmd[-1]=='launch'
            output='ok'
        return subprocess.CompletedProcess(cmd,0,output.encode(),b'')


class PerformanceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        (self.root/'MuMuManager.exe').write_bytes(b'test')
        self.native=NativeCLI()
        self.tuner=MuMuTuner({'id':'test','name':'MuMu Player','root':str(self.root),
                             'path':str(self.root/'MuMuPlayer.exe')},self.root,self.native,
                            lambda:{'availableGB':16})
        self.profile={'cores':2,'guestGB':3,'fps':30}

    def tearDown(self):
        self.temp.cleanup()

    def test_conservative_budget(self):
        fake=SimpleNamespace(virtual_memory=lambda:SimpleNamespace(total=16*1024**3,available=12*1024**3),cpu_count=lambda **kw:12)
        with patch.dict('sys.modules',{'psutil':fake}):
            profile=host_budget()
        self.assertEqual(profile['estimatedInstances'],3)
        self.assertEqual(profile['guestGB'],3)
        self.assertEqual(profile['reserveGB'],4)

    def build_profile(self,total,physical,threads,gpus=None,cpu=0):
        fake=SimpleNamespace(virtual_memory=lambda:SimpleNamespace(total=total*1024**3,available=total*.8*1024**3),
                             cpu_count=lambda logical=True:threads if logical else physical,cpu_percent=lambda **kw:cpu)
        with patch.dict('sys.modules',{'psutil':fake}),patch('performance.hardware_info',return_value={'cpuName':'test CPU','gpus':gpus or []}):
            return host_budget()

    def test_profiles_change_with_hardware(self):
        weak=self.build_profile(8,2,4)
        middle=self.build_profile(16,6,12)
        strong=self.build_profile(64,16,32,['NVIDIA RTX'])
        self.assertEqual((weak['guestGB'],weak['fps'],weak['resolution']),(2,20,'800x450'))
        self.assertEqual((middle['guestGB'],middle['cores'],middle['fps']),(3,2,25))
        self.assertEqual((strong['guestGB'],strong['cores'],strong['fps']),(4,3,30))
        self.assertGreater(strong['estimatedInstances'],middle['estimatedInstances'])

    def test_integrated_gpu_lowers_display_workload(self):
        profile=self.build_profile(32,8,16,['Intel(R) UHD Graphics'])
        self.assertEqual(profile['fps'],20)
        self.assertEqual(profile['resolution'],'800x450')
        self.assertEqual(profile['guestGB'],4)

    def test_heavy_host_load_lowers_display_target(self):
        profile=self.build_profile(32,8,16,['NVIDIA RTX'],cpu=87)
        self.assertEqual(profile['fps'],20)
        self.assertEqual(profile['resolution'],'800x450')

    def test_false_strings_are_not_running(self):
        result=instances_from_info({'0':{'is_process_started':'false','is_android_started':'false','adb_port':'16384'}})
        self.assertFalse(result[0]['running'])
        self.assertEqual(result[0]['port'],16384)

    def test_apply_creates_original_backup_and_verifies(self):
        original=dict(self.native.values)
        self.tuner.apply({'index':0,'running':False},self.profile,threading.Event())
        self.assertEqual(self.native.values['performance_mem.custom'],'3')
        path=self.root/'tuning_backups/test/instance_0.json'
        self.assertEqual(json.loads(path.read_text())['values'],original)
        self.tuner.apply({'index':0,'running':True},self.profile,threading.Event())
        self.assertEqual(json.loads(path.read_text())['values'],original)

    def test_partial_failure_rolls_back(self):
        original=dict(self.native.values)
        self.native.fail_once='performance_mem.custom'
        with self.assertRaisesRegex(RuntimeError,'повернено'):
            self.tuner.apply({'index':0,'running':False},self.profile,threading.Event())
        self.assertEqual(self.native.values,original)

    def test_missing_supported_key_does_not_write(self):
        del self.native.values['max_frame_rate']
        with self.assertRaisesRegex(RuntimeError,'не підтримує'):
            self.tuner.apply({'index':0,'running':False},self.profile,threading.Event())
        self.assertFalse(any('-k' in cmd for cmd in self.native.calls))

    def test_low_memory_blocks_new_instance(self):
        self.tuner.budget=lambda:{'availableGB':3}
        with self.assertRaisesRegex(RuntimeError,'Мало вільної RAM'):
            self.tuner.apply({'index':0,'running':False},self.profile,threading.Event())
        self.assertFalse(any('launch' in cmd for cmd in self.native.calls))

    def test_cpu_overload_blocks_new_instance_before_changes(self):
        self.tuner.budget=lambda:{'availableGB':16,'cpuPercent':99}
        original=dict(self.native.values)
        with self.assertRaisesRegex(RuntimeError,'CPU вже перевантажений'):
            self.tuner.apply({'index':0,'running':False},self.profile,threading.Event())
        self.assertEqual(self.native.values,original)
        self.assertFalse(self.native.calls)

    def test_restore_native_settings(self):
        original=dict(self.native.values)
        self.tuner.apply({'index':0,'running':False},self.profile,threading.Event())
        self.tuner.restore(threading.Event())
        self.assertEqual(self.native.values,original)

    def test_android_overrides_restore(self):
        class Android:
            def __init__(self):
                self.values={};self.size=None;self.density=None
            def adb(self,*args,**kwargs):
                if args[1]=='settings':
                    key=args[4]
                    if args[2]=='get':return self.values.get(key,'1').encode()
                    if args[2]=='put':self.values[key]=args[5]
                elif args[1]=='wm':
                    attr=args[2]
                    if len(args)>3:setattr(self,attr,None if args[3]=='reset' else args[3])
                    original='1080x1920' if attr=='size' else '480'
                    value=getattr(self,attr)
                    return ('Physical '+attr+': '+original+('\nOverride '+attr+': '+value if value else '')).encode()
                return b''
        panel=Android()
        tune_android(panel,'127.0.0.1:16384',self.root,'test')
        self.assertEqual(panel.size,'960x540')
        restore_android(panel,'127.0.0.1:16384',self.root,'test')
        self.assertIsNone(panel.size)
        self.assertIsNone(panel.density)
        self.assertTrue(all(v=='1' for v in panel.values.values()))
        tune_android(panel,'127.0.0.1:16384',self.root,'test',profile={'resolution':'800x450','density':160})
        self.assertEqual(panel.size,'800x450')
        restore_android(panel,'127.0.0.1:16384',self.root,'test')
        self.assertIsNone(panel.size)
