"""Local server for "Моя панель": serves the UI and runs key_system.py on request.

Listens on 127.0.0.1 only and exits on its own after the window has been closed for a while.
"""
import importlib.metadata as md
import json
import os
import subprocess
import sys
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, "app")
SCRIPT = os.path.join(HERE, "key_system.py")
PORT = 8777
IDLE_EXIT = 45  # seconds without the window polling
MAX_LINES = 1000
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# pythonw has no console, so keep output in a file
_log = open(os.path.join(HERE, "server.log"), "a", encoding="utf-8", buffering=1)
sys.stdout = sys.stderr = _log

MSG = {
    "uk": {"start": "▶ Запуск скрипта: {url}", "exit": "■ Скрипт завершився (код {code})", "stop": "■ Зупинено вручну",
           "busy": "Скрипт уже працює", "badurl": "Посилання має починатися з http:// або https://",
           "nopw": "Playwright не встановлено"},
    "en": {"start": "▶ Starting script: {url}", "exit": "■ Script finished (code {code})", "stop": "■ Stopped manually",
           "busy": "The script is already running", "badurl": "The link must start with http:// or https://",
           "nopw": "Playwright is not installed"},
    "ru": {"start": "▶ Запуск скрипта: {url}", "exit": "■ Скрипт завершился (код {code})", "stop": "■ Остановлено вручную",
           "busy": "Скрипт уже работает", "badurl": "Ссылка должна начинаться с http:// или https://",
           "nopw": "Playwright не установлен"},
}


def child_python():
    folder, name = os.path.split(sys.executable)
    if name.lower() == "pythonw.exe":
        console = os.path.join(folder, "python.exe")
        if os.path.exists(console):
            return console
    return sys.executable


def env_info():
    info = {"python": sys.version.split()[0]}
    try:
        info["playwright"] = md.version("playwright")
    except md.PackageNotFoundError:
        info["playwright"] = None
    root = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ms-playwright")
    info["chromium"] = os.path.isdir(root) and any(n.startswith("chromium") for n in os.listdir(root))
    return info


KEYS_FILE = os.path.join(HERE, "keys.json")


def load_keys():
    try:
        with open(KEYS_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def save_keys(keys):
    try:
        with open(KEYS_FILE, "w", encoding="utf-8") as f:
            json.dump(keys, f, ensure_ascii=False, indent=1)
    except OSError:
        pass


class State:
    keys = load_keys()  # newest first
    lock = threading.Lock()
    lines = []
    base = 0
    proc = None
    started = 0
    exit_code = None
    stopping = False
    url = ""
    last_seen = time.time()
    env = env_info()


def add(text, kind=""):
    with State.lock:
        State.lines.append({"i": State.base + len(State.lines), "ts": int(time.time() * 1000), "text": text, "kind": kind})
        if len(State.lines) > MAX_LINES:
            drop = len(State.lines) - MAX_LINES
            State.lines = State.lines[drop:]
            State.base += drop


def kind_of(line):
    s = line.lstrip()
    if s.startswith("[+]"):
        return "ok"
    if s.startswith("[!]"):
        return "warn"
    if s.startswith("[-]") or s.startswith("Traceback") or "Error" in s:
        return "bad"
    return ""


def reader(proc, lang):
    for raw in proc.stdout:
        line = raw.rstrip("\r\n")
        if line.startswith("[KEY] "):
            try:
                value = str(json.loads(line[6:]))
            except ValueError:
                value = line[6:]
            with State.lock:
                State.keys.insert(0, {"value": value, "ts": int(time.time() * 1000), "url": State.url})
                del State.keys[20:]
                keys = list(State.keys)
            save_keys(keys)
            continue
        if line:
            add(line, kind_of(line))
    code = proc.wait()
    with State.lock:
        manual = State.stopping
        if State.proc is proc:
            State.proc = None
            State.exit_code = code
            State.stopping = False
    if not manual:
        add(MSG[lang]["exit"].format(code=code), "ok" if code == 0 else "bad")


def clamp(v, lo, hi, default):
    try:
        return max(lo, min(hi, int(v)))
    except (TypeError, ValueError):
        return default


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=APP, **kwargs)

    def log_message(self, *args):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        State.last_seen = time.time()
        url = urlparse(self.path)
        if url.path == "/api/ping":
            return self.send_json({"ok": True, "app": "moyapanel"})
        if url.path == "/api/status":
            try:
                since = int(parse_qs(url.query).get("since", ["0"])[0])
            except ValueError:
                since = 0
            with State.lock:
                total = State.base + len(State.lines)
                reset = since > total
                start = 0 if reset else max(0, since - State.base)
                data = {
                    "running": State.proc is not None,
                    "pid": State.proc.pid if State.proc else None,
                    "startedAt": State.started if State.proc else 0,
                    "exitCode": State.exit_code,
                    "lines": State.lines[start:],
                    "next": total,
                    "reset": reset,
                    "env": State.env,
                    "key": State.keys[0] if State.keys else None,
                    "keys": State.keys[:10],
                }
            return self.send_json(data)
        return super().do_GET()

    def do_POST(self):
        State.last_seen = time.time()
        # A custom header blocks other websites from calling this server
        if self.headers.get("X-Panel") != "1":
            return self.send_json({"ok": False, "error": "forbidden"}, 403)
        length = int(self.headers.get("Content-Length") or 0)
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
        except ValueError:
            data = {}
        lang = data.get("lang") if data.get("lang") in MSG else "uk"
        path = urlparse(self.path).path

        if path == "/api/start":
            url = str(data.get("url", "")).strip()
            if not url.lower().startswith(("http://", "https://")):
                return self.send_json({"ok": False, "error": MSG[lang]["badurl"]})
            State.env = env_info()
            if not State.env["playwright"]:
                return self.send_json({"ok": False, "error": MSG[lang]["nopw"]})
            cfg = data.get("config") or {}
            args = {
                "url": url,
                "mode": "key" if data.get("mode") == "key" else "full",
                "keyWait": clamp(cfg.get("keyWait"), 1, 300, 20),
                "copyKey": bool(cfg.get("copyKey", True)),
                "showBrowser": bool(cfg.get("showBrowser", True)),
                "closePopups": bool(cfg.get("closePopups", True)),
                "continueWait": clamp(cfg.get("continueWait"), 1, 600, 20),
                "claimWait": clamp(cfg.get("claimWait"), 2, 1800, 180),
                "finalWait": clamp(cfg.get("finalWait"), 0, 600, 15),
            }
            with State.lock:
                if State.proc is not None:
                    return self.send_json({"ok": False, "error": MSG[lang]["busy"]})
            State.url = url
            add(MSG[lang]["start"].format(url=url))
            env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
            proc = subprocess.Popen(
                [child_python(), "-u", SCRIPT, json.dumps(args, ensure_ascii=False)],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                text=True, encoding="utf-8", errors="replace",
                cwd=HERE, env=env, creationflags=NO_WINDOW,
            )
            with State.lock:
                State.proc, State.started, State.exit_code, State.stopping = proc, int(time.time() * 1000), None, False
            threading.Thread(target=reader, args=(proc, lang), daemon=True).start()
            return self.send_json({"ok": True, "pid": proc.pid})

        if path == "/api/stop":
            with State.lock:
                proc = State.proc
                if proc:
                    State.stopping = True
            if proc:
                subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                               capture_output=True, creationflags=NO_WINDOW)
                add(MSG[lang]["stop"], "warn")
            return self.send_json({"ok": True})

        if path == "/api/clear":
            with State.lock:
                State.base += len(State.lines)
                State.lines = []
            return self.send_json({"ok": True})

        return self.send_json({"ok": False, "error": "not found"}, 404)


def watchdog(server):
    while True:
        time.sleep(5)
        with State.lock:
            running = State.proc is not None
        if not running and time.time() - State.last_seen > IDLE_EXIT:
            server.shutdown()
            return


def main():
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        return  # already running
    threading.Thread(target=watchdog, args=(server,), daemon=True).start()
    server.serve_forever()


if __name__ == "__main__":
    main()
