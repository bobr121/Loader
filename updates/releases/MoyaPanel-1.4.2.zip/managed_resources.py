"""Close only emulator instances/process trees launched by this panel session."""
import threading
import os


class ManagedResources:
    def __init__(self):
        self.lock=threading.RLock()
        self.native={}
        self.processes={}

    def native_launch(self, item, tuner, index):
        with self.lock:
            self.native[(item['id'],str(index))]=(dict(item),tuner,index)

    def process_launch(self, process):
        # Capture identities now: PID alone can later belong to another program.
        try:
            import psutil
            parent=psutil.Process(process.pid)
            members=[parent]+parent.children(recursive=True)
            entries=[(p.pid,p.create_time()) for p in members]
            with self.lock:
                self.processes.update(entries)
        except Exception:
            # Do not invent ownership if process identity cannot be read.
            with self.lock:
                self.processes[('unverified',id(process))]=None

    def snapshot(self):
        with self.lock:
            return {'native':[{'emulator':i['name'],'index':n} for i,t,n in self.native.values()],
                    'processCount':len(self.processes)}

    def close_all(self):
        errors=[]
        with self.lock:
            native=list(self.native.items())
            processes=list(self.processes.items())
        # CLI shutdown targets the exact instance, never quitall or image-name taskkill.
        for token,(item,tuner,index) in native:
            try:
                current=next((v for v in tuner.instances() if str(v['index'])==str(index)),None)
                if current and current['running']:
                    tuner.stop_instance(index,threading.Event())
                with self.lock: self.native.pop(token,None)
            except Exception:
                errors.append(item['name']+' #'+str(index)+': зупинку не підтверджено')
        if processes:
            try:
                import psutil
                selected=[]
                identities={}
                for pid,created in processes:
                    if not isinstance(pid,int) or created is None:
                        errors.append('Не підтверджено власника процесу; автоматично не закрито')
                        continue
                    try:
                        p=psutil.Process(pid)
                        if abs(p.create_time()-created)>.001:
                            with self.lock: self.processes.pop(pid,None)
                            continue
                        # Descendants currently attached to our exact process are also owned.
                        for child in p.children(recursive=True)+[p]:
                            identities[child.pid]=child.create_time()
                    except psutil.NoSuchProcess:
                        with self.lock: self.processes.pop(pid,None)
                for pid,created in identities.items():
                    try:
                        p=psutil.Process(pid)
                        if abs(p.create_time()-created)<.001:
                            if os.name == 'nt':
                                self.close_windows(p.pid)
                            else:
                                p.terminate()
                            selected.append(p)
                    except psutil.NoSuchProcess:
                        pass
                gone,alive=psutil.wait_procs(selected,timeout=8)
                for p in alive:
                    try:
                        if abs(p.create_time()-identities[p.pid])<.001: p.terminate()
                    except psutil.NoSuchProcess:
                        pass
                _,alive=psutil.wait_procs(alive,timeout=5)
                for p in alive:
                    try:
                        if abs(p.create_time()-identities[p.pid])<.001: p.kill()
                    except psutil.NoSuchProcess:
                        pass
                _,alive=psutil.wait_procs(alive,timeout=5)
                if alive: errors.append('Деякі керовані процеси не завершилися')
                with self.lock:
                    for pid,created in processes:
                        if isinstance(pid,int) and pid not in {p.pid for p in alive}: self.processes.pop(pid,None)
            except Exception:
                errors.append('Не вдалося перевірити/закрити керовані процеси')
        return errors

    @staticmethod
    def close_windows(pid):
        import ctypes
        from ctypes import wintypes
        user32=ctypes.windll.user32
        callback=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
        user32.EnumWindows.argtypes=[callback,wintypes.LPARAM]
        user32.EnumWindows.restype=wintypes.BOOL
        user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype=wintypes.DWORD
        user32.PostMessageW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
        user32.PostMessageW.restype=wintypes.BOOL
        @callback
        def visit(hwnd,param):
            owner=wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd,ctypes.byref(owner))
            if owner.value==pid:
                user32.PostMessageW(hwnd,0x0010,0,0)  # WM_CLOSE
            return True
        user32.EnumWindows(visit,0)
