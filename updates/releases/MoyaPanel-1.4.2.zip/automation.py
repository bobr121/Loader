"""Bounded ADB monitoring. No browser bypass, injection or password typing."""
import copy
import io
import json
import os
import re
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

PACKAGE = re.compile(r'[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+')
NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


class Panel:
    def __init__(self, directory, runner=subprocess.run):
        self.path = Path(directory) / 'panel_state.json'
        self.runner = runner
        self.lock = threading.RLock()
        self.halt = threading.Event()
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix='adb')
        self.devices = {}
        self.allowed_serials = None
        self.suspended = False
        self.controlled_apps = {}
        self.recovery_serials = set()
        self.adb_active = 0
        self.adb_idle = threading.Event()
        self.adb_idle.set()
        self.frames = {}
        self.busy = set()
        self.retry = {}
        self.error = ''
        self.resources = {}
        self.high_cpu_ticks = 0
        self.thread = None
        bundled_adb = Path(directory) / 'tools' / 'platform-tools' / 'adb.exe'
        default_adb = str(bundled_adb.resolve()) if bundled_adb.is_file() else 'adb'
        self.data = {'settings': {'adb': default_adb, 'ports': [], 'auto': False},
                     'configs': [{'id': 'default', 'name': 'Основний', 'package': '', 'restart': False}],
                     'active': 'default', 'accounts': [], 'history': []}
        if self.path.exists():
            try:
                self.data = json.loads(self.path.read_text(encoding='utf-8'))
            except (OSError, ValueError) as e:
                raise RuntimeError('Cannot read panel_state.json; restore it from backup') from e
        self.suspended = bool(self.data.get('runtimePaused', False))
        if bundled_adb.is_file() and self.data['settings'].get('adb') == 'adb':
            self.data['settings']['adb'] = default_adb

    def save(self):
        # Caller holds lock; replace is atomic on a single filesystem.
        temp = self.path.with_suffix('.tmp')
        temp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temp, self.path)

    def event(self, serial, stage, detail=''):
        with self.lock:
            self.data['history'].insert(0, {'time': int(time.time()*1000), 'serial': serial,
                                          'stage': stage, 'detail': detail[:500]})
            del self.data['history'][100:]
            self.save()

    def adb(self, *args, serial=None, timeout=8, allow_suspended=False):
        with self.lock:
            if self.suspended and not allow_suspended:
                raise RuntimeError('Роботу припинено; натисніть Відновити роботу')
            executable = self.data['settings']['adb']
            self.adb_active += 1
            self.adb_idle.clear()
        try:
            cmd = [executable] + (['-s', serial] if serial else []) + list(args)
            result = self.runner(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 timeout=timeout, creationflags=NO_WINDOW, shell=False)
            if result.returncode:
                raise RuntimeError(result.stderr.decode('utf-8', 'replace').strip()[:300] or 'ADB command failed')
            return result.stdout
        finally:
            with self.lock:
                self.adb_active -= 1
                if not self.adb_active: self.adb_idle.set()

    @staticmethod
    def local_serial(serial):
        return bool(re.fullmatch(r'(?:127\.0\.0\.1|localhost):[0-9]{1,5}', serial)
                    or re.fullmatch(r'emulator-[0-9]+', serial))

    def scan(self):
        with self.lock:
            ports = list(self.data['settings']['ports'])
        for port in ports:
            try:
                self.adb('connect', f'127.0.0.1:{port}')
            except (OSError, RuntimeError, subprocess.TimeoutExpired):
                pass
        raw = self.adb('devices', '-l').decode('utf-8', 'replace')
        found = {}
        for line in raw.splitlines():
            parts = line.split()
            if len(parts) < 2 or not self.local_serial(parts[0]):
                continue
            serial, state = parts[:2]
            found[serial] = {'serial': serial, 'state': state, 'process': 'unknown',
                             'login': 'unverified', 'checked': 0, 'frameAt': 0, 'error': ''}
        with self.lock:
            if self.suspended: return
            for serial, device in found.items():
                previous = self.devices.get(serial)
                if previous and previous['state'] == device['state']:
                    found[serial] = previous
                elif device['state'] == 'device':
                    self.retry.pop(serial, None)
            for serial, device in found.items():
                if device['state'] != 'device':
                    self.frames.pop(serial, None)
            for serial in set(self.devices) - set(found):
                self.frames.pop(serial, None)
                self.retry.pop(serial, None)
            self.devices = found
            self.error = ''
        for serial, device in found.items():
            if device['state'] == 'device':
                self.enqueue(serial)

    def enqueue(self, serial, launch=False):
        with self.lock:
            if self.suspended:
                if launch: raise ValueError('Роботу припинено')
                return
            if serial not in self.devices or self.devices[serial]['state'] != 'device':
                raise ValueError('Сесію не підключено через ADB')
            if serial in self.busy:
                if launch:
                    raise ValueError('Сесія зайнята; повторіть після оновлення прев’ю')
                return
            self.busy.add(serial)
        self.pool.submit(self.inspect, serial, launch)

    def inspect(self, serial, launch=False):
        try:
            with self.lock:
                if self.suspended: return
                account = next((a for a in self.data['accounts'] if a['serial'] == serial), None)
                config_id = account.get('configId', self.data['active']) if account else self.data['active']
                cfg = copy.deepcopy(next(c for c in self.data['configs'] if c['id'] == config_id))
                auto = self.data['settings']['auto']
                if self.resources.get('pauseNewLaunches'):
                    auto = False
                if self.allowed_serials is not None and serial not in self.allowed_serials:
                    auto = False
                bound = [a for a in self.data['accounts'] if a['serial'] == serial]
                if self.controlled_apps.get(serial)=='com.roblox.client' and any(a['enabled'] for a in bound):
                    auto = False  # The watchdog owns complete login/game/key/script recovery.
                if bound and not any(a['enabled'] for a in bound):
                    auto = False
            # ADB connection alone is not evidence of completed boot.
            booted = self.adb('shell', 'getprop', 'sys.boot_completed', serial=serial).strip() == b'1'
            if not booted:
                with self.lock:
                    if serial in self.devices:
                        self.devices[serial].update(process='booting', checked=int(time.time()*1000))
                return
            package = cfg['package']
            running = False
            if package:
                # pidof returns code 1 for an absent process; use shell output with fixed, validated package.
                output = self.adb('shell', 'ps', '-A', serial=serial).decode('utf-8', 'replace')
                running = any(line.split() and line.split()[-1] == package for line in output.splitlines())
                with self.lock:
                    first_attempt = serial not in self.retry
                    retry_due = time.monotonic() >= self.retry.get(serial, 0)
                should_launch = launch or (auto and not running and retry_due and (first_attempt or cfg['restart']))
                if should_launch:
                    with self.lock:
                        self.retry[serial] = time.monotonic() + 60
                    self.launch_package(serial, package)
                    output = self.adb('shell', 'ps', '-A', serial=serial).decode('utf-8', 'replace')
                    running = any(line.split() and line.split()[-1] == package for line in output.splitlines())
            with self.lock:
                last_frame=self.devices.get(serial,{}).get('frameAt',0)
            if int(time.time()*1000)-last_frame < 8000:
                with self.lock:
                    if serial in self.devices:
                        self.devices[serial].update(process=('running' if running else 'stopped') if package else 'not_configured',
                                                    checked=int(time.time()*1000),error='')
                return
            png = self.adb('exec-out', 'screencap', '-p', serial=serial)
            if not png.startswith(b'\x89PNG\r\n\x1a\n'):
                raise RuntimeError('ADB не повернув PNG')
            try:
                from PIL import Image
                with Image.open(io.BytesIO(png)) as picture:
                    picture.thumbnail((640,360))
                    buffer=io.BytesIO()
                    picture.save(buffer,format='PNG')
                    png=buffer.getvalue()
            except (ImportError,OSError,ValueError):
                pass
            now = int(time.time()*1000)
            with self.lock:
                if serial in self.devices:
                    self.frames[serial] = png
                    self.devices[serial].update(process=('running' if running else 'stopped') if package else 'not_configured',
                                                checked=now, frameAt=now, error='')
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as e:
            with self.lock:
                if serial in self.devices:
                    self.devices[serial].update(error=str(e)[:300], process='error', checked=int(time.time()*1000))
            # Avoid flooding persistent history on each monitor tick.
            if launch:
                self.event(serial, 'error', str(e))
        finally:
            with self.lock:
                self.busy.discard(serial)

    def launch_package(self, serial, package):
        if not self.local_serial(serial) or not PACKAGE.fullmatch(package):
            raise ValueError('Некоректний serial або package')
        component = self.adb('shell', 'cmd', 'package', 'resolve-activity', '--brief',
                             '-a', 'android.intent.action.MAIN', '-c', 'android.intent.category.LAUNCHER',
                             package, serial=serial).decode('utf-8', 'replace').strip().splitlines()
        component = component[-1] if component else ''
        if not re.fullmatch(r'[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+', component):
            raise RuntimeError('Немає launcher activity: перевірте package та встановлення додатка')
        result = self.adb('shell', 'am', 'start', '-W', '-n', component, serial=serial).decode('utf-8', 'replace')
        if 'Error' in result or 'Exception' in result:
            raise RuntimeError(result[:300])
        output = self.adb('shell', 'ps', '-A', serial=serial).decode('utf-8', 'replace')
        if not any(line.split() and line.split()[-1] == package for line in output.splitlines()):
            raise RuntimeError('Команда запуску виконана, але процес '+package+' не з’явився')
        with self.lock:
            self.controlled_apps[serial] = package
        self.event(serial, 'app_started', package)

    def snapshot(self):
        with self.lock:
            accounts = []
            for account in self.data['accounts']:
                device = self.devices.get(account['serial'])
                status = 'disabled' if not account['enabled'] else ('offline' if not device or device['state'] != 'device'
                         else device['process'])
                accounts.append(dict(account, status=status, loginState='unverified', hasPassword=self.has_secret(account['id'])))
            return {'suspended': self.suspended, 'settings': copy.deepcopy(self.data['settings']), 'configs': copy.deepcopy(self.data['configs']),
                    'active': self.data['active'], 'accounts': accounts, 'devices': copy.deepcopy(list(self.devices.values())),
                    'history': copy.deepcopy(self.data['history']), 'error': self.error,
                    'resources':copy.deepcopy(self.resources)}

    @staticmethod
    def vault():
        # Fail closed: never use plaintext fallback backends.
        import keyring
        backend = keyring.get_keyring()
        if os.name != 'nt' or not type(backend).__module__.startswith('keyring.backends.Windows'):
            raise ValueError('Паролі потребують Windows Credential Manager: pip install keyring')
        return keyring

    def has_secret(self, account_id):
        try:
            return bool(self.vault().get_password('MoyaPanel', account_id))
        except Exception:
            return False

    def mutate(self, action, body):
        with self.lock:
            if action == 'settings':
                adb = str(body.get('adb', 'adb')).strip()
                ports = body.get('ports', [])
                if not adb or len(adb) > 1024 or not isinstance(ports, list) or len(ports) > 16:
                    raise ValueError('Некоректний шлях ADB або список портів (до 16)')
                if any(type(p) is not int or not 1 <= p <= 65535 for p in ports):
                    raise ValueError('ADB порти: цілі числа 1–65535')
                self.data['settings'] = {'adb': adb, 'ports': sorted(set(ports)), 'auto': bool(body.get('auto'))}
                self.retry.clear()
            elif action == 'config':
                name, package = str(body.get('name', '')).strip(), str(body.get('package', '')).strip()
                if not name or len(name) > 100 or (package and not PACKAGE.fullmatch(package)):
                    raise ValueError('Вкажіть назву та коректний Android package')
                ident = body.get('id') or uuid.uuid4().hex
                old = next((c for c in self.data['configs'] if c['id'] == ident), None)
                script = body.get('luaScript', '')
                if not isinstance(script, str) or len(script.encode('utf-8')) > 32768 or '\0' in script:
                    raise ValueError('Lua-скрипт має бути текстом до 32 КіБ без NUL')
                config = {'luaScript': script, 'executorAutoInject': bool(body.get('executorAutoInject', False)), 'id': ident, 'name': name, 'package': package, 'restart': bool(body.get('restart'))}
                if old:
                    old.update(config)
                else:
                    self.data['configs'].append(config)
                self.data['active'] = ident
                self.retry.clear()
            elif action == 'activate':
                if body.get('id') not in [c['id'] for c in self.data['configs']]:
                    raise ValueError('Конфіг не знайдено')
                self.data['active'] = body['id']
                self.retry.clear()
            elif action == 'account':
                login, serial = str(body.get('login', '')).strip(), str(body.get('serial', '')).strip()
                if not login or len(login) > 200 or (serial and not self.local_serial(serial)):
                    raise ValueError('Потрібен логін; необов’язковий serial має бути локальним ADB serial')
                ident = body.get('id') or uuid.uuid4().hex
                old = next((a for a in self.data['accounts'] if a['id'] == ident), None)
                if old is None and body.get('id'):
                    raise ValueError('Акаунт не знайдено')
                from android_setup import place_id
                game = place_id(body.get('placeId', old.get('placeId', '') if old else ''))
                if serial and any(a['serial'] == serial and a['id'] != ident for a in self.data['accounts']):
                    raise ValueError('Цей інстанс уже прив’язаний до іншого акаунта')
                password = body.get('password', '')
                if password:
                    self.vault().set_password('MoyaPanel', ident, str(password))
                account = {'id': ident, 'login': login, 'serial': serial, 'placeId': game, 'enabled': bool(body.get('enabled', True))}
                if old:
                    old.update(account)
                else:
                    self.data['accounts'].append(account)
            elif action == 'delete_account':
                ident = body.get('id')
                if self.has_secret(ident):
                    self.vault().delete_password('MoyaPanel', ident)
                self.data['accounts'] = [a for a in self.data['accounts'] if a['id'] != ident]
            else:
                raise ValueError('Невідома дія')
            self.save()
        return {'ok': True}

    def sample_resources(self):
        try:
            import psutil
            memory=psutil.virtual_memory()
            cpu=psutil.cpu_percent(interval=None)
            self.high_cpu_ticks = self.high_cpu_ticks+1 if cpu>92 else 0
            low=memory.available < 2*1024**3
            pressure=low or self.high_cpu_ticks>=3
            with self.lock:
                self.resources={'availableGB':round(memory.available/1024**3,1),'cpuPercent':cpu,
                                'pauseNewLaunches':pressure,
                                'message':('Мало вільної RAM: нові автозапуски призупинено.' if low else
                                           'CPU тривало перевантажений: нові автозапуски призупинено.' if pressure else '')}
        except ImportError:
            pass

    def loop(self):
        while not self.halt.is_set():
            try:
                if self.suspended:
                    self.halt.wait(.5)
                    continue
                self.sample_resources()
                self.scan()
            except (OSError, RuntimeError, subprocess.TimeoutExpired) as e:
                with self.lock:
                    self.error = str(e)[:300]
                    self.devices.clear()
                    self.frames.clear()
            self.halt.wait(3)

    def start(self):
        self.thread = threading.Thread(target=self.loop, daemon=True, name='monitor')
        self.thread.start()

    def close(self):
        self.halt.set()
        if self.thread:
            self.thread.join(timeout=10)
        self.pool.shutdown(wait=True, cancel_futures=True)
