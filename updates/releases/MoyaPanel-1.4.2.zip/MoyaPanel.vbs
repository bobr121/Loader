Option Explicit
Dim shell, fso, root, python, desktop
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
python = fso.BuildPath(root, ".venv\Scripts\pythonw.exe")
desktop = fso.BuildPath(root, "bootstrap.py")
shell.CurrentDirectory = root
If fso.FileExists(python) Then
  shell.Run Chr(34) & python & Chr(34) & " " & Chr(34) & desktop & Chr(34), 0, False
Else
  shell.Run "cmd.exe /c " & Chr(34) & Chr(34) & fso.BuildPath(root, "Install.bat") & Chr(34) & Chr(34), 1, False
End If
