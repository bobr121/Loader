"""Native Windows application window. No browser tab or external browser launcher."""
import ctypes
import logging
import os
import sys
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(webview_module=None):
    if webview_module is None:
        import webview as webview_module
    import server
    from automation import Panel
    from key_jobs import KeyJobs
    from emulators import EmulatorFlow
    # Bind a fresh port: never accidentally attach to an older copy on 8777.
    httpd = ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
    httpd.daemon_threads = True
    server.PORT = httpd.server_port
    worker = None
    try:
        server.panel = Panel(HERE)
        server.key_jobs = KeyJobs(HERE)
        server.emulator_flow = EmulatorFlow(server.panel)
        from control_center import ControlCenter
        server.control_center = ControlCenter(server.panel,server.emulator_flow,server.key_jobs)
        from recovery import RecoveryWatchdog
        server.recovery = RecoveryWatchdog(server.panel,server.emulator_flow)
        server.panel.start()
        server.emulator_flow.refresh()
        server.recovery.start()
        from updater import UpdateManager
        server.updates = UpdateManager(HERE)
        server.updates.start()
        worker = threading.Thread(target=httpd.serve_forever, daemon=True, name='local-api')
        worker.start()
        window = webview_module.create_window('MoyaPanel · Desktop', f'http://127.0.0.1:{server.PORT}',
                                     width=1280, height=850, min_size=(850, 620),
                                     background_color='#0c1018', text_select=True)
        if window is not None:
            window.events.loaded += server.updates.window_ready
            server.updates.restart_callback = lambda: window.destroy()
        # Force modern WebView2; never fall back to old Internet Explorer.
        webview_module.start(gui='edgechromium', debug=False)
    finally:
        if worker:
            httpd.shutdown()
            worker.join(timeout=5)
        httpd.server_close()
        if server.updates:
            server.updates.close()
        if server.recovery:
            server.recovery.close()
        if server.control_center:
            server.control_center.close()
        if server.emulator_flow:
            server.emulator_flow.close()
        if server.key_jobs:
            server.key_jobs.close()
        if server.panel:
            server.panel.close()
    return bool(server.updates and server.updates.restart)


if __name__ == '__main__':
    from bootstrap import main
    sys.exit(main())
