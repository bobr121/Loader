"""Small Windows EXE entry point built by Install.bat; uses the local venv."""
import ctypes
import subprocess
import sys
from pathlib import Path


def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    python = root / '.venv' / 'Scripts' / 'pythonw.exe'
    desktop = root / 'bootstrap.py'
    if not python.is_file() or not desktop.is_file():
        ctypes.windll.user32.MessageBoxW(None, 'Спочатку запустіть Install.bat у цій папці.', 'MoyaPanel', 0x10)
        return 1
    subprocess.Popen([str(python), str(desktop)], cwd=str(root),
                     creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
