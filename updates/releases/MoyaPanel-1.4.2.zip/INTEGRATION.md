1.3: immutable bootstrap.py + pinned update_config.json, updater.py stages signed
source archives. Snapshot.updates: stage/detail/version. POST update_healthy commits
trial after WebView event + successful frontend render. POST update_restart requires
fully stopped desktop. Raw CDN feed; jitter 10-90 sec first, 5-7 h thereafter.
Publisher tooling/key are OUTSIDE the public client tree. Publish manifest LAST.
Source writes are journaled with rollback; dependencies get side-by-side venv.
Any update protocol/bootstrap changes require explicit bootstrap migration.

1.2: discover(on_found=None,budget_seconds=8) probes known files instead of walking
subdirectories, supports mumunxmain.exe and emits incremental installation results.
POST /api/emulator_path {path} validates a known local exe and persists its path.
Discovery reloads manualEmulators; UI differentiates discovering vs not_found.
resume_all without lastRun now returns selectionRequired:true and releases pause.

Installer 1.1.2: allow final x64 CPython 3.11 in discovery/venv validation;
include Python311 default paths, python3.11.exe and py -3.11 fallback.
Existing verified 3.11 now avoids unnecessary bootstrap. App source was parsed
with AST feature_version=(3,11); Windows and actual Python 3.11 not executed here.

Installer patch 1.1.1: Get-PythonInfo validates isolated CPython x64 3.12/3.13
and stdlib; Get-PythonCandidates covers standard paths, PEP514 PythonCore registry
views and PATH; py launcher is the last fallback. Venv reuse also requires pip.
Python installer /log captures python-install.log; exit and probe failures are
recorded without removing publisher-signature validation.
Windows fixture checks in tests/test_installer.ps1 are supplied but not run here.

1.1: recovery.py — RecoveryWatchdog у desktop/server lifecycle.
GET /api/status.recovery: enabled та sessions (attempts, stage, detail, blocked).
POST /api/recovery_set: enabled:boolean; recoveryEnabled зберігається у state.
Scope: enabled account ∩ allowed_serials ∩ controlled_apps[serial]==com.roblox.client.
Три спостереження, single-operation mutex EmulatorFlow._begin(reset=False),
backoff 15→300 sec, 6 attempts, stable process 120 sec resets budget.
Roblox process missing → launch/login/game/key/script; ADB missing → exact native
index, owned ports only, then same pipeline. UI signout/disconnect is semantic only.
Не орієнтується на неперевірені пікселі і не визначає всі типи зависання/вильотів.
Paused/closing/stop_event/disabled flags блокують watchdog, у тому числі після probe.
Новий ручний EmulatorFlow.start збільшує generation й переозброює лічильники.
Legacy inspect auto-launch придушено для керованих Roblox-акаунтів,
щоб він не підміняв повний сценарій відновлення одним запуском процесу.

1.0: control_center.py — account save/game/script, stop_all та resume_all.
GET /api/status додає controlCenter і suspended. emulator snapshot додає managed.
POST /api/center_action: id, operation(save|game|script), placeId, luaScript,
executorAutoInject. Один акаунт → session_<account id> config без глобальної активації.
POST /api/stop_all — асинхронна зупинка; stage stopping/stopped/stop_incomplete.
POST /api/resume_all — повтор lastRun; спочатку перевірка доступності емулятора.
Panel.adb має barrier active/idle; allow_suspended використовується лише всередині
повної зупинки. Монітор не може відновити старі дані після паузи.
managed_resources.py обліковує лише започатковані тут native instances/PID identities.
Native CLI зупиняє конкретний index, generic fallback — тільки підтверджене дерево.
Пауза зберігається як runtimePaused; ownership навмисно не відновлюється за одним
ім’ям/індексом після аварії процесу. Закриття програми не є кнопкою повної зупинки.
android_setup.download_delta — cancellable subprocess; кеш перевіряється локальним
SHA-256, строк 24 години. Це не перевірка довіреного підпису видавця.

0.9: script_step.py — Android-редактор і одноразовий Execute після етапу ключа.
Config: luaScript:string до 32768 UTF-8 bytes, executorAutoInject:boolean.
POST emulator_start: runScript:boolean, потребує autoKeys:true.
ScriptStep запускається тільки після accepted/already_unlocked.
Конфіг фіксується на старті сценарію; його зміна перед Execute зупиняє етап.
executorAutoInject:true повністю пропускає ScriptStep без Android-запитів.
workflow.sessionKeys також відображає статуси етапу скрипта.
execute_sent — натискання, не доказ успішного виконання Lua.

0.8: session_keys.py — ізольований per-session key handoff через KeyJobs.
POST /api/emulator_start: autoKeys:boolean, потребує setupDelta:true.
workflow.sessionKeys[serial]: accountId, stage, detail, url; самого ключа немає.
Фонові session jobs мають saveKey:false; ручний key job зберігає стару поведінку.
Етап запускається після prepare_account. Уже відкритий доступ пропускається.
Невідомий UI, змінена прив’язка/процес, таймаут — needs_attention, не success.
Завершення — keys_ready; наступна автоматизація не запускається.

Зміни 0.7: android_setup.py (завантаження, APK install, семантичний вхід,
посилання режимів), load_guard.py (вимірювання перед наступним інстансом).
API emulator_start приймає setupDelta:boolean (типово false).
Акаунт: serial може бути порожнім, placeId приймає ID або Roblox games URL.
snapshot зберігає справжній login; loginState окремо залишається unverified,
бо панель не має постійного підтвердження автентифікації.
Етапи needs_attention/awaiting_game НЕ означають підтверджений вхід у режим.
У 1.4 provisioning.py створює чисті MuMu-інстанси для акаунтів через перевірений installed CLI create --number 1. Прив’язки та журнал незавершеного створення зберігаються в panel_state.json; інші вендори використовують наявні інстанси. Див. README.txt щодо перевірки на живому Android.

# MoyaPanel Desktop 0.6

## Архітектура

`MoyaPanel.exe` — launcher для `.venv/Scripts/pythonw.exe desktop.py`.
Desktop створює власний localhost HTTP сервер на вільному порту та відкриває
його UI у нативному WebView2 вікні. Зовнішній браузер для основного UI не запускається.
Закриття вікна зупиняє сервер/worker/key job; самі емулятори залишаються відкритими.

HTML/JS використовують same-origin API. Python звертається до ADB через argv та
shell=False з тайм-аутами. HTTP прив'язаний до localhost, перевіряє Host/Origin,
POST потребує X-Panel, JSON body обмежено 64 KiB. Зовнішні файли не роздаються.

## Модулі

- `server.py`: HTTP API та окремий ручний режим для розробки на 8777.
- `desktop.py`: вікно WebView2 та lifecycle локального сервера.
- `automation.py`: ADB discovery, процеси додатків, thumbnail capture, ресурси.
- `emulators.py`: пошук vendor executable та асинхронний launch/tuning workflow.
- `performance.py`: бюджет ПК, GPU/CPU metadata, MuMuTuner, Android tune/restore.
- `vendor_adapters.py`: LDPlayerTuner, MEmuTuner, NoxTuner, capabilities.
- `official_sources.py`: закритий каталог сайтів та перевірене відкриття URL.
- `key_jobs.py`: окремий subprocess для наявного key_system.py, stdout/[KEY], cancel.
- `Install.bat`/`install.ps1`: bootstrap Python, залежностей, WebView2, Chromium, ADB, EXE.

## Профіль за ПК

`host_budget()` читає psutil RAM/physical/logical CPU/current CPU. `hardware_info()`
один раз за процес пробує Windows CIM CPU/GPU names, timeout 10 с. Немає драйверних
налаштувань і немає VRAM/GPU benchmark. У разі збою назва GPU лишається невідомою.
Евристика integrated-only знижує display target, але не приписує виміряну продуктивність.

Рівні: економний 2 ГБ/1–2 vCPU/20 FPS/800x450; збалансований 3 ГБ/2/25/960x540;
розширений 4 ГБ/2/30/1024x576; потужний 4 ГБ/3/30/1024x576. Пороги описані в README.
CPU>=80% або мала вільна RAM знижують display workload. `recompute_capacity()`
відраховує reserve Windows, overhead VM та CPU reserve. Для LD/Nox guest RAM
округлюється до підтримуваного дискретного значення, потім capacity рахується знову.
Це оцінка планування, не максимум, доведений тестом робочої гри.

## Native-адаптери

Спільний контракт: manager, instances(), profile_for_host(), desired(), read(),
write(), stop_instance(), start_instance(), wait_ready(), apply(), restore().
`make_tuner()` обирає реалізацію за реально знайденою інсталяцією. Capabilities у
UI означають доступність адаптера/CLI; read/write перевіряються перед застосуванням.

MuMu: info/setting/control, тільки відомий JSON та всі потрібні ключі.
LD: офіційний list2/modify/quit/launch/adb, два підтримувані list2 формати.
  Readback лише відомої JSON схеми config, файл напряму не змінюється.
MEmu: офіційні listvms/getconfigex/setconfigex/start/stop/adb.
  cpus/memory мають повернути допустимі числові значення; serial береться через adb.
Nox: офіційний list/modify/quit/launch/adb з перевіреним внутрішнім ім'ям VM.
  CPU/RAM/NAT port читаються з відомого VirtualBox XML, включно з namespaces;
  файл напряму не переписується. Невідома схема зупиняє зміни.
BlueStacks: native CPU/RAM adapter відсутній, лише generic launch/Android tune.
Для LD/MEmu/Nox немає native FPS write: глобальні налаштування інших VM не зачіпаються.
Root/ідентифікатори/renderer/драйвери не змінюються.

Baseline зберігається перед першою зміною; повторний запуск його не перезаписує.
readback має підтвердити всі цільові значення (до 3 спроб після CLI). При помилці
повертаються змінені поля та перевіряється відкат. Неповний відкат — явна помилка.
CPU/RAM застосовуються при зупиненій VM. VM launch послідовний з Android boot wait.

## Зіставлення сесій

Registry Uninstall, відомі vendor каталоги та запущені player executable дають
список інсталяцій. Discovery не обходить цілі диски. LISTEN ports беруться лише
від PID у вибраному vendor root та відомих його hypervisor підкаталогах/сусідах.
5037 виключено. Native index→port додатково звужує вибір сесій. emulator-N і TCP
alias одного порту дедуплікуються. Інша інсталяція не обирається як «перший ADB device».
Невідомий native port mapping не обходиться підміною іншого серіалу.

## API

| Метод | Шлях | Призначення |
|---|---|---|
| GET | /api/status | devices/accounts/configs/history/keyJob/emulators/resources |
| GET | /api/frame?serial=... | cached PNG або 404 |
| POST | /api/emulator_scan | пошук інсталяцій |
| POST | /api/emulator_start | {id, package?, optimize?:true} |
| POST | /api/emulator_stop | скасування поточного workflow |
| POST | /api/emulator_restore | {id}; baseline restore |
| POST | /api/emulator_download | {id}; тільки fixed official catalogue |
| POST | /api/settings | ADB path, optional ports, auto |
| POST | /api/config | збереження/активація конфігу |
| POST | /api/activate | {id} |
| POST | /api/account | логін, serial, enabled, optional password |
| POST | /api/delete_account | {id} |
| POST | /api/launch | {serial}; запуск active package |
| POST | /api/key_start | URL/mode/showBrowser/closePopups |
| POST | /api/key_stop | зупинка керованого браузерного job |

Official downloads — лише відкрити HTTPS homepage із фіксованим hostname та шляхом /.
Невідомий ID/довільний URL відхиляється. Джерела не беруться з пошуку або налаштувань.
Браузер потрібен тільки для сторінки завантаження на явний клік; main app лишається
нативним вікном. Silent install емуляторів не виконується. Після ручної установки — scan.

## Джерела документації

- https://www.ldplayer.net/support/introduction-to-ldplayer-command-line-interface.html
- https://ru.ldplayer.net/support/rukovodstvo-po-komandnoy-stroke-ldconsole.html
- https://www.memuplay.com/blog/memucommand-reference-manual.html
- https://support.bignox.com/en/function/command
- https://support.bignox.com/vn/often/adb
- https://support.bluestacks.com/hc/en-us/articles/360053245871-How-to-use-the-BlueStacks-5-Settings-menu
- https://developer.android.com/tools/adb
- https://pywebview.flowrl.com/guide/installation

## Межі та перевірка

42 тести використовують підставні ADB/GUI/CLI, тестові config/XML та метрики ресурсу.
Вони перевіряють вибір профілю, adapter readback/restore, відмову на невідомій схемі,
URL allowlist, one-click flow та resource guards. Це не live acceptance Windows.
Потрібно перевірити реальні vendor CLI версії, формати/units config, порти/права
процесів, shutdown/boot, запуск встановленого Roblox та фактичну стабільність гри.
Автовхід, game join, AFK/Reconnect, введення ключа й Lua не реалізовані.
Живі GPU/VRAM/FPS/health гри не вимірюються, тому гарантії максимуму акаунтів немає.
