# Run via Install.bat. Scope: current user and this application directory.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = $PSScriptRoot
Set-Location -LiteralPath $root
$cache = Join-Path $root '.setup-cache'
New-Item -ItemType Directory -Force -Path $cache | Out-Null
$transcript = $false

function Run-Step([string]$Exe, [string[]]$Arguments) {
    & $Exe @Arguments | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "Command failed ($LASTEXITCODE): $Exe $($Arguments -join ' ')" }
}
function Get-PythonInfo([string]$Executable, [switch]$RequirePip) {
    if (-not $Executable) { return $null }
    $Executable = [Environment]::ExpandEnvironmentVariables($Executable.Trim().Trim('"'))
    if (-not (Test-Path -LiteralPath $Executable -PathType Leaf)) { return $null }
    # Do not execute Store aliases that may open an interactive installation window.
    if ($Executable -match '\\Microsoft\\WindowsApps\\') { return $null }
    $probe = 'import sys,struct,platform,json,ssl,venv,ensurepip,ctypes; print(json.dumps(dict(version=list(sys.version_info[:2]),bits=struct.calcsize(chr(80))*8,machine=platform.machine(),implementation=sys.implementation.name,executable=sys.executable,release=sys.version_info.releaselevel)))'
    if ($RequirePip) { $probe = 'import pip; ' + $probe }
    Write-Host "Checking Python: $Executable"
    try {
        # -I avoids PYTHONPATH, user site packages and imports from the current directory.
        $output = @(& $Executable '-I' '-c' $probe 2>&1)
        $probeExit = $LASTEXITCODE
        if ($probeExit -ne 0) {
            Write-Host "Python probe failed (exit $probeExit): $($output -join ' ')"
            return $null
        }
        $line = $output | Where-Object { $_ -is [string] -and $_.Trim() } | Select-Object -Last 1
        $info = $line | ConvertFrom-Json -ErrorAction Stop
        $version = ($info.version -join '.')
        if ($version -notin @('3.11','3.12','3.13') -or $info.bits -ne 64 -or
            $info.machine -notin @('AMD64','x86_64') -or $info.implementation -ne 'cpython' -or $info.release -ne 'final') {
            Write-Host "Python rejected: version=$version bits=$($info.bits) machine=$($info.machine) implementation=$($info.implementation) release=$($info.release)"
            return $null
        }
        if (-not (Test-Path -LiteralPath $info.executable -PathType Leaf)) { return $null }
        return $info
    } catch {
        Write-Host "Python probe error: $($_.Exception.Message)"
        return $null
    }
}

function Get-PythonCandidates {
    # Read existing installations; do not change PATH, associations or other Python installs.
    $candidates = @(Join-Path $root '.runtime\python.exe')
    foreach ($base in @($env:LOCALAPPDATA, $env:ProgramFiles, $env:ProgramW6432, ${env:ProgramFiles(x86)})) {
        if (-not $base) { continue }
        foreach ($tag in @('311','312','313')) {
            foreach ($relative in @("Programs\Python\Python$tag\python.exe", "Programs\Python\Python$tag-64\python.exe", "Python$tag\python.exe")) {
                $candidates += Join-Path $base $relative
            }
        }
    }
    if ($env:SystemDrive) {
        foreach ($tag in @('311','312','313')) { $candidates += Join-Path ($env:SystemDrive + '\') "Python$tag\python.exe" }
    }
    foreach ($hive in @([Microsoft.Win32.RegistryHive]::CurrentUser, [Microsoft.Win32.RegistryHive]::LocalMachine)) {
        foreach ($view in @([Microsoft.Win32.RegistryView]::Registry64, [Microsoft.Win32.RegistryView]::Registry32)) {
            $registry = $null; $core = $null
            try {
                $registry = [Microsoft.Win32.RegistryKey]::OpenBaseKey($hive, $view)
                $core = $registry.OpenSubKey('Software\Python\PythonCore')
                if (-not $core) { continue }
                foreach ($tag in $core.GetSubKeyNames()) {
                    $install = $null
                    try {
                        $install = $core.OpenSubKey($tag + '\InstallPath')
                        if (-not $install) { continue }
                        $exe = $install.GetValue('ExecutablePath')
                        $directory = $install.GetValue('')
                        if ($exe) { $candidates += [string]$exe }
                        if ($directory) { $candidates += Join-Path ([string]$directory) 'python.exe' }
                    } finally { if ($install) { $install.Dispose() } }
                }
            } catch {
                Write-Host "Python registry discovery: $($_.Exception.Message)"
            } finally {
                if ($core) { $core.Dispose() }
                if ($registry) { $registry.Dispose() }
            }
        }
    }
    foreach ($name in @('python.exe','python3.exe','python3.11.exe','python3.12.exe','python3.13.exe')) {
        foreach ($command in @(Get-Command $name -CommandType Application -All -ErrorAction SilentlyContinue)) {
            if ($command) { $candidates += $command.Source }
        }
    }
    return $candidates | Select-Object -Unique
}

function Find-CompatiblePython {
    foreach ($candidate in @(Get-PythonCandidates)) {
        $info = Get-PythonInfo -Executable $candidate
        if ($info) { return $info.executable }
    }
    $launcher = Get-Command py.exe -CommandType Application -ErrorAction SilentlyContinue
    if ($launcher) {
        foreach ($tag in @('-3.11','-3.12','-3.13')) {
            try {
                $output = @(& $launcher.Source $tag '-I' '-c' 'import sys; print(sys.executable)' 2>$null)
                foreach ($line in $output) {
                    if ($line -is [string]) {
                        $info = Get-PythonInfo -Executable $line
                        if ($info) { return $info.executable }
                    }
                }
            } catch { Write-Host "Python launcher probe: $($_.Exception.Message)" }
        }
    }
    return $null
}
function Find-Manager {
    foreach ($name in @('pymanager.exe','py.exe')) {
        $command = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue
        if ($command) {
            try {
                $help = & $command.Source 'help' 'install' 2>$null
                if (($help -join ' ') -match '--target') { return $command.Source }
            } catch { }
        }
    }
    return $null
}
function Has-WebView2 {
    foreach ($base in @('HKCU:\Software\Microsoft\EdgeUpdate\Clients',
                         'HKLM:\Software\Microsoft\EdgeUpdate\Clients',
                         'HKLM:\Software\WOW6432Node\Microsoft\EdgeUpdate\Clients')) {
        if (Test-Path $base) {
            foreach ($key in (Get-ChildItem $base -ErrorAction SilentlyContinue)) {
                $entry = Get-ItemProperty $key.PSPath -ErrorAction SilentlyContinue
                if ($entry.name -like '*WebView2*' -and $entry.pv -and $entry.pv -ne '0.0.0.0') { return $true }
            }
        }
    }
    return $false
}
function Download([string]$Url, [string]$Destination) {
    $partial = "$Destination.partial"
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Invoke-WebRequest -Uri $Url -OutFile $partial -UseBasicParsing -TimeoutSec 180
            if ((Get-Item -LiteralPath $partial).Length -lt 1024) { throw 'Empty or incomplete download' }
            Move-Item -LiteralPath $partial -Destination $Destination -Force
            return
        } catch {
            Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
            if ($attempt -eq 3) { throw }
            Write-Host "Download interrupted. Retrying ($attempt/3)..."
        }
    }
}
try {
    Start-Transcript -Path (Join-Path $root 'install.log') -Append | Out-Null
    $transcript = $true
    Write-Host '[1/6] Checking compatible Python...'
    $python = Find-CompatiblePython
    if (-not $python) {
        $manager = Find-Manager
        if ($manager) {
            try {
                Write-Host 'Downloading Python 3.12 using the existing manager...'
                Run-Step -Exe $manager -Arguments @('install','3.12','--target',(Join-Path $root '.runtime'))
                $python = Find-CompatiblePython
            } catch {
                Write-Host 'Manager bootstrap failed; switching to the official direct installer.'
            }
        }
        if (-not $python) {
            # No winget / Store / app aliases required on this path.
            Write-Host 'Downloading a compatible Python installer directly from python.org...'
            $page = Invoke-WebRequest -Uri 'https://www.python.org/downloads/windows/' -UseBasicParsing -TimeoutSec 120
            $pattern = 'https://www\.python\.org/ftp/python/(?<v>3\.13\.\d+)/python-\k<v>-amd64\.exe'
            $releases = @([regex]::Matches($page.Content, $pattern) | ForEach-Object {
                [pscustomobject]@{ Version = [version]$_.Groups['v'].Value; Url = $_.Value }
            } | Sort-Object Version -Descending)
            if ($releases.Count -eq 0) { throw 'Cannot resolve the official Python 3.13 Windows installer link.' }
            if (-not [Environment]::Is64BitOperatingSystem) { throw 'This desktop package requires 64-bit Windows.' }
            $setup = Join-Path $cache 'PythonSetup.exe'
            Download -Url $releases[0].Url -Destination $setup
            $signature = Get-AuthenticodeSignature -LiteralPath $setup
            if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
                throw 'Python installer publisher verification failed.'
            }
            $runtime = Join-Path $root '.runtime'
            $pythonLog = Join-Path $root 'python-install.log'
            $arguments = @('/quiet','/log',('"' + $pythonLog + '"'),'InstallAllUsers=0','Include_launcher=0','PrependPath=0',
                           'Include_test=0','AssociateFiles=0','Shortcuts=0','Include_pip=1','Include_exe=1','Include_lib=1',
                           ('TargetDir="' + $runtime + '"'))
            Write-Host "Python installer target: $runtime"
            Write-Host "Python installer log: $pythonLog"
            $process = Start-Process -FilePath $setup -ArgumentList ($arguments -join ' ') -Wait -PassThru
            Write-Host "Python installer exit code: $($process.ExitCode)"
            if ($process.ExitCode -notin @(0,3010)) { throw "Python installer failed ($($process.ExitCode)). See python-install.log." }
            $python = Find-CompatiblePython
            if (-not $python -and $process.ExitCode -eq 3010) {
                throw 'Python installation requires a Windows restart. Restart Windows, then run Install.bat again.'
            }
        }
        if (-not $python) { throw 'No usable x64 CPython 3.11/3.12/3.13 found after installation. See install.log and python-install.log.' }
    }
    Write-Host "Python ready: $python"

    Write-Host '[2/6] Preparing application environment...'
    $venv = Join-Path $root '.venv'
    $venvPython = Join-Path $venv 'Scripts\python.exe'
    $valid = [bool](Get-PythonInfo -Executable $venvPython -RequirePip)
    if (-not $valid) {
        if (Test-Path -LiteralPath $venv) {
            Move-Item -LiteralPath $venv -Destination ($venv + '.previous.' + [guid]::NewGuid().ToString('N'))
        }
        Run-Step -Exe $python -Arguments @('-m','venv',$venv)
    }
    Run-Step -Exe $venvPython -Arguments @('-m','pip','install','--upgrade','pip')
    Run-Step -Exe $venvPython -Arguments @('-m','pip','install','-r',(Join-Path $root 'requirements.txt'),'pyinstaller')

    Write-Host '[3/6] Checking native window runtime...'
    if (-not (Has-WebView2)) {
        $bootstrap = Join-Path $cache 'WebView2Setup.exe'
        Download -Url 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -Destination $bootstrap
        $signature = Get-AuthenticodeSignature -LiteralPath $bootstrap
        if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') {
            throw 'WebView2 installer publisher verification failed.'
        }
        $process = Start-Process -FilePath $bootstrap -ArgumentList @('/silent','/install') -Wait -PassThru
        if (-not (Has-WebView2)) { throw "WebView2 did not install (exit $($process.ExitCode))." }
    }

    Write-Host '[4/6] Installing the Playwright browser...'
    Run-Step -Exe $venvPython -Arguments @('-m','playwright','install','chromium')

    Write-Host '[5/6] Installing local Android platform tools...'
    $tools = Join-Path $root 'tools'
    $adb = Join-Path $tools 'platform-tools\adb.exe'
    if (-not (Test-Path -LiteralPath $adb)) {
        $archive = Join-Path $cache 'platform-tools.zip'
        Download -Url 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -Destination $archive
        New-Item -ItemType Directory -Force -Path $tools | Out-Null
        Expand-Archive -LiteralPath $archive -DestinationPath $tools -Force
    }
    Run-Step -Exe $adb -Arguments @('version')

    Write-Host '[6/6] Building MoyaPanel.exe...'
    New-Item -ItemType Directory -Force -Path (Join-Path $root 'desktop_build') | Out-Null
    Run-Step -Exe $venvPython -Arguments @('-m','PyInstaller','--noconfirm','--clean','--onefile','--windowed','--name','MoyaPanel','--icon',(Join-Path $root 'icon.ico'),'--distpath',(Join-Path $root 'desktop_dist'),'--workpath',(Join-Path $root 'desktop_build'),'--specpath',(Join-Path $root 'desktop_build'),(Join-Path $root 'launcher.py'))
    Copy-Item -LiteralPath (Join-Path $root 'desktop_dist\MoyaPanel.exe') -Destination (Join-Path $root 'MoyaPanel.exe') -Force
    Write-Host 'Complete. Opening MoyaPanel Desktop...'
    Start-Process -FilePath (Join-Path $root 'MoyaPanel.exe') -WorkingDirectory $root
} catch {
    Write-Host "SETUP FAILED: $($_.Exception.Message)" -ForegroundColor Red
    if ($transcript) { Stop-Transcript | Out-Null; $transcript = $false }
    exit 1
} finally {
    if ($transcript) { Stop-Transcript | Out-Null }
}
exit 0
