"""Vendor CLI adapters. Configuration files are read only, never rewritten directly."""
import csv
import json
import re
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from performance import MuMuTuner, recompute_capacity


def find_cli(item,names):
    root=Path(item['root'])
    folders=(Path(item['path']).parent,root,root/'bin')
    return next((folder/name for folder in folders for name in names if (folder/name).is_file()),None)


def numeric(text):
    lines=[s.strip() for s in text.splitlines() if s.strip()]
    if not lines or re.search(r'error|fail',text,re.I):
        raise RuntimeError('Vendor CLI не повернув числове значення')
    if not re.fullmatch(r'\d+',lines[-1]):
        raise RuntimeError('Непідтримуваний формат значення Vendor CLI')
    return int(lines[-1])


class CommonTuner(MuMuTuner):
    native_fields=('CPU','RAM')
    def call(self,*args):
        try:
            return super().call(*args)
        except RuntimeError as e:
            raise RuntimeError(str(e).replace('MuMu CLI',self.item['name']+' CLI')) from e

    def profile_for_host(self,profile):
        profile=dict(profile)
        if self.item['name'] in {'LDPlayer','Nox'}:
            requested=profile['guestGB']*1024
            memory=next((n for n in (2048,4096,8192) if n>=requested),8192)
            profile['guestGB']=memory//1024
        profile['cores']=min(4,profile['cores'])
        return recompute_capacity(profile)

    def stop_instance(self,index,cancel):
        self.quit(index)
        deadline=time.monotonic()+75
        while time.monotonic()<deadline:
            state=next((x for x in self.instances() if x['index']==index),None)
            if state and not state['running']:
                return
            if cancel.wait(1):
                raise RuntimeError('Зупинку інстанса скасовано')
        raise RuntimeError(self.item['name']+' не підтвердив зупинку; ресурси не змінено')

    def wait_ready(self,index,cancel):
        deadline=time.monotonic()+150
        while time.monotonic()<deadline:
            try:
                if self.boot_complete(index):
                    return
            except (RuntimeError,subprocess.TimeoutExpired):
                pass
            if cancel.wait(3):
                return
        raise RuntimeError(self.item['name']+' не підтвердив Android boot за 150 с')

    def desired(self,profile):
        return {'cpu':str(profile['cores']),'memory':str(profile['guestGB']*1024)}


class LDPlayerTuner(CommonTuner):
    def __init__(self,item,directory,**kwargs):
        super().__init__(item,directory,**kwargs)
        self.manager=find_cli(item,('ldconsole.exe','dnconsole.exe'))

    def instances(self):
        result=[]
        for row in csv.reader(self.call('list2').splitlines()):
            if len(row)<6 or not row[0].isdigit():
                continue
            index=int(row[0])
            if index>=10000:
                continue
            try:
                if len(row)>=7:
                    running=row[4]=='1' or int(row[5])>0 or int(row[6])>0
                    ready=row[4]=='1'
                elif row[2] in {'0','1'} and all(int(v)>0 for v in row[3:6]):
                    running=row[2]=='1';ready=running
                else:
                    continue
            except ValueError:
                continue
            result.append({'index':index,'running':running,'ready':ready,'port':5555+2*index})
        if not result:
            raise RuntimeError('LDPlayer list2: інстанси не знайдені або формат не підтримується')
        return result

    def config_path(self,index):
        roots=(Path(self.item['root']),Path(self.item['path']).parent)
        choices=[root/'vms/config'/f'leidian{index}.config' for root in roots]
        return next((p for p in choices if p.is_file()),None)

    def read(self,index):
        path=self.config_path(index)
        if path is None:
            raise RuntimeError('LDPlayer: немає читабельного config для резервної копії; CPU/RAM не змінено')
        values=json.loads(path.read_text(encoding='utf-8-sig'))
        try:
            cpu=int(values['advancedSettings.cpuCount'])
            memory=int(values['advancedSettings.memorySize'])
        except (KeyError,TypeError,ValueError) as e:
            raise RuntimeError('LDPlayer: невідома схема config; CPU/RAM не змінено') from e
        if not 1<=cpu<=16 or not 256<=memory<=65536:
            raise RuntimeError('LDPlayer: некоректні CPU/RAM у config')
        return {'cpu':str(cpu),'memory':str(memory)}

    def write(self,index,key,value):
        if key not in {'cpu','memory'}:
            raise ValueError('Unsupported LD setting')
        self.call('modify','--index',index,'--'+key,value)

    def quit(self,index):
        self.call('quit','--index',index)

    def start_instance(self,index):
        self.call('launch','--index',index)

    def boot_complete(self,index):
        raw=self.call('adb','--index',index,'--command','shell getprop sys.boot_completed')
        return any(line.strip()=='1' for line in raw.splitlines())


class MEmuTuner(CommonTuner):
    def __init__(self,item,directory,**kwargs):
        super().__init__(item,directory,**kwargs)
        self.manager=find_cli(item,('memuc.exe',))

    def instances(self):
        result=[]
        for row in csv.reader(self.call('listvms').splitlines()):
            if len(row)<5 or not row[0].isdigit():
                continue
            index=int(row[0])
            running=row[3]=='1'
            port=None
            if running:
                try:
                    serial=self.call('-i',index,'adb','get-serialno')
                    match=re.search(r'(?:127\.0\.0\.1|localhost):(\d+)',serial)
                    if match:port=int(match.group(1))
                except (RuntimeError,subprocess.TimeoutExpired):
                    pass
            result.append({'index':index,'running':running,'ready':False,'port':port})
        if not result:
            raise RuntimeError('MEmu listvms: інстанси не знайдені або формат не підтримується')
        return result

    def read(self,index):
        cpu=numeric(self.call('getconfigex','-i',index,'cpus'))
        memory=numeric(self.call('getconfigex','-i',index,'memory'))
        if not 1<=cpu<=16 or not 256<=memory<=65536:
            raise RuntimeError('MEmu не підтвердив CPU/RAM у підтримуваних одиницях')
        return {'cpu':str(cpu),'memory':str(memory)}

    def write(self,index,key,value):
        name={'cpu':'cpus','memory':'memory'}.get(key)
        if name is None:
            raise ValueError('Unsupported MEmu setting')
        self.call('setconfigex','-i',index,name,value)

    def quit(self,index):
        self.call('stop','-i',index)

    def start_instance(self,index):
        self.call('start','-i',index)

    def boot_complete(self,index):
        raw=self.call('-i',index,'adb','shell getprop sys.boot_completed')
        return any(line.strip()=='1' for line in raw.splitlines())


class NoxTuner(CommonTuner):
    def __init__(self,item,directory,**kwargs):
        super().__init__(item,directory,**kwargs)
        self.manager=find_cli(item,('NoxConsole.exe','noxconsole.exe'))

    def vbox_path(self,index):
        if not re.fullmatch(r'[A-Za-z0-9_-]+',str(index)):
            raise ValueError('Некоректне ім’я інстанса Nox')
        root=Path(self.item['root'])
        folders=(root/'BignoxVMS',root.parent/'BignoxVMS')
        return next((folder/str(index)/(str(index)+'.vbox') for folder in folders
                     if (folder/str(index)/(str(index)+'.vbox')).is_file()),None)

    def hardware(self,index):
        path=self.vbox_path(index)
        if path is None:
            raise RuntimeError('Nox: не знайдено читабельний VM config; зміни ресурсів зупинено')
        root=ET.parse(path).getroot()
        tag=lambda e:e.tag.rsplit('}',1)[-1]
        machine=next((x for x in root.iter() if tag(x)=='Machine'),None)
        hardware=next((x for x in machine if tag(x)=='Hardware'),None) if machine is not None else None
        if hardware is None:
            raise RuntimeError('Nox: непідтримувана схема VM config')
        return hardware

    def read(self,index):
        hardware=self.hardware(index)
        fields={node.tag.rsplit('}',1)[-1]:node for node in hardware}
        try:
            cpu=int(fields['CPU'].attrib['count'])
            memory=int(fields['Memory'].attrib['RAMSize'])
        except (KeyError,ValueError) as e:
            raise RuntimeError('Nox: не вдалося прочитати CPU/RAM') from e
        return {'cpu':str(cpu),'memory':str(memory)}

    def port(self,index):
        try:
            for node in self.hardware(index).iter():
                if node.attrib.get('guestport')=='5555' and str(node.attrib.get('hostport','')).isdigit():
                    return int(node.attrib['hostport'])
        except (OSError,RuntimeError,ET.ParseError):
            pass
        return None

    def instances(self):
        result=[]
        for row in csv.reader(self.call('list').splitlines()):
            if len(row)<6 or not re.fullmatch(r'[A-Za-z0-9_-]+',row[0]):
                continue
            try:running=any(int(v)>0 for v in row[-2:])
            except ValueError:continue
            result.append({'index':row[0],'running':running,'ready':False,'port':self.port(row[0])})
        if not result:
            raise RuntimeError('Nox list: інстанси не знайдені або формат не підтримується')
        return result

    def write(self,index,key,value):
        if key not in {'cpu','memory'}:
            raise ValueError('Unsupported Nox setting')
        self.call('modify','-name:'+str(index),'-'+key+':'+str(value))

    def quit(self,index):
        self.call('quit','-name:'+str(index))

    def start_instance(self,index):
        self.call('launch','-name:'+str(index))

    def boot_complete(self,index):
        raw=self.call('adb','-name:'+str(index),'-command:shell getprop sys.boot_completed')
        return any(line.strip()=='1' for line in raw.splitlines())


def capabilities(item):
    paths={'MuMu Player':('MuMuManager.exe',),'LDPlayer':('ldconsole.exe','dnconsole.exe'),
           'MEmu':('memuc.exe',),'Nox':('NoxConsole.exe','noxconsole.exe')}
    names=paths.get(item['name'],())
    found=find_cli(item,names) if names else None
    root=Path(item['root'])
    if item['name']=='MuMu Player' and not found:
        found=next((root/sub/'MuMuManager.exe' for sub in ('shell','nx_main')
                    if (root/sub/'MuMuManager.exe').is_file()),None)
    fields=['CPU','RAM']+(['FPS'] if item['name']=='MuMu Player' else []) if found else []
    return {'nativeFields':fields,'cli':str(found) if found else None,
            'status':'Перевірка читання/запису перед зміною' if found else 'Лише Android-профіль; native CPU/RAM недоступні',
            'android':True}
