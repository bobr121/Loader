"""Persistent dedicated MuMu slots. Never clone another account's Android data."""
import copy
import shutil
import time
from pathlib import Path


def account_instances(panel,item,tuner,limit,cancel,stage):
    with panel.lock:
        accounts=copy.deepcopy([a for a in panel.data['accounts'] if a['enabled']])[:limit]
    if not accounts:
        raise RuntimeError('Немає увімкнених акаунтів у межах бюджету ПК')
    if any(not a.get('placeId') for a in accounts):
        raise RuntimeError('Перед запуском задайте режим гри для кожного увімкненого акаунта')
    entries=tuner.instances()
    selected=[]
    for account in accounts:
        if cancel.is_set():
            return []
        with panel.lock:
            pool=panel.data.setdefault('instancePool',{}).setdefault(item['id'],{})
            record=pool.get(account['id'])
            record=copy.deepcopy(record) if record else None
        if record and record.get('login')!=account['login']:
            # An edited username must never inherit the previous user's session.
            record=None
        existing=next((v for v in entries if record and v['index']==record.get('index')),None)
        if existing is None:
            with panel.lock:
                pending=copy.deepcopy(panel.data.setdefault('instanceCreates',{}).get(item['id']))
            if pending:
                added=[v for v in entries if v['index'] not in pending['before']]
                if len(added)!=1:
                    raise RuntimeError('Попереднє створення MuMu не підтверджено однозначно. Нові дублікати не створювалися.')
                with panel.lock:
                    pool=panel.data['instancePool'][item['id']]
                    pool[pending['accountId']]={'index':added[0]['index'],'login':pending['login']}
                    panel.data['instanceCreates'].pop(item['id'],None)
                    panel.save()
                if pending['accountId']==account['id'] and pending['login']==account['login']:
                    existing=added[0]
            if existing is None:
                if shutil.disk_usage(Path(item['root'])).free<8*1024**3:
                    raise RuntimeError('Для нового Android-інстанса потрібен резерв 8 ГБ на диску емулятора')
                stage('creating_instance','Створюю чистий Android для '+account['login']+'…')
                before=[v['index'] for v in entries]
                with panel.lock:
                    panel.data.setdefault('instanceCreates',{})[item['id']]={
                        'before':before,'accountId':account['id'],'login':account['login']}
                    panel.save()
                # Do not automatically retry create after timeout or crash: it may
                # have succeeded. The saved inventory reconciles the next launch.
                tuner.create_instance(cancel)
                deadline=time.monotonic()+60
                while not cancel.is_set():
                    entries=tuner.instances()
                    added=[v for v in entries if v['index'] not in before]
                    if len(added)==1:
                        existing=added[0]
                        break
                    if len(added)>1 or time.monotonic()>=deadline:
                        raise RuntimeError('MuMu не підтвердив один новий інстанс; повторне створення заблоковано')
                    cancel.wait(1)
                if existing is None:
                    return []
                with panel.lock:
                    panel.data['instancePool'][item['id']][account['id']]={
                        'index':existing['index'],'login':account['login']}
                    panel.data['instanceCreates'].pop(item['id'],None)
                    panel.save()
        if any(v['index']==existing['index'] for v in selected):
            raise RuntimeError('Два акаунти посилаються на один інстанс; запуск зупинено')
        with panel.lock:
            live=next((a for a in panel.data['accounts'] if a['id']==account['id']),None)
            if not live or live['login']!=account['login'] or not live['enabled']:
                raise RuntimeError('Акаунт змінився під час підготовки')
            live.update(emulatorId=item['id'],instanceIndex=existing['index'],serial='')
            panel.save()
        selected.append(existing)
        stage('instance_ready',account['login']+': Android #'+str(existing['index'])+' підготовлений')
    return selected
