"""Account controls, complete work stop, and restart from saved launch options."""
import copy
import threading
import time
from android_setup import PACKAGE, place_id
from session_keys import SessionKeys
from script_step import ScriptStep


class ControlCenter:
    def __init__(self, panel, flow, key_jobs):
        self.panel,self.flow,self.key_jobs=panel,flow,key_jobs
        self.lock=threading.RLock()
        self.thread=None
        self.state={'running':False,'stage':'paused' if panel.suspended else 'ready','detail':'Роботу припинено' if panel.suspended else 'Керування готове','errors':[]}

    def snapshot(self):
        with self.lock:
            state=copy.deepcopy(self.state)
        with self.panel.lock:
            state['canResume']=not state['running'] and self.panel.suspended
            state['paused']=self.panel.suspended
        if not state['running'] and not state['paused']:
            with self.flow.lock:
                state['detail']=self.flow.state.get('detail') or state['detail']
                state['stage']=self.flow.state.get('stage') or state['stage']
        return state

    def _account(self, ident):
        account=next((a for a in self.panel.data['accounts'] if a['id']==ident),None)
        if not account: raise ValueError('Акаунт не знайдено')
        return account

    def _prepare(self, body):
        operation=body.get('operation')
        if operation not in {'save','game','script'}: raise ValueError('Невідома дія')
        with self.panel.lock:
            account=self._account(body.get('id'))
            current=next((c for c in self.panel.data['configs'] if c['id']==account.get('configId',self.panel.data['active'])),None)
            if current is None: raise ValueError('Конфіг акаунта не знайдено')
            script=body.get('luaScript',current.get('luaScript',''))
            if not isinstance(script,str) or len(script.encode('utf-8'))>32768 or '\0' in script:
                raise ValueError('Lua-скрипт: до 32 КіБ без NUL')
            game=place_id(body.get('placeId',account.get('placeId','')))
            if operation=='game' and not game: raise ValueError('Вкажіть режим гри')
            if operation!='save':
                if not account['enabled'] or not account['serial'] or self.panel.allowed_serials is None or account['serial'] not in self.panel.allowed_serials:
                    raise ValueError('Спочатку запустіть цей акаунт через панель')
                if self.panel.suspended: raise ValueError('Роботу припинено; натисніть Відновити роботу')
            config=copy.deepcopy(current)
            config.update(id='session_'+account['id'],name='Сесія: '+account['login'],package=PACKAGE,
                          luaScript=script,executorAutoInject=bool(body.get('executorAutoInject',current.get('executorAutoInject',False))))
            return operation,copy.deepcopy(account),game,config

    def _save(self,account,game,config):
        with self.panel.lock:
            live=self._account(account['id'])
            if live['serial']!=account['serial'] or live['login']!=account['login']:
                raise ValueError('Прив’язка акаунта змінилася')
            existing=next((c for c in self.panel.data['configs'] if c['id']==config['id']),None)
            if existing: existing.update(config)
            else: self.panel.data['configs'].append(copy.deepcopy(config))
            live.update(placeId=game,configId=config['id'])
            self.panel.save()
            return copy.deepcopy(live)

    def action(self,body):
        operation,account,game,config=self._prepare(body)
        if operation=='save':
            with self.flow.lock:
                if self.flow.state['running']: raise ValueError('Дочекайтеся поточної операції')
                self._save(account,game,config)
            return {'ok':True,'saved':True}
        def perform():
            bound=self._save(account,game,config)
            serial=bound['serial']
            if self.flow.stop_event.is_set(): return
            if operation=='game':
                self.flow.key_state(serial,bound['id'],'switching_game','Надсилаю перехід у режим '+game+'…')
                output=self.panel.adb('shell','am','start','-W','-a','android.intent.action.VIEW','-d','roblox://placeId='+game,'-p',PACKAGE,serial=serial,timeout=40)
                if b'Error:' in output or b'Exception' in output: raise ValueError('Android не прийняв посилання режиму')
                with self.panel.lock: self.panel.controlled_apps[serial]=PACKAGE
                self.panel.event(serial,'game_link_sent','Place ID '+game+'; завантаження гри ще не підтверджено')
            result=SessionKeys(self.panel,self.flow.key_state).run(serial,bound,self.flow.stop_event)
            if result not in {'accepted','already_unlocked'}: return
            ScriptStep(self.panel,self.flow.key_state).run(serial,bound,config,self.flow.stop_event)
        self.flow._begin(perform,reset=False)
        return {'ok':True,'queued':True}

    def stop_all(self):
        with self.lock:
            if self.state['running']: return {'ok':True,'stopping':True}
            self.state.update(running=True,stage='stopping',detail='Скасовую завдання та закриваю керовані вікна…',errors=[])
            with self.flow.lock:
                self.flow.closing_all=True
                self.flow.stop_event.set()
            with self.panel.lock:
                self.panel.suspended=True
                self.panel.data['runtimePaused']=True
                try: self.panel.save()
                except OSError: self.state['errors'].append('Не вдалося зберегти стан паузи на диск')
            self.thread=threading.Thread(target=self._stop,daemon=True,name='stop-all')
            self.thread.start()
        return {'ok':True,'stopping':True}

    def _stop(self):
        with self.lock:
            errors=list(self.state['errors'])
        try:
            try: self.key_jobs.stop()
            except Exception: errors.append('Фоновий браузер ключа не підтвердив завершення')
            # Let in-flight ADB/install/UI calls finish before closing emulators. No new ADB calls
            # can start after suspended=True. The UI remains responsive during this wait.
            worker=self.flow.thread
            while worker and worker.is_alive(): worker.join(.5)
            self.panel.adb_idle.wait()
            with self.panel.lock:
                apps=dict(self.panel.controlled_apps)
            for serial,package in apps.items():
                try:
                    self.panel.adb('shell','am','force-stop',package,serial=serial,timeout=15,allow_suspended=True)
                    output=self.panel.adb('shell','ps','-A',serial=serial,allow_suspended=True).decode('utf-8','replace')
                    if any(line.split() and line.split()[-1]==package for line in output.splitlines()):
                        raise RuntimeError('still running')
                    with self.panel.lock: self.panel.controlled_apps.pop(serial,None)
                except Exception:
                    errors.append(serial+': зупинку гри не підтверджено через ADB')
            errors.extend(self.flow.managed.close_all())
            with self.panel.lock:
                self.panel.allowed_serials=set()
                self.panel.devices.clear();self.panel.frames.clear()
            self.flow.stage('fully_stopped' if not errors else 'stop_incomplete','Керовані вікна закриті; автозапуски вимкнені' if not errors else 'Частину вікон не вдалося закрити; дивіться Центр керування')
        except Exception:
            errors.append('Не вдалося завершити зупинку; повторіть після завершення поточних команд')
        finally:
            with self.lock:
                self.state.update(running=False,stage='stop_incomplete' if errors else 'stopped',errors=errors,
                                  detail='; '.join(errors) if errors else 'Роботу припинено. Керовані вікна закриті; налаштування збережені.')

    def resume(self,options_override=None):
        with self.lock:
            if self.state['running']: raise ValueError('Зупинка ще триває')
            if not self.panel.suspended: raise ValueError('Робота вже активна')
            with self.flow.lock:
                if self.flow.state['running']: raise ValueError('Операція вже виконується')
            with self.panel.lock:
                options=copy.deepcopy(options_override if options_override is not None else self.panel.data.get('lastRun'))
            if not options:
                with self.panel.lock:
                    self.panel.data['runtimePaused']=False
                    try: self.panel.save()
                    except OSError:
                        self.panel.data['runtimePaused']=True
                        raise ValueError('Не вдалося зберегти стан запуску')
                    self.panel.suspended=False;self.panel.allowed_serials=set()
                self.flow.closing_all=False
                self.flow.stage('choose_emulator','Пауза знята. Виберіть емулятор у Моніторингу для першого запуску')
                self.state.update(stage='ready',detail='Пауза знята; потрібен перший запуск',errors=[])
                return {'ok':True,'selectionRequired':True}
            if not any(i['id']==options['id'] for i in self.flow.items):
                found=self.flow.detector()
                with self.flow.lock: self.flow.items=found
            if not any(i['id']==options['id'] for i in self.flow.items):
                raise ValueError('Збережений емулятор не знайдено. Перевірте встановлення')
            with self.panel.lock:
                self.panel.data['runtimePaused']=False
                try: self.panel.save()
                except OSError:
                    self.panel.data['runtimePaused']=True
                    raise ValueError('Не вдалося зберегти стан запуску; панель залишається на паузі')
                self.panel.allowed_serials=set()
                self.panel.suspended=False
            self.flow.closing_all=False
            try: self.flow.start(options)
            except Exception:
                with self.panel.lock:
                    self.panel.suspended=True;self.panel.data['runtimePaused']=True;self.panel.save()
                self.flow.closing_all=True
                raise
            self.state.update(stage='resuming',detail='Відновлюю збережений сценарій…',errors=[])
        return {'ok':True,'queued':True}

    def close(self):
        # Desktop close also cancels tasks; explicit full stop performs emulator shutdown.
        if self.thread and self.thread.is_alive(): self.thread.join()
