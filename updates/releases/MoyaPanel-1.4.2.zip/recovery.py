"""Scoped recovery of managed Roblox sessions; never restart all healthy windows."""
import copy
import os
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from android_setup import PACKAGE, prepare_account, place_id
from emulators import make_tuner, selected_devices, serial_port
from session_keys import SessionKeys, AndroidKeyUI
from script_step import ScriptStep


class RecoveryAttention(RuntimeError):
    pass


class RecoveryRetry(RecoveryAttention):
    pass


def ui_problem(serial):
    ui=AndroidKeyUI(serial)
    if ui.device.app_current().get('package')!=PACKAGE: return None
    nodes=[n.attrib for n in ET.fromstring(ui.device.dump_hierarchy()).iter('node')
           if n.get('package')==PACKAGE and n.get('visible-to-user')!='false']
    if any(n.get('class')=='android.widget.EditText' and n.get('password')=='true' for n in nodes):
        return 'signed_out'
    phrases={'disconnected','connection lost','you were disconnected','відключено','з’єднання втрачено','соединение потеряно','отключено'}
    if any(n.get('text','').strip().casefold() in phrases for n in nodes): return 'disconnected'
    return None


class RecoveryWatchdog:
    def __init__(self,panel,flow,clock=time.monotonic,probe=ui_problem):
        self.panel,self.flow,self.clock,self.probe=panel,flow,clock,probe
        self.lock=threading.RLock();self.halt=threading.Event();self.thread=None
        self.records={};self.generation=None;self.last_probe=0

    def snapshot(self):
        with self.panel.lock: enabled=self.panel.data.get('recoveryEnabled',True)
        with self.lock:
            return {'enabled':enabled,'sessions':[dict(v) for v in self.records.values()]}

    def set_enabled(self,body):
        if type(body.get('enabled')) is not bool: raise ValueError('enabled має бути true/false')
        with self.panel.lock:
            self.panel.data['recoveryEnabled']=body['enabled'];self.panel.save()
        if body['enabled']:
            with self.lock: self.records.clear()
        return {'ok':True}

    def targets(self):
        with self.panel.lock:
            allowed=self.panel.allowed_serials or set()
            return [copy.deepcopy(a) for a in self.panel.data['accounts'] if a['enabled'] and a['serial'] in allowed
                    and self.panel.controlled_apps.get(a['serial'])==PACKAGE]

    def start(self):
        self.thread=threading.Thread(target=self.loop,daemon=True,name='account-recovery');self.thread.start()

    def loop(self):
        while not self.halt.wait(5):
            try: self.tick()
            except Exception: pass  # A failed probe must not tear down the panel or leak RPC data.

    def tick(self):
        if self.halt.is_set() or self.panel.suspended or self.flow.stop_event.is_set(): return
        with self.panel.lock:
            if not self.panel.data.get('recoveryEnabled',True): return
            devices=copy.deepcopy(self.panel.devices)
            pressure=self.panel.resources.get('pauseNewLaunches',False)
        with self.flow.lock:
            if self.flow.state['running'] or self.flow.closing_all: return
            generation=self.flow.generation
        now=self.clock()
        targets=self.targets()
        with self.panel.lock: self.panel.recovery_serials={a['serial'] for a in targets}
        with self.lock:
            if generation!=self.generation:
                self.records.clear();self.generation=generation
            active={a['id'] for a in targets}
            self.records={k:v for k,v in self.records.items() if k in active}
        probed=False
        for account in targets:
            serial=account['serial'];device=devices.get(serial)
            with self.lock:
                rec=self.records.setdefault(account['id'],{'accountId':account['id'],'serial':serial,'attempts':0,'misses':0,'nextAttempt':0,'blocked':False,'stableSince':None,'uiAt':-1e9,'uiReason':None,'stage':'watching','detail':'Контроль сесії'})
                rec['serial']=serial
            if rec['blocked']: continue
            reason=None
            if not device or device.get('state')=='offline': reason='adb_missing'
            elif device.get('state')=='device' and device.get('process')=='stopped' and time.time()*1000-device.get('checked',0)<20000:
                reason='client_closed'
            elif device.get('state')=='device' and device.get('process')=='running':
                due=5 if rec['uiReason'] else 30
                if not probed and now-rec['uiAt']>=due:
                    probed=True;rec['uiAt']=now
                    try: reason=self.probe(serial)
                    except Exception: reason=None
                    rec['uiReason']=reason
                elif rec['uiReason']:
                    continue  # Need another actual UI observation, not a cached error.
                if not reason:
                    rec['misses']=0
                    if rec['stableSince'] is None: rec['stableSince']=now
                    if now-rec['stableSince']>=120:
                        rec.update(attempts=0,stage='watching',detail='Процес стабільний; UI/виконання Lua не підтверджені')
                    continue
            else: continue  # booting, unauthorized, screenshot errors are not proof of a crash.
            if not reason: continue
            rec['stableSince']=None;rec['misses']+=1
            if rec['misses']<3 or now<rec['nextAttempt']: continue
            if pressure:
                rec.update(stage='waiting_resources',detail='Відновлення очікує вільні ресурси ПК');continue
            if rec['attempts']>=6:
                rec.update(blocked=True,stage='needs_attention',detail='6 невдалих/нестабільних відновлень; потрібна перевірка');continue
            if self.halt.is_set() or self.panel.suspended or self.flow.stop_event.is_set(): return
            old_attempts=rec['attempts'];rec['attempts']+=1
            rec['nextAttempt']=now+min(300,15*2**(rec['attempts']-1))
            rec.update(misses=0,stage='recovering',detail='Відновлюю лише цю сесію: '+reason)
            try:
                self.flow._begin(lambda a=account,r=reason:self.recover(a,r),reset=False)
            except ValueError:
                rec['attempts']=old_attempts
            return  # One heavy recovery at a time; healthy accounts remain running.

    def publish(self,account,stage,detail):
        with self.lock:
            rec=self.records.get(account['id'])
            if rec: rec.update(stage=stage,detail=detail,serial=account['serial'])
        self.flow.key_state(account['serial'],account['id'],stage,detail)

    def check(self,account):
        if self.halt.is_set() or self.panel.suspended or self.flow.stop_event.is_set(): raise RecoveryAttention('Відновлення скасовано')
        SessionKeys(self.panel,self.flow.key_state).binding(account['serial'],account)

    def check_memory(self):
        with self.panel.lock:
            free=self.panel.resources.get('availableGB')
        with self.flow.lock:
            guest=(self.flow.state.get('profile') or {}).get('guestGB',2)
        if free is not None and free<guest+2:
            raise RecoveryRetry('Бракує RAM для нового інстанса з резервом; повторю пізніше')

    def reconnect(self,account,item):
        tuner=make_tuner(item,self.panel.path.parent)
        index=account.get('instanceIndex')
        if tuner.manager:
            entries=tuner.instances()
            if index is None:
                matched=[v for v in entries if v.get('port')==serial_port(account['serial'])]
                if len(matched)!=1: raise RecoveryAttention('Невідомий індекс інстанса; інші вікна не перезапускалися')
                index=matched[0]['index']
            instance=next((v for v in entries if str(v['index'])==str(index)),None)
            if instance is None: raise RecoveryAttention('Збережений інстанс не знайдено')
            if not instance['running']:
                self.check(account)
                with self.panel.lock:
                    if self.panel.resources.get('pauseNewLaunches'): raise RecoveryAttention('Недостатньо ресурсів для запуску')
                self.check_memory()
                self.flow.managed.native_launch(item,tuner,index)
                tuner.start_instance(index)
            tuner.wait_ready(index,self.flow.stop_event)
        else:
            # No guessed default launch when several accounts may share this installation.
            with self.panel.lock:
                count=sum(a['enabled'] and a.get('emulatorId',self.panel.data.get('emulator'))==item['id'] for a in self.panel.data['accounts'])
            if count!=1: raise RecoveryAttention('Для адресного перезапуску цього емулятора потрібен сумісний CLI')
            import psutil
            wanted=os.path.normcase(str(Path(item['path']).resolve()))
            running=any(p.info.get('exe') and os.path.normcase(str(Path(p.info['exe']).resolve()))==wanted for p in psutil.process_iter(['exe']))
            if not running:
                self.check(account)
                import subprocess
                self.check_memory()
                proc=self.flow.launcher([item['path']],cwd=str(Path(item['path']).parent),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),shell=False)
                self.flow.managed.process_launch(proc)
        deadline=self.clock()+180
        while self.clock()<deadline:
            self.check(account)
            ports=self.flow.port_reader(item)
            if tuner.manager:
                entry=next((v for v in tuner.instances() if str(v['index'])==str(index)),None)
                port=entry.get('port') if entry else None
                if port: ports=[p for p in ports if p==port]
                else: ports=[]  # Never borrow another instance's sole visible port.
            else:
                ports=[p for p in ports if p==serial_port(account['serial'])]
            for port in ports:
                try: self.panel.adb('connect','127.0.0.1:'+str(port),timeout=2)
                except Exception: pass
            connected=selected_devices(self.panel.adb('devices','-l').decode('utf-8','replace'),ports)
            if len(connected)==1 and self.panel.adb('shell','getprop','sys.boot_completed',serial=connected[0]).strip()==b'1':
                serial=connected[0]
                with self.panel.lock:
                    live=next(a for a in self.panel.data['accounts'] if a['id']==account['id'])
                    if any(a['id']!=live['id'] and a['serial']==serial for a in self.panel.data['accounts']): raise RecoveryAttention('Новий ADB-порт зайнятий іншим акаунтом')
                    old=account['serial'];live['serial']=serial
                    if tuner.manager: live.update(emulatorId=item['id'],instanceIndex=index)
                    self.panel.allowed_serials.discard(old);self.panel.allowed_serials.add(serial)
                    self.panel.recovery_serials.discard(old);self.panel.recovery_serials.add(serial)
                    if old!=serial: self.panel.controlled_apps.pop(old,None)
                    self.panel.save();account.update(live)
                with self.flow.lock:
                    self.flow.state['serials']=[serial if s==old else s for s in self.flow.state['serials']]
                    if old!=serial: self.flow.state['sessionKeys'].pop(old,None)
                return serial
            if self.flow.stop_event.wait(3): break
        raise RecoveryRetry('Не підтверджено ADB саме цього інстанса; повторю пізніше')

    def recover(self,account,reason):
        try:
            self.check(account)
            self.publish(account,'recovering','Відновлюю акаунт; інші сесії залишаються активними')
            with self.panel.lock:
                options=copy.deepcopy(self.panel.data.get('lastRun',{}))
                item_id=account.get('emulatorId',options.get('id',self.panel.data.get('emulator')))
            item=next((i for i in self.flow.items if i['id']==item_id),None)
            if not item: raise RecoveryAttention('Не знайдено збережений емулятор')
            if reason=='adb_missing': self.reconnect(account,item)
            self.check(account)
            serial=account['serial']
            if reason in {'adb_missing','client_closed'}:
                self.panel.launch_package(serial,PACKAGE)
            if options.get('setupDelta') and reason!='disconnected':
                try:
                    result=prepare_account(self.panel,serial,account,self.flow.stop_event,self.flow.stage)
                except Exception:
                    raise RecoveryAttention('Вхід не підтверджено; перевірте пароль, форму, CAPTCHA або 2FA')
                if result=='cancelled': return
            else:
                game=place_id(account.get('placeId'))
                if not game: raise RecoveryAttention('Для повторного входу потрібен Place ID акаунта')
                self.panel.adb('shell','am','start','-W','-a','android.intent.action.VIEW','-d','roblox://placeId='+game,'-p',PACKAGE,serial=serial,timeout=40)
            self.check(account)
            if options.get('autoKeys'):
                result=SessionKeys(self.panel,self.flow.key_state).run(serial,account,self.flow.stop_event)
                if result not in {'accepted','already_unlocked'}: raise RecoveryAttention('Вхід/ключ потребує перевірки у прев’ю')
                if options.get('runScript'):
                    with self.panel.lock:
                        live=next(a for a in self.panel.data['accounts'] if a['id']==account['id'])
                        config=copy.deepcopy(next(c for c in self.panel.data['configs'] if c['id']==live.get('configId',self.panel.data['active'])))
                    result=ScriptStep(self.panel,self.flow.key_state).run(serial,account,config,self.flow.stop_event)
                    if result not in {'execute_sent','skipped'}: raise RecoveryAttention('Етап скрипта потребує перевірки')
            self.publish(account,'recovery_sent','Дії відновлення надіслані; перевіряю стабільність процесу')
            self.panel.event(serial,'recovery_sent','Спроба відновлення керованого акаунта')
        except Exception as error:
            message=str(error) if isinstance(error,RecoveryAttention) else 'Команда відновлення не завершилась; повторю пізніше'
            blocked=isinstance(error,RecoveryAttention) and not isinstance(error,RecoveryRetry)
            with self.lock:
                rec=self.records.get(account['id'])
                if rec:
                    blocked=blocked or rec['attempts']>=6
                    rec['blocked']=blocked
            self.publish(account,'needs_attention' if blocked else 'recovery_wait',message)
        finally:
            with self.lock:
                rec=self.records.get(account['id'])
                if rec:
                    delay=min(300,15*2**max(0,rec['attempts']-1))
                    rec['nextAttempt']=max(rec['nextAttempt'],self.clock()+delay)

    def close(self):
        self.halt.set()
        if self.thread: self.thread.join(timeout=5)
