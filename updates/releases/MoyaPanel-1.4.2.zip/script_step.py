"""Paste user-configured Lua into the Android executor, with one Execute click."""
import re
import time
import xml.etree.ElementTree as ET
from android_setup import PACKAGE
from session_keys import AndroidKeyUI, KeyAttention, SessionKeys

EDITOR_LABEL = r'(?i)(enter (?:your )?script(?: here)?|paste (?:your )?script(?: here)?|script editor|редактор скрипта)'


class AndroidScriptUI(AndroidKeyUI):
    def script_view(self):
        gate = self.view()  # Also enforces package and unchanged process.
        root = ET.fromstring(self.device.dump_hierarchy())
        nodes = [n.attrib for n in root.iter('node') if n.get('package') == PACKAGE and n.get('visible-to-user') != 'false']
        def matches(node, pattern):
            return any(re.fullmatch(pattern, node.get(attr, '').strip()) for attr in ('text','hint','content-desc'))
        editors = [n for n in nodes if n.get('class') == 'android.widget.EditText' and n.get('password') != 'true'
                   and (matches(n, EDITOR_LABEL) or re.search(r'(?i)(?:[:/])(?:script_editor|scripteditor|code_editor)$', n.get('resource-id','')))]
        buttons = [n for n in nodes if n.get('clickable') == 'true' and matches(n, r'(?i)(execute(?: script)?|run script|виконати(?: скрипт)?)')]
        tabs = [n for n in nodes if n.get('clickable') == 'true' and matches(n, r'(?i)(executor|script editor|редактор скрипта)')]
        return {'keyGate': bool(gate['field']), 'editor': editors[0] if len(editors)==1 else None,
                'execute': buttons[0] if len(buttons)==1 else None,'tab': tabs[0] if len(tabs)==1 else None}

    def read(self, node):
        return self.control(node).get_text()


class ScriptStep:
    def __init__(self, panel, update, ui_factory=AndroidScriptUI):
        self.panel, self.update, self.ui_factory = panel, update, ui_factory

    def run(self, serial, account, config, stop, timeout=60):
        def state(stage, detail):
            self.update(serial, account['id'], stage, detail)
        try:
            # No Android interaction, including no tab opening, when executor autorun is configured.
            if config.get('executorAutoInject'):
                state('script_skipped', 'Автоінжект налаштований у виконавці; редактор і Execute не чіпалися')
                return 'skipped'
            script = config.get('luaScript','')
            if not script.strip():
                state('script_not_configured','Додайте Lua-скрипт в активний конфіг або позначте автоінжект виконавця')
                return 'needs_attention'
            guard = SessionKeys(self.panel, self.update)
            def check():
                if stop.is_set():
                    raise KeyAttention('Сценарій зупинено')
                guard.binding(serial, account)
                with self.panel.lock:
                    bound = next(a for a in self.panel.data['accounts'] if a['id'] == account['id'])
                    config_id = bound.get('configId', self.panel.data['active'])
                    active = next(c for c in self.panel.data['configs'] if c['id'] == config_id)
                    if active['id'] != config['id'] or active.get('luaScript','') != script or active.get('executorAutoInject',False):
                        raise KeyAttention('Конфіг скрипта змінився; Execute не натискатиметься')
            check()
            ui = self.ui_factory(serial)
            state('waiting_editor','Відкриваю розпізнану вкладку редактора…')
            deadline = time.monotonic()+timeout
            opened = False
            while time.monotonic()<deadline:
                check()
                view = ui.script_view()
                if view['keyGate']:
                    raise KeyAttention('Знову з’явилась форма ключа; запуск скрипта зупинено')
                if view['editor'] and view['execute']:
                    break
                if view['tab'] and not opened:
                    check()
                    ui.control(view['tab']).click()
                    opened=True
                stop.wait(.5)
            else:
                raise KeyAttention('Не розпізнано редактор/Execute; потрібна перевірка Android UI')
            check()
            editor = view['editor']
            # Once text changes, an editor without an id can no longer be targeted safely.
            if not editor.get('resource-id'):
                raise KeyAttention('Редактор не має resource-id для перевірки вставленого скрипта')
            state('pasting_script','Вставляю скрипт з активного конфіга…')
            ui.control(editor).set_text(script)
            check()
            if ui.read(editor).replace('\r\n','\n') != script.replace('\r\n','\n'):
                raise KeyAttention('Вставлення скрипта не підтверджено; Execute не натискався')
            # Refresh controls after insertion. Do not reuse a stale Execute node.
            view = ui.script_view()
            if view['keyGate'] or not view['execute']:
                raise KeyAttention('Кнопка Execute/стан доступу змінилися; натискання скасовано')
            check()
            ui.control(view['execute']).click()
            state('execute_sent','Execute натиснуто один раз; виконання Lua всередині гри не підтверджене')
            self.panel.event(serial,'execute_sent','Команду Execute надіслано; конфіг '+config['id'])
            return 'execute_sent'
        except KeyAttention as error:
            state('stopped' if stop.is_set() else 'needs_attention',str(error))
            return 'stopped' if stop.is_set() else 'needs_attention'
        except Exception:
            # Do not leak script text through RPC exceptions.
            state('needs_attention','Етап скрипта не завершено. Повторного Execute немає; перевірте прев’ю')
            return 'needs_attention'
