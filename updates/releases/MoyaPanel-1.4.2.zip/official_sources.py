"""Closed catalogue: no URLs from user input, search results or affiliate feeds."""
from urllib.parse import urlsplit
import webbrowser

CATALOG = (
    {'id':'mumu','name':'MuMu Player','url':'https://www.mumuplayer.com/','domain':'www.mumuplayer.com'},
    {'id':'ldplayer','name':'LDPlayer','url':'https://www.ldplayer.net/','domain':'www.ldplayer.net'},
    {'id':'memu','name':'MEmu','url':'https://www.memuplay.com/','domain':'www.memuplay.com'},
    {'id':'bluestacks','name':'BlueStacks','url':'https://www.bluestacks.com/','domain':'www.bluestacks.com'},
    {'id':'nox','name':'NoxPlayer','url':'https://www.bignox.com/','domain':'www.bignox.com'},
)


def catalogue():
    return [dict(item) for item in CATALOG]


def open_official(ident, opener=webbrowser.open):
    item=next((x for x in CATALOG if x['id']==ident),None)
    if item is None:
        raise ValueError('Невідомий емулятор. Довільні посилання не дозволені.')
    url=urlsplit(item['url'])
    if url.scheme!='https' or url.netloc!=item['domain'] or url.path!='/':
        raise ValueError('Некоректне офіційне джерело')
    if not opener(item['url']):
        raise RuntimeError('Не вдалося відкрити браузер. Офіційний сайт: '+item['url'])
    return {'ok':True,'name':item['name'],'url':item['url']}
