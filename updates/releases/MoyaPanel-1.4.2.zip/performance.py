"""Conservative, reversible resource profiles. Native MuMu changes require CLI readback."""
import json
import platform
from functools import lru_cache
import math
import os
import re
import subprocess
import time
from pathlib import Path

GIB = 1024 ** 3
NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


@lru_cache(maxsize=1)
def hardware_info():
    info={'cpuName':platform.processor() or 'Невідома модель CPU','gpus':[]}
    if os.name=='nt':
        try:
            script='[Console]::OutputEncoding=[Text.UTF8Encoding]::new(); @{cpu=(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name);gpu=@(Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name)} | ConvertTo-Json -Compress'
            result=subprocess.run(['powershell.exe','-NoProfile','-Command',script],capture_output=True,
                                  timeout=10,creationflags=NO_WINDOW,shell=False)
            if result.returncode==0:
                values=json.loads(result.stdout.decode('utf-8-sig','replace'))
                info['cpuName']=str(values.get('cpu') or info['cpuName'])
                names=values.get('gpu') or []
                info['gpus']=names if isinstance(names,list) else [str(names)]
        except (OSError,ValueError,subprocess.TimeoutExpired):
            pass
    return info


def recompute_capacity(profile):
    profile=dict(profile)
    capacity=max(0,min(math.floor((profile['totalGB']-profile['reserveGB'])/(profile['guestGB']+.5)),
                       max(1,(profile['logicalCPU']-2)//profile['cores'])))
    profile['estimatedInstances']=capacity
    profile['estimatedAdditional']=max(0,math.floor((profile['availableGB']-2)/(profile['guestGB']+.5)))
    return profile


def host_budget():
    import psutil
    mem=psutil.virtual_memory()
    threads=psutil.cpu_count(logical=True) or 2
    physical=psutil.cpu_count(logical=False) or max(1,threads//2)
    total=mem.total/GIB
    cpu=getattr(psutil,'cpu_percent',lambda **kw:0)(interval=None)
    hardware=hardware_info()
    gpu=' / '.join(hardware['gpus']) or 'GPU не визначено'
    if total<12 or physical<4:
        tier='Економний';guest=2;cores=min(2,physical,threads);fps=20;resolution='800x450'
    elif total>=64 and physical>=12:
        tier='Потужний';guest=4;cores=3;fps=30;resolution='1024x576'
    elif total>=24 and physical>=8:
        tier='Розширений';guest=4;cores=2;fps=30;resolution='1024x576'
    else:
        tier='Збалансований';guest=3;cores=2;fps=25;resolution='960x540'
    # Use a lower display workload when only a recognized integrated/basic GPU is present.
    integrated=bool(hardware['gpus']) and all(re.search(r'Intel.*(UHD|Iris|HD Graphics)|Radeon.*(Vega|TM)?.*Graphics|Basic Display',str(g),re.I) for g in hardware['gpus'])
    if integrated or cpu>=80 or mem.available<4*GIB:
        fps=min(fps,20);resolution='800x450'
    reserve=max(3,total*.25)
    return recompute_capacity({'tier':tier,'totalGB':round(total,1),'availableGB':round(mem.available/GIB,1),
        'logicalCPU':threads,'physicalCPU':physical,'cpuName':hardware['cpuName'],'gpuName':gpu,
        'cpuPercent':cpu,'reserveGB':round(reserve,1),'guestGB':guest,'cores':cores,'fps':fps,
        'resolution':resolution,'density':160,
        'warning':'Профіль за RAM/CPU, поточним навантаженням і доступною назвою GPU. VRAM та стабільність гри не виміряні.'})


def json_output(text):
    # Managers sometimes prefix JSON with diagnostic lines.
    for i, char in enumerate(text):
        if char in '{[':
            try:
                return json.JSONDecoder().raw_decode(text[i:])[0]
            except ValueError:
                pass
    raise RuntimeError('CLI емулятора не повернув коректний JSON')


def truth(value):
    return value is True or str(value).lower() in {'1','true','yes'}


def instances_from_info(value):
    result = {}
    def visit(node, hint=None):
        if isinstance(node,list):
            for item in node:
                visit(item)
        if isinstance(node,dict):
            index = next((node[k] for k in ('index','player_index','vm_index','vmindex') if k in node),hint)
            state_fields = ('is_process_started','is_android_started','running')
            if str(index).isdigit() and any(k in node for k in state_fields):
                port=node.get('adb_port',node.get('adb_host_port'))
                result[int(index)] = {'index':int(index), 'running':any(truth(node.get(k)) for k in state_fields),
                                      'ready':truth(node.get('is_android_started')),
                                      'port':int(port) if str(port).isdigit() and 1<=int(port)<=65535 else None}
            for key, child in node.items():
                if isinstance(child,(dict,list)):
                    visit(child, key if str(key).isdigit() else None)
    visit(value)
    return sorted(result.values(),key=lambda x:x['index'])


def settings_from_json(value):
    if isinstance(value,dict):
        if 'performance_mode' in value:
            return value
        for child in value.values():
            found=settings_from_json(child)
            if found:
                return found
    if isinstance(value,list):
        for child in value:
            found=settings_from_json(child)
            if found:
                return found
    return None


class MuMuTuner:
    native_fields=('CPU','RAM','FPS')
    def __init__(self, item, directory, runner=subprocess.run, budget=host_budget):
        self.item=item
        self.directory=Path(directory)
        self.runner=runner
        self.budget=budget
        root=Path(item['root'])
        choices=[Path(item['path']).parent/'MuMuManager.exe', root/'shell/MuMuManager.exe',
                 root/'nx_main/MuMuManager.exe',root/'MuMuManager.exe']
        self.manager=next((p for p in choices if p.is_file()),None) if item['name']=='MuMu Player' else None

    def call(self,*args,timeout=25):
        result=self.runner([str(self.manager),*map(str,args)],capture_output=True,timeout=timeout,
                           creationflags=NO_WINDOW,shell=False)
        output=result.stdout.decode('utf-8','replace')
        if result.returncode:
            raise RuntimeError('MuMu CLI: '+(result.stderr.decode('utf-8','replace') or output)[:300])
        return output

    def instances(self):
        if not self.manager:
            return []
        raw=json_output(self.call('info','-v','all'))
        info=instances_from_info(raw)
        if not info and raw not in ({},[]):
            raise RuntimeError('Версія MuMu CLI не дала індекси/стан інстансів. CPU/RAM не змінювалися.')
        return info

    def create_instance(self,cancel):
        # Ask the installed CLI about its contract before mutating anything.
        help_text=self.call('create','--help')
        if not re.search(r'--number\b',help_text):
            raise RuntimeError('Ця версія MuMu CLI не підтвердила підтримку create --number')
        if cancel.is_set():
            raise RuntimeError('Створення інстанса скасовано')
        self.call('create','--number','1',timeout=180)

    def wait_ready(self,index,cancel):
        deadline=time.monotonic()+150
        while time.monotonic()<deadline:
            state=next((x for x in self.instances() if x['index']==index),None)
            if state and state['ready']:
                return
            if cancel.wait(1):
                return
        raise RuntimeError('Інстанс '+str(index)+' не підтвердив готовність Android за 150 с')

    def read(self,index):
        values=settings_from_json(json_output(self.call('setting','-v',index,'-aw')))
        if not values:
            raise RuntimeError('Немає читабельних налаштувань MuMu. Нічого не змінено.')
        return values

    def write(self,index,key,value):
        self.call('setting','-v',index,'-k',key,'-val',value)

    @staticmethod
    def equivalent(a,b):
        try:
            return abs(float(a)-float(b))<.001
        except (ValueError,TypeError):
            return str(a).lower()==str(b).lower()

    def stop_instance(self,index,cancel):
        self.call('control','-v',index,'shutdown')
        deadline=time.monotonic()+75
        while time.monotonic()<deadline:
            state=next((x for x in self.instances() if x['index']==index),None)
            if state and not state['running']:
                return
            if cancel.wait(1):
                raise RuntimeError('Налаштування скасовано під час зупинки інстанса')
        raise RuntimeError('MuMu не підтвердив зупинку інстанса; CPU/RAM не змінювалися.')

    def set_verified(self,index,desired,original):
        changed=[]
        try:
            for key,value in desired.items():
                if self.equivalent(original.get(key),value):
                    continue
                changed.append(key)
                self.write(index,key,value)
            invalid=list(desired)
            for attempt in range(3):
                after=self.read(index)
                invalid=[key for key,value in desired.items() if not self.equivalent(after.get(key),value)]
                if not invalid:
                    break
                if attempt<2:
                    time.sleep(.25)
            if invalid:
                raise RuntimeError(self.item['name']+' не підтвердив зміни: '+', '.join(invalid))
        except Exception as error:
            failed=[]
            for key in reversed(changed):
                try:
                    self.write(index,key,original[key])
                except Exception:
                    failed.append(key)
            try:
                rolled=self.read(index)
                failed.extend(k for k in changed if not self.equivalent(rolled.get(k),original[k]))
            except Exception:
                failed.extend(changed)
            if failed:
                raise RuntimeError('Помилка налаштування та неповний відкат: '+', '.join(failed)) from error
            raise RuntimeError(self.item['name']+' відхилив профіль; змінені значення повернено. '+str(error)) from error

    def backup(self,index,values):
        folder=self.directory/'tuning_backups'/self.item['id']
        folder.mkdir(parents=True,exist_ok=True)
        path=folder/f'instance_{index}.json'
        # Keep the original baseline across repeated one-click launches.
        if not path.exists():
            tmp=path.with_suffix('.tmp')
            tmp.write_text(json.dumps({'index':index,'values':values},ensure_ascii=False,indent=2),encoding='utf-8')
            os.replace(tmp,path)
        return path

    def profile_for_host(self,profile):
        return dict(profile)

    def desired(self,profile):
        return {'performance_mode':'custom','performance_cpu.custom':str(profile['cores']),
                'performance_mem.custom':str(profile['guestGB']),'max_frame_rate':str(profile['fps'])}

    def start_instance(self,index):
        self.call('control','-v',index,'launch')

    def apply(self,instance,profile,cancel):
        index=instance['index']
        live=self.budget()
        if not instance['running'] and live.get('cpuPercent',0)>92:
            raise RuntimeError('CPU вже перевантажений; новий інстанс не запускається.')
        values=self.read(index)
        desired=self.desired(profile)
        # All keys must actually be readable in this installed version before any change.
        missing=set(desired)-values.keys()
        if missing:
            raise RuntimeError('Версія емулятора не підтримує потрібні ключі: '+', '.join(sorted(missing)))
        original={key:values[key] for key in desired}
        self.backup(index,original)
        changed=any(not self.equivalent(original[k],v) for k,v in desired.items())
        # CPU/RAM settings require a stopped VM; never edit live config files.
        if changed and instance['running']:
            self.stop_instance(index,cancel)
        self.set_verified(index,desired,original)
        if cancel.is_set():
            return False
        if not instance['running'] or changed:
            if self.budget()['availableGB'] < profile['guestGB']+2:
                raise RuntimeError('Мало вільної RAM для нового запуску з резервом 2 ГБ. Інстанс не запущено.')
            self.start_instance(index)
        return changed

    def restore(self,cancel):
        if not self.manager:
            raise RuntimeError('Немає сумісного vendor CLI для відновлення')
        files=sorted((self.directory/'tuning_backups'/self.item['id']).glob('instance_*.json'))
        if not files:
            raise RuntimeError('Резервних копій CPU/RAM/FPS для цього емулятора немає')
        restored=[]
        for path in files:
            if cancel.is_set():
                break
            backup=json.loads(path.read_text(encoding='utf-8'))
            index=backup['index']
            state=next((x for x in self.instances() if x['index']==index),None)
            if state is None:
                continue
            before=self.read(index)
            if state['running']:
                self.stop_instance(index,cancel)
            desired=backup['values']
            self.set_verified(index,desired,before)
            if state['running'] and not cancel.is_set():
                self.start_instance(index)
            restored.append(index)
        return restored


def tune_android(panel,serial,directory,namespace='default',profile=None):
    """Keep Android UI light; store the exact prior overrides for restoration."""
    folder=Path(directory)/'tuning_backups'/namespace/'android'
    folder.mkdir(parents=True,exist_ok=True)
    safe=re.sub(r'[^A-Za-z0-9_-]','_',serial)
    path=folder/(safe+'.json')
    resolution=(profile or {}).get('resolution','960x540')
    density_value=str((profile or {}).get('density',160))
    keys=('window_animation_scale','transition_animation_scale','animator_duration_scale')
    if not path.exists():
        original={key:panel.adb('shell','settings','get','global',key,serial=serial).decode().strip() for key in keys}
        original['size']=panel.adb('shell','wm','size',serial=serial).decode('utf-8','replace')
        original['density']=panel.adb('shell','wm','density',serial=serial).decode('utf-8','replace')
        path.write_text(json.dumps(original),encoding='utf-8')
    for key in keys:
        panel.adb('shell','settings','put','global',key,'0',serial=serial)
    panel.adb('shell','wm','size',resolution,serial=serial)
    panel.adb('shell','wm','density',density_value,serial=serial)
    size=panel.adb('shell','wm','size',serial=serial).decode('utf-8','replace')
    density=panel.adb('shell','wm','density',serial=serial).decode('utf-8','replace')
    sizes=re.findall(r'(?:Physical|Override) size:\s*([0-9x]+)',size)
    densities=re.findall(r'(?:Physical|Override) density:\s*([0-9]+)',density)
    if not sizes or sizes[-1]!=resolution or not densities or densities[-1]!=density_value:
        raise RuntimeError('Android не підтвердив '+resolution+' / '+density_value+' DPI; зменшення графічного навантаження не підтверджено')


def restore_android(panel,serial,directory,namespace='default'):
    safe=re.sub(r'[^A-Za-z0-9_-]','_',serial)
    path=Path(directory)/'tuning_backups'/namespace/'android'/(safe+'.json')
    if not path.exists():
        return False
    data=json.loads(path.read_text(encoding='utf-8'))
    for key in ('window_animation_scale','transition_animation_scale','animator_duration_scale'):
        value=data[key]
        if value in {'null',''}:
            panel.adb('shell','settings','delete','global',key,serial=serial)
        else:
            panel.adb('shell','settings','put','global',key,value,serial=serial)
    for name in ('size','density'):
        match=re.search(r'Override '+name+r':\s*([0-9x]+)',data[name])
        panel.adb('shell','wm',name,match.group(1) if match else 'reset',serial=serial)
    return True
