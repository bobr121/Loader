import asyncio
import json
import os
import re
import sys

from playwright.async_api import async_playwright

try:
    import pyperclip  # копіювання в буфер обміну (pip install pyperclip)
except ImportError:
    pyperclip = None

HERE = os.path.dirname(os.path.abspath(__file__))
SAVE_KEY = True
EXTRA_BUTTONS = ("Proceed", "Verify")
SKIP_INPUT_TYPES = {"hidden", "password", "checkbox", "radio", "submit", "button", "file", "image", "reset"}


async def find_button(page, label):
    """Видима кнопка, текст якої точно дорівнює label (а не блок, де це слово просто трапляється)."""
    exact = re.compile(rf"^\s*{re.escape(label)}\s*$", re.I)
    for selector, pick_last in (("button, a, [role=button], input[type=submit]", False), ("div, span", True)):
        loc = page.locator(selector).filter(has_text=exact)
        try:
            count = await loc.count()
            if count:
                el = loc.nth(count - 1) if pick_last else loc.first  # у вкладених div беремо найглибший
                if await el.is_visible():
                    return el
        except Exception:
            pass
    return None


async def find_key_on(page):
    """Шукає ключ на одній сторінці. Повертає рядок або None."""
    # Спосіб 1: видимі input / textarea з готовим текстом
    try:
        inputs = await page.locator("input, textarea").all()
    except Exception:
        inputs = []
    candidates = []
    for inp in inputs:
        try:
            if not await inp.is_visible():
                continue
            kind = (await inp.get_attribute("type") or "").lower()
            if kind in SKIP_INPUT_TYPES:
                continue
            val = (await inp.input_value()).strip()
            if val.startswith("FREE_"):  # ключ з відомим префіксом беремо одразу
                return val
            if val and len(val) > 10 and not val.lower().startswith(("http://", "https://")):  # ключі зазвичай довгі рядки
                candidates.append(val)
        except Exception:
            pass
    if candidates:
        return candidates[0]

    # Спосіб 2: спеціальний блок з ключем (код або текст)
    try:
        code_block = page.locator("code, pre, .key-string, .token")
        if await code_block.count() > 0:
            txt = (await code_block.first.inner_text()).strip()
            if txt:
                return txt
    except Exception:
        pass
    return None


async def find_key(context, page, seconds):
    """Шукає ключ на основній сторінці та в інших відкритих вкладках, поки не мине час."""
    print("[+] Шукаю ключ на сторінці...")
    for _ in range(max(1, seconds)):
        for pg in [page] + [x for x in context.pages if x is not page]:
            key = await find_key_on(pg)
            if key:
                return key
        await asyncio.sleep(1)
    return None


def report_key(key, copy_key):
    print(f"[УСПІХ] Знайдено ключ: {key}")
    # Службовий рядок: панель забирає з нього ключ у віконце «Ключ»
    print("[KEY] " + json.dumps(key, ensure_ascii=False))
    if copy_key:
        if pyperclip:
            try:
                pyperclip.copy(key)
                print("[+] Ключ успішно скопійовано в буфер обміну!")
            except Exception as e:
                print(f"[!] Не вдалося скопіювати в буфер: {e}")
        else:
            print("[!] pyperclip не встановлено, ключ не скопійовано в буфер.")
    # Також зберігаємо у файл key.txt для надійності
    if SAVE_KEY:
        with open(os.path.join(HERE, "key.txt"), "w", encoding="utf-8") as f:
            f.write(key)


async def run_key_system(start_url: str, show_browser: bool = True, close_popups: bool = True,
                         continue_wait: int = 20, claim_wait: int = 180, final_wait: int = 15,
                         key_wait: int = 20, copy_key: bool = True):
    async with async_playwright() as p:
        # Запускаємо браузер (headless=False дозволяє бачити процес візуально)
        browser = await p.chromium.launch(
            headless=not show_browser,
            args=["--disable-blink-features=AutomationControlled"]
        )
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )
        page = await context.new_page()

        print(f"[+] Відкриваю посилання: {start_url}")
        await page.goto(start_url, wait_until="networkidle")

        # Функція для закриття зайвих рекламних вкладок (pop-ups), які відкриваються при кліках
        async def close_extra_tabs():
            if not close_popups:
                return
            pages = context.pages
            if len(pages) > 1:
                for p_tab in pages[1:]:
                    print("[!] Закриваю рекламну вкладку...")
                    try:
                        await p_tab.close()
                    except Exception:
                        pass
                await page.bring_to_front()

        try:
            # Крок 1: Очікування таймера та натискання першої кнопки Continue
            print("[+] Чекаємо на завершення таймера та появу кнопки Continue...")
            for _ in range(max(1, continue_wait)):
                await close_extra_tabs()
                try:
                    continue_btn = await find_button(page, "Continue")
                    if continue_btn:
                        await continue_btn.click()
                        print("[+] Кнопку Continue натиснуто!")
                        break
                except Exception:
                    pass
                await asyncio.sleep(1)
            else:
                print("[!] Кнопку Continue не знайдено, йду далі...")

            await asyncio.sleep(3)
            await close_extra_tabs()

            # Крок 2: Очікування фінальної кнопки Claim Reward (після завдань)
            print("[+] Очікуємо виконання завдань / появи кнопки Claim Reward...")
            for _ in range(max(1, claim_wait // 2)):
                await close_extra_tabs()

                # Проміжні кнопки, якщо сайт їх показує
                for label in EXTRA_BUTTONS:
                    try:
                        btn = await find_button(page, label)
                        if btn:
                            await btn.click(timeout=1000)
                            print(f"[+] Натиснуто: {label}")
                    except Exception:
                        pass

                claim_btn = await find_button(page, "Claim Reward")
                if claim_btn:
                    print("[+] Знайдено кнопку Claim Reward! Натискаю...")
                    try:
                        await claim_btn.click()
                        break
                    except Exception as e:
                        print(f"[!] Не вдалося натиснути Claim Reward: {e}")

                await asyncio.sleep(2)
            else:
                print("[-] Кнопка Claim Reward так і не з'явилась.")

            # Крок 3: Забираємо ключ (вкладки тут не закриваємо: ключ може відкритися в новій)
            await asyncio.sleep(2)
            key = await find_key(context, page, key_wait)
            if key:
                report_key(key, copy_key)
                print("[+] Готово! Ключ у віконці «Ключ».")
            else:
                print("[-] Не вдалося автоматично знайти ключ на сторінці. Можливо, структура відрізняється.")
            await asyncio.sleep(max(0, final_wait))

        except Exception as e:
            print(f"[-] Сталася помилка під час виконання: {e}")

        await browser.close()


async def get_existing_key(start_url: str, show_browser: bool = True, key_wait: int = 20, copy_key: bool = True):
    """Лише ключ: відкриває посилання і забирає ключ, який уже є на сторінці."""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=not show_browser)
        context = await browser.new_context()
        page = await context.new_page()

        print(f"[+] Відкриваю посилання: {start_url}")
        await page.goto(start_url, wait_until="networkidle")

        try:
            key = await find_key(context, page, key_wait)
            if key:
                report_key(key, copy_key)
            else:
                print("[-] Не вдалося автоматично знайти ключ на сторінці. Можливо, структура відрізняється.")
        except Exception as e:
            print(f"[-] Сталася помилка: {e}")

        await asyncio.sleep(3)
        await browser.close()


# Панель передає параметри одним JSON-аргументом
if __name__ == "__main__":
    cfg = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    SAVE_KEY = bool(cfg.get("saveKey", True))
    link = cfg.get("url") or "ТУТ_ВСТАВТЕ_ПОСИЛАННЯ"
    show = bool(cfg.get("showBrowser", True))
    key_wait = int(cfg.get("keyWait", 20))
    copy_key = bool(cfg.get("copyKey", True))
    if cfg.get("mode") == "key":
        asyncio.run(get_existing_key(link, show_browser=show, key_wait=key_wait, copy_key=copy_key))
    else:
        asyncio.run(run_key_system(
            link,
            show_browser=show,
            close_popups=bool(cfg.get("closePopups", True)),
            continue_wait=int(cfg.get("continueWait", 20)),
            claim_wait=int(cfg.get("claimWait", 180)),
            final_wait=int(cfg.get("finalWait", 15)),
            key_wait=key_wait,
            copy_key=copy_key,
        ))
