"""Signed, staged updates. Apply only under the desktop process lock before runtime starts."""
import base64
import contextlib
import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

MAX_ARCHIVE=20*1024*1024
ROOT_FILES={'automation.py','server.py','desktop.py','launcher.py','emulators.py','performance.py',
'official_sources.py','vendor_adapters.py','key_jobs.py','key_system.py','android_setup.py',
'session_keys.py','script_step.py','managed_resources.py','control_center.py','recovery.py',
'updater.py','requirements.txt','version.json','start.bat','MoyaPanel.vbs','Install.bat','install.ps1',
'README.txt','INTEGRATION.md','icon.ico'}
APP_FILES={'app/index.html','app/panel.js','app/panel.css'}


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')


def read_json(path,default=None):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default


def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.tmp')
    temporary.write_bytes(canonical(value));os.replace(temporary,path)


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1024*1024),b''): h.update(data)
    return h.hexdigest()


def safe_name(name):
    if name in {'bootstrap.py','update_config.json'}: raise ValueError('Immutable update trust/entry file')
    if not isinstance(name,str) or '\\' in name or ':' in name or name.startswith('/') or any(v in {'.','..',''} for v in name.split('/')):
        raise ValueError('Unsafe update path')
    module=bool(re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*\.py',name))
    asset=name.startswith('app/') and PurePosixPath(name).suffix.lower() in {'.html','.css','.js','.json','.svg','.png','.ico','.woff','.woff2'}
    if name not in ROOT_FILES|APP_FILES and not module and not asset: raise ValueError('Protected or unknown update file: '+name)
    return name


def fetch(url,limit):
    parsed=urlsplit(url)
    if parsed.scheme!='https' or parsed.hostname!='raw.githubusercontent.com' or not parsed.path.startswith('/bobr121/Loader/') or parsed.username or parsed.password:
        raise ValueError('Untrusted update address')
    with urlopen(Request(url,headers={'User-Agent':'MoyaPanel-Updater/1','Cache-Control':'no-cache'}),timeout=30) as response:
        final=urlsplit(response.url)
        if final.scheme!='https' or final.hostname!='raw.githubusercontent.com': raise ValueError('Unexpected redirect')
        data=response.read(limit+1)
        if len(data)>limit: raise ValueError('Update exceeds size limit')
        return data


def verify(envelope,config):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    payload=envelope['payload']
    Ed25519PublicKey.from_public_bytes(base64.b64decode(config['publicKey'],validate=True)).verify(
        base64.b64decode(envelope['signature'],validate=True),canonical(payload))
    if type(payload.get('sequence')) is not int or payload['sequence']<1: raise ValueError('Invalid release sequence')
    if not re.fullmatch(r'\d+\.\d+\.\d+',payload.get('version','')): raise ValueError('Invalid version')
    files=payload['files']
    if not isinstance(files,dict) or not 1<=len(files)<=100: raise ValueError('Invalid update inventory')
    for name,sha in files.items():
        safe_name(name)
        if not re.fullmatch('[a-f0-9]{64}',sha): raise ValueError('Invalid file hash')
    if not {'desktop.py','updater.py','requirements.txt','version.json'}<=files.keys(): raise ValueError('Incomplete release')
    if type(payload.get('size')) is not int or not 0<payload['size']<=MAX_ARCHIVE: raise ValueError('Invalid archive size')
    return payload


class ApplicationLock:
    def __init__(self,root): self.path=Path(root)/'.update/app.lock';self.file=None
    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open('a+b');self.file.seek(0);self.file.write(b'0');self.file.flush()
        deadline=time.monotonic()+5
        while True:
            try:
                self.file.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
                return self
            except OSError:
                if time.monotonic()>=deadline:
                    self.file.close();raise RuntimeError('MoyaPanel already running in this folder')
                time.sleep(.1)
    def __exit__(self,*args): self.file.close()


class UpdateManager:
    def __init__(self,root):
        self.root=Path(root).resolve();self.folder=self.root/'.update';self.folder.mkdir(exist_ok=True)
        self.lock=threading.RLock();self.halt=threading.Event();self.thread=None
        self.config=read_json(self.root/'update_config.json',{})
        self.restart=False;self.restart_callback=None;self.gui_loaded=False
        self.state={'stage':'idle' if self.config else 'unconfigured','detail':'Автоматична перевірка оновлень','version':read_json(self.root/'version.json',{}).get('version','1.2.0')}
    def snapshot(self):
        with self.lock: return dict(self.state)
    def status(self,stage,detail):
        with self.lock: self.state.update(stage=stage,detail=detail)
    def current_sequence(self): return read_json(self.root/'version.json',{}).get('sequence',0)
    def check(self):
        if not self.config: return
        self.status('checking','Перевіряю нову версію…')
        envelope=json.loads(fetch(self.config['manifestUrl'],256*1024))
        release=verify(envelope,self.config)
        failed=read_json(self.folder/'failed.json',[])
        if release['sequence']<=self.current_sequence() or release['sequence'] in failed:
            self.status('current','Встановлена актуальна доступна версія');return
        pending=read_json(self.folder/'pending.json',{})
        if pending.get('payload',{}).get('sequence')==release['sequence']:
            self.status('pending','Версію '+release['version']+' буде встановлено під час наступного запуску');return
        self.status('downloading','Завантажую версію '+release['version']+'…')
        data=fetch(release['archiveUrl'],MAX_ARCHIVE)
        if len(data)!=release['size'] or hashlib.sha256(data).hexdigest()!=release['sha256']: raise ValueError('Update archive hash mismatch')
        archive=self.folder/'incoming.zip';archive.write_bytes(data)
        stage=self.folder/'incoming';shutil.rmtree(stage,ignore_errors=True);stage.mkdir()
        try:
            with zipfile.ZipFile(archive) as z:
                names=[v.filename for v in z.infolist()]
                if len(names)!=len(set(n.casefold() for n in names)) or set(names)!=set(release['files']): raise ValueError('Archive inventory mismatch')
                total=0
                for entry in z.infolist():
                    name=safe_name(entry.filename)
                    if (entry.external_attr>>16)&0o170000==0o120000: raise ValueError('Symlink in update')
                    total+=entry.file_size
                    if total>50*1024*1024: raise ValueError('Expanded update too large')
                    content=z.read(entry)
                    if hashlib.sha256(content).hexdigest()!=release['files'][name]: raise ValueError('File hash mismatch')
                    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
            version=read_json(stage/'version.json')
            if version!={'version':release['version'],'sequence':release['sequence']}: raise ValueError('Release version mismatch')
            ready=self.folder/('stage-'+str(release['sequence']))
            shutil.rmtree(ready,ignore_errors=True);os.replace(stage,ready)
            write_json(self.folder/'pending.json',envelope)
        finally:
            archive.unlink(missing_ok=True);shutil.rmtree(stage,ignore_errors=True)
        self.status('pending','Версію '+release['version']+' підготовлено. Автоматичне встановлення — під час наступного запуску')
    def start(self):
        if not self.config:return
        def loop():
            delay=random.uniform(10,90)
            while not self.halt.wait(delay):
                try:
                    self.check();delay=random.uniform(5*3600,7*3600)
                except Exception:
                    self.status('offline','Не вдалося перевірити оновлення; поточна версія працює. Повторю пізніше')
                    delay=random.uniform(600,1200)
        self.thread=threading.Thread(target=loop,daemon=True,name='updates');self.thread.start()
    def close(self): self.halt.set()
    def environment(self):
        relative=read_json(self.folder/'active-env.json','.venv')
        if relative!='.venv' and not re.fullmatch(r'\.update/env-\d+',relative): raise ValueError('Invalid runtime path')
        folder=(self.root/relative).resolve()
        if not folder.is_relative_to(self.root): raise ValueError('Runtime outside application')
        return folder/('Scripts/pythonw.exe' if os.name=='nt' else 'bin/python')
    def target(self,name):
        target=self.root/safe_name(name)
        if not target.resolve().is_relative_to(self.root) or target.is_symlink(): raise ValueError('Unsafe target location')
        return target
    def rollback(self,journal):
        backup=self.folder/'backup'
        for name,existed in journal['originals'].items():
            target=self.target(name)
            if existed:
                temporary=target.with_name(target.name+'.rollback');shutil.copy2(backup/name,temporary);os.replace(temporary,target)
            else: target.unlink(missing_ok=True)
        write_json(self.folder/'active-env.json',journal['oldEnv'])
        failures=read_json(self.folder/'failed.json',[])
        write_json(self.folder/'failed.json',list(set(failures+[journal['sequence']])))
        (self.folder/'journal.json').unlink(missing_ok=True);(self.folder/'pending.json').unlink(missing_ok=True)
    def runtime_for(self,stage,sequence):
        if digest(stage/'requirements.txt')==digest(self.root/'requirements.txt'):return read_json(self.folder/'active-env.json','.venv')
        env=self.folder/('env-'+str(sequence))
        shutil.rmtree(env,ignore_errors=True)
        base=Path(sys.base_prefix)/('python.exe' if os.name=='nt' else 'bin/python3')
        flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
        with (self.folder/'runtime-install.log').open('ab') as log:
            for command in ([str(base),'-m','venv',str(env)],
                            [str(env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')),'-m','pip','install','-r',str(stage/'requirements.txt')],
                            [str(env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')),'-m','playwright','install','chromium']):
                subprocess.run(command,check=True,stdout=log,stderr=log,timeout=1800,creationflags=flags)
        return '.update/env-'+str(sequence)
    def startup(self,trial=None):
        journal=read_json(self.folder/'journal.json')
        if journal:
            if journal.get('phase')=='trial' and str(journal['sequence'])==str(trial): return False,trial
            self.rollback(journal)
            return True,None  # Re-exec restored source; this interpreter already loaded the failed files.
        pending=read_json(self.folder/'pending.json')
        if not pending:return False,None
        release=verify(pending,self.config)
        if release['sequence']<=self.current_sequence():
            (self.folder/'pending.json').unlink();return False,None
        stage=self.folder/('stage-'+str(release['sequence']))
        for name,sha in release['files'].items():
            self.target(name)
            if digest(stage/name)!=sha:raise ValueError('Staged files changed')
        new_env=self.runtime_for(stage,release['sequence'])
        backup=self.folder/'backup';shutil.rmtree(backup,ignore_errors=True);backup.mkdir()
        originals={}
        for name in release['files']:
            target=self.target(name);originals[name]=target.exists()
            if target.exists():
                saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
        journal={'sequence':release['sequence'],'oldEnv':read_json(self.folder/'active-env.json','.venv'),'originals':originals,'phase':'applying'}
        write_json(self.folder/'journal.json',journal)
        try:
            for name in release['files']:
                target=self.target(name);target.parent.mkdir(parents=True,exist_ok=True)
                temporary=target.with_name(target.name+'.update');shutil.copy2(stage/name,temporary);os.replace(temporary,target)
            write_json(self.folder/'active-env.json',new_env)
            journal['phase']='trial';write_json(self.folder/'journal.json',journal)
            return True,release['sequence']
        except Exception:
            self.rollback(journal);raise
    def window_ready(self,*args): self.gui_loaded=True
    def mark_healthy(self):
        if not self.gui_loaded: return False
        journal=read_json(self.folder/'journal.json')
        if journal and journal.get('phase')=='trial':
            (self.folder/'journal.json').unlink()
            pending=read_json(self.folder/'pending.json',{})
            if pending.get('payload',{}).get('sequence')==journal['sequence']: (self.folder/'pending.json').unlink(missing_ok=True)
            shutil.rmtree(self.folder/'backup',ignore_errors=True)
        return True
