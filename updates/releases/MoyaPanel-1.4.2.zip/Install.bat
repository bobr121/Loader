@echo off
setlocal
cd /d "%~dp0"
echo MoyaPanel automatic setup - downloading prerequisites if needed...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
 echo Setup failed. Details are in install.log next to Install.bat.
 pause
 exit /b 1
)
exit /b 0
