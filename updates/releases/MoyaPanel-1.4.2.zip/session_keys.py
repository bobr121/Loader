"""Account-bound key handoff. Unknown Android UI never counts as acceptance."""
import ipaddress
import re
import time
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit
from android_setup import PACKAGE
from key_jobs import KeyJobs


class KeyAttention(RuntimeError):
    pass


def key_url(value):
    value = str(value or '').strip()
    parsed = urlsplit(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or len(value) > 4096:
        raise KeyAttention('Не отримано коректне HTTPS-посилання на ключ')
    host = parsed.hostname.lower().rstrip('.')
    if host == 'localhost' or host.endswith(('.localhost', '.local')) or '.' not in host:
        raise KeyAttention('Локальне посилання не використовується')
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise KeyAttention('Локальне посилання не використовується')
    return value


class AndroidKeyUI:
    """Semantic native controls only; no screen coordinates or shared PC clipboard."""
    def __init__(self, serial):
        import uiautomator2 as u2
        import adbutils
        self.device = u2.connect(adbutils.AdbClient(host='127.0.0.1', port=5037).device(serial=serial))
        self.pid = None
        self.field_id = None

    def view(self):
        current = self.device.app_current()
        if current.get('package') != PACKAGE:
            raise KeyAttention('Гра не на передньому плані Android; перевірте прев’ю')
        if self.pid is None:
            self.pid = current.get('pid')
        elif current.get('pid') != self.pid:
            raise KeyAttention('Процес гри змінився; потрібне нове посилання на ключ')
        root = ET.fromstring(self.device.dump_hierarchy())
        nodes = [n.attrib for n in root.iter('node') if n.get('package') == PACKAGE and n.get('visible-to-user') != 'false']
        def label(n):
            return (n.get('text') or n.get('hint') or n.get('content-desc') or '').strip()
        fields = [n for n in nodes if n.get('class') == 'android.widget.EditText' and n.get('password') != 'true'
                  and (any(re.fullmatch(r'(?i)(enter(?: your)? key(?: here)?|paste(?: your)? key(?: here)?|key|введіть ключ|вставте ключ)', n.get(attr, '').strip()) for attr in ('text', 'hint', 'content-desc'))
                       or (self.field_id and n.get('resource-id') == self.field_id))]
        if len(fields) == 1 and fields[0].get('resource-id'):
            self.field_id = fields[0]['resource-id']
        copies = [n for n in nodes if n.get('clickable') == 'true' and re.fullmatch(r'(?i)(get key|copy key link|copy link|отримати ключ|скопіювати посилання)', label(n))]
        verifies = [n for n in nodes if n.get('clickable') == 'true' and re.fullmatch(r'(?i)(verify(?: key)?|check key|submit(?: key)?|перевірити(?: ключ)?)', label(n))]
        accepted = any(re.fullmatch(r'(?i)(key verified(?: successfully)?|key accepted|authentication successful|ключ прийнято|ключ перевірено)', label(n)) for n in nodes)
        # A recognizable script editor is also an unlocked state. A vanished dialog alone is not.
        def is_editor(n):
            return n.get('class') == 'android.widget.EditText' and n.get('password') != 'true' and (
                any(re.fullmatch(r'(?i)(enter (?:your )?script(?: here)?|paste (?:your )?script(?: here)?|script editor|редактор скрипта)',n.get(attr,'').strip()) for attr in ('text','hint','content-desc'))
                or bool(re.search(r'(?i)(?:[:/])(?:script_editor|scripteditor|code_editor)$',n.get('resource-id',''))))
        editor = any(is_editor(n) for n in nodes)
        other_edits = [n for n in nodes if n.get('class') == 'android.widget.EditText' and not is_editor(n)]
        return {'accepted': accepted or (editor and not other_edits), 'field': fields[0] if len(fields) == 1 else None,
                'copy': copies[0] if len(copies) == 1 else None, 'verify': verifies[0] if len(verifies) == 1 else None}

    def control(self, node):
        args = {'packageName': PACKAGE, 'className': node['class']}
        if node.get('resource-id'):
            args['resourceId'] = node['resource-id']
        elif node.get('text'):
            args['text'] = node['text']
        elif node.get('content-desc'):
            args['description'] = node['content-desc']
        else:
            raise KeyAttention('Поле не має однозначного Android-селектора')
        obj = self.device(**args)
        if obj.count != 1:
            raise KeyAttention('Android-контрол не знайдений однозначно')
        return obj

    def copy_url(self, node, stop):
        # Clear and verify the DEVICE clipboard before clicking; never reuse an old account's URL.
        self.device.clipboard = ''
        if self.device.clipboard:
            raise KeyAttention('Не вдалося очистити Android-буфер')
        self.control(node).click()
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline and not stop.is_set():
            value = self.device.clipboard
            if value:
                return key_url(value)
            stop.wait(.5)
        raise KeyAttention('Кнопка не скопіювала посилання в Android-буфер')

    def insert(self, node, key):
        self.control(node).set_text(key)

    def verify(self, node):
        self.control(node).click()


class SessionKeys:
    def __init__(self, panel, update, ui_factory=AndroidKeyUI, jobs_factory=KeyJobs):
        self.panel, self.update = panel, update
        self.ui_factory, self.jobs_factory = ui_factory, jobs_factory

    def binding(self, serial, account):
        with self.panel.lock:
            current = next((a for a in self.panel.data['accounts'] if a['id'] == account['id']), None)
            if not current or not current['enabled'] or current['serial'] != serial or current['login'] != account['login']:
                raise KeyAttention('Прив’язка акаунта змінилася; старий результат не вставляється')

    def run(self, serial, account, stop, timeout=180):
        jobs = None
        key = None
        def state(stage, detail, **extra):
            self.update(serial, account['id'], stage, detail, **extra)
        try:
            self.binding(serial, account)
            ui = self.ui_factory(serial)
            state('waiting_key_ui', 'Очікую форму ключа або вже відкритий редактор…')
            deadline = time.monotonic() + timeout
            while not stop.is_set() and time.monotonic() < deadline:
                self.binding(serial, account)
                view = ui.view()
                if view['accepted']:
                    state('already_unlocked', 'Доступ уже відкритий; жодних натискань')
                    return 'already_unlocked'
                if view['field'] and view['copy']:
                    break
                stop.wait(2)
            else:
                if stop.is_set():
                    state('stopped', 'Зупинено')
                    return 'stopped'
                raise KeyAttention('Не розпізнано форму ключа. Потрібна перевірка Android UI')
            state('copying_url', 'Копіюю посилання з цієї сесії…')
            url = key_url(ui.copy_url(view['copy'], stop))
            if stop.is_set():
                state('stopped', 'Зупинено')
                return 'stopped'
            self.binding(serial, account)
            state('getting_key', 'Очікую результат модуля ключів…', url=url)
            # Each session owns its subprocess/result; manual panel jobs cannot overwrite it.
            jobs = self.jobs_factory(self.panel.path.parent)
            jobs.start({'url': url, 'showBrowser': False, 'closePopups': True, 'saveKey': False})
            while jobs.snapshot()['running']:
                if stop.wait(.25):
                    jobs.stop()
                    state('stopped', 'Зупинено')
                    return 'stopped'
                self.binding(serial, account)
            result = jobs.snapshot()
            if result['stage'] != 'succeeded' or not result.get('key'):
                raise KeyAttention('Модуль не отримав ключ; вставлення не виконано')
            key = result['key']
            self.binding(serial, account)
            if stop.is_set():
                state('stopped', 'Зупинено')
                return 'stopped'
            view = ui.view()
            if view['accepted']:
                state('already_unlocked', 'Доступ відкрився під час очікування; ключ не вставлявся')
                return 'already_unlocked'
            if not view['field']:
                raise KeyAttention('Поле ключа зникло; результат не вставляється в інші поля')
            state('inserting_key', 'Вставляю ключ у вихідну сесію…')
            ui.insert(view['field'], key)
            # Give automatic verification time before considering the Verify button.
            deadline = time.monotonic() + 30
            clicked = False
            inserted_at = time.monotonic()
            while time.monotonic() < deadline and not stop.is_set():
                self.binding(serial, account)
                view = ui.view()
                if view['accepted']:
                    state('accepted', 'Android UI підтверджує доступ')
                    self.panel.event(serial, 'key_accepted', 'Доступ підтверджено UI; акаунт ' + account['id'])
                    return 'accepted'
                if not clicked and time.monotonic() - inserted_at >= 3 and view['field'] and view['verify']:
                    ui.verify(view['verify'])
                    clicked = True
                    state('verifying_key', 'Кнопку перевірки натиснуто один раз; очікую підтвердження…')
                stop.wait(.5)
            if stop.is_set():
                state('stopped', 'Зупинено')
                return 'stopped'
            raise KeyAttention('Ключ вставлено, але доступ не підтверджено. Повторних натискань немає')
        except KeyAttention as error:
            state('needs_attention', str(error))
            return 'needs_attention'
        except Exception:
            # UI/RPC/browser exceptions may contain the URL or key: do not expose them.
            state('needs_attention', 'Не вдалося завершити етап ключа; перевірте прев’ю сесії')
            return 'needs_attention'
        finally:
            key = None
            if jobs:
                jobs.close()
