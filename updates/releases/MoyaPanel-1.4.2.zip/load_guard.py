"""Measured admission control; never kill existing emulator instances."""
import time


def can_add_instance(guest_gb, stop, seconds=15, sample=None):
    if sample is None:
        import psutil
        def sample():
            return psutil.cpu_percent(interval=None), psutil.virtual_memory().available / 1024**3
    sample()  # prime CPU sampling in this thread
    end = time.monotonic() + seconds
    readings = []
    while time.monotonic() < end:
        if stop.wait(1):
            return False
        cpu, free = sample()
        if free < guest_gb + 2:
            return False
        readings.append(cpu)
    return bool(readings) and sum(readings) / len(readings) < 75 and max(readings) < 90
