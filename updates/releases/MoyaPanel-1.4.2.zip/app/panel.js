'use strict';
const $=s=>document.querySelector(s);
let latest=null,settingsLoaded=false,updateHealthy=false;
const names={running:'Процес працює',stopped:'Процес зупинено',not_configured:'Пакет не задано',unknown:'Очікування перевірки',booting:'Android завантажується',offline:'Вимкнено / немає ADB',disabled:'Акаунт вимкнений',error:'Помилка перевірки',device:'ADB підключено',unauthorized:'Дозвольте ADB в емуляторі'};
const text=(tag,value,cls)=>{const e=document.createElement(tag);e.textContent=value;if(cls)e.className=cls;return e;};
function message(value){$('#notice').textContent=value;}
async function api(action,body){const r=await fetch('/api/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-Panel':'1'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.error||'Помилка запиту');return d;}
function button(label,fn,cls='secondary'){const b=text('button',label,cls);b.type='button';b.onclick=async()=>{b.disabled=true;try{await fn();}catch(e){message(e.message);}finally{b.disabled=false;}};return b;}
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>{for(const section of document.querySelectorAll('.tab'))section.classList.toggle('hidden',section.id!==b.dataset.tab);for(const nav of document.querySelectorAll('[data-tab]'))nav.classList.toggle('selected',nav===b);$('#heading').textContent=b.textContent.slice(2);};
function fill(form,data){for(const [k,v]of Object.entries(data)){const e=form.elements.namedItem(k);if(e){if(e.type==='checkbox')e.checked=Boolean(v);else e.value=v??'';}}}
function render(data){
 latest=data;
 if(data.updates){$('#update-status').textContent='Версія '+data.updates.version+' · '+data.updates.detail;$('#update-restart').disabled=data.updates.stage!=='pending'||!data.suspended||data.controlCenter?.stage!=='stopped';}
 renderControl(data);
 const emulators=data.emulators;if(emulators){const choice=$('#emulator-choice');const signature=JSON.stringify(emulators.installed.map(x=>x.id));if(choice.dataset.options!==signature){const previous=choice.value||emulators.selected;choice.replaceChildren(...emulators.installed.map(x=>{const o=text('option',x.name+' · '+x.path);o.value=x.id;return o;}));if(!emulators.installed.length){const o=text('option',emulators.workflow.stage==='discovering'?'Шукаю емулятори…':'Емулятор не знайдено');o.value='';choice.append(o);}if(emulators.installed.some(x=>x.id===previous))choice.value=previous;else if(emulators.installed.length>1){const o=text('option','Виберіть емулятор…');o.value='';choice.prepend(o);choice.value='';}choice.dataset.options=signature;}
 if(!emulators.installed.length&&choice.options.length)choice.options[0].textContent=emulators.workflow.stage==='discovering'?'Шукаю емулятори…':'Емулятор не знайдено';
 const workflow=emulators.workflow;const sessionBox=$('#session-key-status');sessionBox.replaceChildren(...Object.values(workflow.sessionKeys||{}).map(s=>{const row=text('article');const account=data.accounts.find(a=>a.id===s.accountId);row.append(text('strong',(account?.login||s.accountId)+' · '+s.serial),text('p',s.detail));if(s.url){const input=document.createElement('input');input.readOnly=true;input.value=s.url;input.setAttribute('aria-label','Посилання ключа цієї сесії');row.append(input);}return row;}));const selected=emulators.installed.find(x=>x.id===choice.value);const caps=selected?.capabilities;$('#emulator-capabilities').textContent=caps?(caps.nativeFields.length?'Адаптер: '+caps.nativeFields.join(', ')+' · '+caps.status:caps.status):'';$('#official-downloads').classList.toggle('hidden',emulators.installed.length>0||workflow.running||workflow.stage!=='not_found');if(!$('#official-sources').childElementCount){for(const source of emulators.officialSources||[]){$('#official-sources').append(button(source.name+' · '+source.domain,async()=>{await api('emulator_download',{id:source.id});message('Відкрито офіційний сайт '+source.domain+'. Після встановлення оновіть пошук емуляторів.');}));}}const profile=workflow.profile;$('#resource-plan').textContent=profile?'ПК: '+profile.cpuName+' / '+profile.physicalCPU+' фізичних ядер / '+profile.totalGB+' ГБ RAM / '+profile.gpuName+'. Профіль '+profile.tier+': '+profile.cores+' vCPU, '+profile.guestGB+' ГБ, '+profile.fps+' FPS (ціль), '+profile.resolution+'. Орієнтир: до '+profile.estimatedInstances+' інстансів (не перевірений максимум).':'';$('#tuning-report').textContent=(workflow.tuning||[]).join(' · ');$('#emulator-restore').disabled=workflow.running||!choice.value;$('#emulator-stage').textContent=workflow.detail||'Виберіть емулятор';$('#emulator-serials').textContent=workflow.serials.length?'Сесії: '+workflow.serials.join(', '):'';$('#emulator-start').disabled=Boolean(data.controlCenter?.running)||workflow.running||!choice.value;$('#emulator-scan').disabled=workflow.running;$('#emulator-stop').disabled=!workflow.running;$('#emulator-path').textContent=emulators.installed.find(x=>x.id===choice.value)?.path||'';}

 const job=data.keyJob;if(job){const stages={idle:'Очікування',running:'Працює',succeeded:'Ключ отримано',failed:'Не отримано ключ: дивіться журнал',stopped:'Зупинено',timeout:'Перевищено 10 хвилин'};$('#key-status').textContent=stages[job.stage]||job.stage;$('#key-result').value=job.key||'';$('#key-log').textContent=job.lines.join('\n');$('#key-start').disabled=data.suspended||job.running;$('#key-stop').disabled=!job.running;}
$('#connection').textContent='● Сервер підключено';$('#resource-pressure').textContent=data.resources?.message||'';$('#backend-error').textContent=data.error;
 $('#count').textContent=data.devices.filter(d=>d.state==='device').length+' активних ADB сесій';
 const cfg=data.configs.find(c=>c.id===data.active);$('#active-name').textContent=cfg?.name||'—';$('#active-package').textContent=cfg?.package||'Пакет не задано';$('#auto-state').textContent=data.suspended?'Призупинено':(data.settings.auto?'Увімкнено':'Вимкнено');
 if(!settingsLoaded){fill($('#settings-form'),{...data.settings,ports:data.settings.ports.join(', ')});settingsLoaded=true;}
 const container=$('#screens');const existing=new Map([...container.querySelectorAll('.screen')].map(e=>[e.dataset.serial,e]));
 container.querySelector('.empty')?.remove();
 if(!data.devices.length){container.replaceChildren(text('div','Немає локальних ADB-сесій. Виберіть емулятор вище й натисніть «Запустити та оптимізувати». Для підключення ADB має бути дозволено в самому емуляторі.','empty'));}
 for(const d of data.devices){let card=existing.get(d.serial);if(!card){card=text('article','','screen');card.dataset.serial=d.serial;const head=text('div','','screen-head');head.append(text('strong',d.serial),text('small','','device-state'));const img=document.createElement('img');img.alt='Прев’ю Android';img.hidden=true;const info=text('div','','screen-info');info.append(text('p','','process'),text('p','','error'),text('p','','frame-time'),button('Запустити додаток',async()=>{await api('launch',{serial:d.serial});message('Запуск поставлено в чергу. Результат з’явиться в історії.');}));card.append(head,img,info);container.append(card);}
 existing.delete(d.serial);card.querySelector('.device-state').textContent=names[d.state]||d.state;card.querySelector('.process').textContent=(names[d.process]||d.process)+' · Вхід не перевірено';card.querySelector('.error').textContent=d.error;card.querySelector('button').disabled=d.state!=='device'||!cfg?.package;
 card.querySelector('.frame-time').textContent=d.frameAt?'Кадр: '+new Date(d.frameAt).toLocaleTimeString():'Очікування кадру';
 const img=card.querySelector('img');if(d.frameAt&&img.dataset.frame!==String(d.frameAt)&&!img.dataset.loading){img.dataset.loading='1';const preload=new Image();preload.onload=()=>{img.src=preload.src;img.hidden=false;img.dataset.frame=String(d.frameAt);delete img.dataset.loading;};preload.onerror=()=>{delete img.dataset.loading;};preload.src='/api/frame?serial='+encodeURIComponent(d.serial)+'&v='+d.frameAt;}
 }
 for(const card of existing.values())card.remove();
 $('#serials').replaceChildren(...data.devices.map(d=>{const o=document.createElement('option');o.value=d.serial;return o;}));
 $('#account-list').replaceChildren(...data.accounts.map(a=>{const card=text('article');const row=text('div','','row');const body=text('div');body.append(text('h2',a.login),text('p',a.serial+' · '+(names[a.status]||a.status)+' · Режим: '+(a.placeId||'не заданий')),text('p','Вхід: не перевірено · Пароль: '+(a.hasPassword?'збережений':'не задано')));const actions=text('div','','buttons');actions.append(button('Редагувати',()=>{fill($('#account-form'),{...a,password:''});$('#account-form').scrollIntoView({behavior:'smooth'});}),button('Видалити',async()=>{await api('delete_account',{id:a.id});message('Акаунт видалено');}));row.append(body,actions);card.append(row);return card;}));
 $('#config-list').replaceChildren(...data.configs.map(c=>{const card=text('article','','row');card.append(text('strong',c.name+(c.id===data.active?' · АКТИВНИЙ':'')),text('code',c.package||'Пакет не задано'));const actions=text('div','','buttons');actions.append(button('Редагувати',()=>fill($('#config-form'),{luaScript:'',executorAutoInject:false,...c})),button('Активувати',async()=>{await api('activate',{id:c.id});message('Конфіг активовано');}));card.append(actions);return card;}));
 $('#history').replaceChildren(...data.history.map(h=>text('div',new Date(h.time).toLocaleString()+' · '+h.serial+' · '+h.stage+' · '+h.detail,'history-row')));if(!data.history.length)$('#history').append(text('p','Процесів ще не було.'));
}
function formHandler(selector,action,convert){const f=$(selector);f.onsubmit=async e=>{e.preventDefault();const b=f.querySelector('[type="submit"]')||f.querySelector('button');b.disabled=true;try{await api(action,convert(f));if(action==='account')f.elements.password.value='';message('Збережено');}catch(err){message(err.message);}finally{b.disabled=false;}};}
formHandler('#settings-form','settings',f=>({adb:f.elements.adb.value.trim(),ports:f.elements.ports.value.split(',').map(x=>x.trim()).filter(Boolean).map(x=>/^\d+$/.test(x)?Number(x):null),auto:f.elements.auto.checked}));
formHandler('#account-form','account',f=>({id:f.elements.id.value||undefined,login:f.elements.login.value,password:f.elements.password.value,serial:f.elements.serial.value,placeId:f.elements.placeId.value,enabled:f.elements.enabled.checked}));
formHandler('#config-form','config',f=>({id:f.elements.id.value||undefined,name:f.elements.name.value,package:f.elements.package.value,restart:f.elements.restart.checked,luaScript:f.elements.luaScript.value,executorAutoInject:f.elements.executorAutoInject.checked}));
async function poll(){try{const r=await fetch('/api/status');if(!r.ok)throw Error('HTTP '+r.status);render(await r.json());if(!updateHealthy){try{updateHealthy=(await api('update_healthy',{})).ok;}catch{}}}catch(e){$('#connection').textContent='● Сервер недоступний';$('#backend-error').textContent='Немає актуальних даних. Перевірте вікно start.bat. '+e.message;}finally{setTimeout(poll,2000);}}
poll();

formHandler('#key-form','key_start',f=>({url:f.elements.url.value,mode:f.elements.mode.value,showBrowser:f.elements.showBrowser.checked,closePopups:f.elements.closePopups.checked}));
$('#key-stop').onclick=async()=>{try{await api('key_stop',{});message('Зупинка процесу');}catch(e){message(e.message);}};
$('#key-copy').onclick=async()=>{try{const value=$('#key-result').value;if(!value)throw Error('Немає результату');await navigator.clipboard.writeText(value);message('Ключ скопійовано');}catch(e){message(e.message);}};

formHandler('#emulator-form','emulator_start',f=>({id:f.elements.id.value,package:f.elements.package.value,setupDelta:f.elements.setupDelta.checked,autoKeys:f.elements.setupDelta.checked&&f.elements.autoKeys.checked,runScript:f.elements.setupDelta.checked&&f.elements.autoKeys.checked&&f.elements.runScript.checked}));
$('#emulator-scan').onclick=async()=>{try{await api('emulator_scan',{});message('Пошук емуляторів запущено');}catch(e){message(e.message);}};
$('#emulator-stop').onclick=async()=>{try{await api('emulator_stop',{});message('Сценарій зупиняється');}catch(e){message(e.message);}};
$('#emulator-choice').onchange=()=>{$('#emulator-start').disabled=Boolean(latest?.controlCenter?.running)||!$('#emulator-choice').value||Boolean(latest?.emulators?.workflow.running);};

$('#emulator-restore').onclick=async()=>{try{await api('emulator_restore',{id:$('#emulator-choice').value});message('Відновлення налаштувань запущено');}catch(e){message(e.message);}};

function chooseControlAccount(){
 if(!latest)return;
 const form=$('#control-form');const a=latest.accounts.find(a=>a.id===form.elements.id.value);
 if(!a)return;
 const c=latest.configs.find(c=>c.id===(a.configId||latest.active));
 fill(form,{id:a.id,placeId:a.placeId||'',luaScript:c?.luaScript||'',executorAutoInject:Boolean(c?.executorAutoInject)});
}
function renderControl(data){
 const center=data.controlCenter;if(!center)return;
 const flow=data.emulators?.workflow;const busy=Boolean(flow?.running||center.running);
 $('#center-status').textContent=center.detail;
 const recovery=data.recovery;if(recovery){$('#recovery-enabled').checked=recovery.enabled;$('#recovery-status').textContent='Автовідновлення: '+(data.suspended?'призупинено повною зупинкою':recovery.enabled?'увімкнено':'вимкнено')+' · '+recovery.sessions.map(s=>(data.accounts.find(a=>a.id===s.accountId)?.login||s.serial)+': '+s.detail+' (спроб '+s.attempts+')').join(' · ');}
 $('#resume-all').disabled=busy||!center.canResume;
 $('#stop-all').disabled=center.running;
 const managed=data.emulators?.managed;
 $('#center-owned').textContent='Інстанси панелі: '+(managed?.native.map(x=>x.emulator+' #'+x.index).join(', ')||'немає')+' · Керованих процесів: '+(managed?.processCount||0)+'. Процес гри ≠ підтверджене виконання Lua.';
 const select=$('#control-account-choice');const signature=JSON.stringify(data.accounts.map(a=>[a.id,a.login]));
 if(select.dataset.options!==signature){const old=select.value;select.replaceChildren(...data.accounts.map(a=>{const o=text('option',a.login);o.value=a.id;return o;}));if(data.accounts.some(a=>a.id===old))select.value=old;select.dataset.options=signature;chooseControlAccount();}
 for(const b of $('#control-form').querySelectorAll('button'))b.disabled=busy||!data.accounts.length||(b.value!=='save'&&data.suspended);
 const box=$('#control-accounts');const existing=new Map([...box.children].map(n=>[n.dataset.id,n]));
 for(const a of data.accounts){let card=existing.get(a.id);if(!card){card=text('article');card.dataset.id=a.id;card.append(text('h2','','control-name'),text('p','','control-process'),text('p','','control-state'));const img=document.createElement('img');img.className='control-preview';img.alt='Прев’ю сесії акаунта';img.hidden=true;card.append(img,text('p','','control-game'),button('Керувати цим акаунтом',()=>{select.value=a.id;chooseControlAccount();$('#control-form').scrollIntoView({behavior:'smooth'});}));box.append(card);}existing.delete(a.id);
 const d=data.devices.find(d=>d.serial===a.serial);const phase=flow?.sessionKeys?.[a.serial];
 card.querySelector('.control-name').textContent=a.login;
 card.querySelector('.control-process').textContent=(names[a.status]||a.status)+' · '+(a.serial||'інстанс ще не призначено')+(d?.checked?' · '+new Date(d.checked).toLocaleTimeString():'');
 card.querySelector('.control-state').textContent=data.suspended?'Роботу припинено':(phase?.detail||'Очікую етапи сценарію');
 card.querySelector('.control-game').textContent='Режим: '+(a.placeId||'не задано')+(d?.error?' · '+d.error:'');
 const img=card.querySelector('img');if(d?.frameAt&&img.dataset.frame!==String(d.frameAt)){img.src='/api/frame?serial='+encodeURIComponent(a.serial)+'&v='+d.frameAt;img.dataset.frame=String(d.frameAt);img.hidden=false;}if(!d?.frameAt)img.hidden=true;
 }for(const card of existing.values())card.remove();
}
$('#control-account-choice').onchange=chooseControlAccount;
$('#control-form').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget;const operation=e.submitter?.value||'save';const body={id:form.elements.id.value,operation,placeId:form.elements.placeId.value,luaScript:form.elements.luaScript.value,executorAutoInject:form.elements.executorAutoInject.checked};try{const r=await api('center_action',body);message(r.saved?'Налаштування акаунта збережені':'Дію поставлено в чергу; статус у Центрі керування');}catch(err){message(err.message);}};
$('#stop-all').onclick=async()=>{try{await api('stop_all',{});message('Повна зупинка розпочата; очікуйте підтвердження у Центрі керування');}catch(err){message(err.message);}};
$('#resume-all').onclick=async()=>{try{const r=await api('resume_all',{});message(r.selectionRequired?'Пауза знята. Виберіть емулятор у Моніторингу':'Відновлення збереженого сценарію розпочате');}catch(err){message(err.message);}};

$('#recovery-enabled').onchange=async e=>{try{await api('recovery_set',{enabled:e.target.checked});message('Налаштування автовідновлення збережено');}catch(err){message(err.message);}};

formHandler('#emulator-path-form','emulator_path',f=>({path:f.elements.path.value}));

$('#update-restart').onclick=async()=>{try{await api('update_restart',{});}catch(err){message(err.message);}};
