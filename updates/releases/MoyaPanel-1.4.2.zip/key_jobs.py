"""Run the existing Playwright module as a cancellable background process."""
import json
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit


class KeyJobs:
    def __init__(self, directory, script=None):
        self.directory = Path(directory)
        self.script = Path(script) if script else self.directory / 'key_system.py'
        self.lock = threading.RLock()
        self.proc = None
        self.reader_thread = None
        self.timer = None
        self.state = {'running': False, 'stage': 'idle', 'key': None, 'lines': [], 'exitCode': None}

    def snapshot(self):
        with self.lock:
            return dict(self.state, lines=list(self.state['lines']))

    def line(self, value):
        with self.lock:
            self.state['lines'].append(value[:1500])
            del self.state['lines'][:-150]

    def start(self, body):
        url = str(body.get('url', '')).strip()
        parsed = urlsplit(url)
        if parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or len(url) > 4096:
            raise ValueError('Потрібне коректне HTTP/HTTPS посилання без логіна в URL')
        mode = body.get('mode', 'full')
        if mode not in {'full', 'key'}:
            raise ValueError('Режим: full або key')
        args = {'url': url, 'mode': mode, 'showBrowser': bool(body.get('showBrowser', True)),
                'copyKey': False, 'saveKey': bool(body.get('saveKey', True)), 'closePopups': bool(body.get('closePopups', True)),
                'continueWait': 20, 'claimWait': 180, 'keyWait': 30, 'finalWait': 0}
        executable = Path(sys.executable)
        if executable.name.lower() == 'pythonw.exe':
            executable = executable.with_name('python.exe')
        with self.lock:
            if self.proc is not None:
                raise ValueError('Процес отримання ключа вже працює')
            proc = subprocess.Popen([str(executable), '-u', str(self.script), json.dumps(args)],
                                    cwd=str(self.directory), stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    encoding='utf-8', errors='replace',
                                    env=dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8'),
                                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                                    start_new_session=os.name != 'nt')
            self.proc = proc
            self.state = {'running': True, 'stage': 'running', 'key': None, 'lines': [],
                          'exitCode': None, 'started': int(time.time()*1000)}
            self.reader_thread = threading.Thread(target=self.read, args=(proc,), daemon=True)
            self.timer = threading.Timer(600, lambda: self.stop(proc, 'timeout'))
            self.timer.daemon = True
            self.timer.start()
            self.reader_thread.start()
        return {'ok': True}

    def read(self, proc):
        try:
            for raw in proc.stdout:
                line = raw.rstrip('\r\n')
                if line.startswith('[KEY] '):
                    try:
                        key = json.loads(line[6:])
                        if not isinstance(key, str) or not key.strip() or len(key) > 16384:
                            raise ValueError('Invalid key payload')
                        with self.lock:
                            self.state['key'] = key
                        self.line('[+] Результат отримано')
                    except ValueError:
                        self.line('[-] Некоректний формат [KEY]')
                elif line.startswith('[УСПІХ]'):
                    continue  # Module prints the secret here as well; keep it out of the log.
                else:
                    self.line(line)
            code = proc.wait()
            with self.lock:
                if self.proc is proc:
                    self.state['running'] = False
                    self.state['exitCode'] = code
                    if self.state['stage'] not in {'stopped', 'timeout'}:
                        self.state['stage'] = 'succeeded' if code == 0 and self.state['key'] else 'failed'
                    self.proc = None
                    if self.timer:
                        self.timer.cancel()
        finally:
            proc.stdout.close()

    def stop(self, expected=None, reason='stopped'):
        # Serialize against a new start; this process and its browser descendants belong to us.
        with self.lock:
            proc = self.proc
            if proc is None or (expected is not None and proc is not expected):
                return {'ok': True}
            self.state['stage'] = reason
            if proc.poll() is None:
                try:
                    if os.name == 'nt':
                        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'],
                                       capture_output=True, timeout=10,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                    else:
                        os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=10)
        return {'ok': True}

    def close(self):
        self.stop()
        if self.reader_thread:
            self.reader_thread.join(timeout=12)
