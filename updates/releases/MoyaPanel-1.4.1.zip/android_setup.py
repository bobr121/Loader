"""Delta delivery and per-device game preparation. Never infer login from a PID."""
import hashlib
import json
import re
import time
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urlsplit

SOURCE = 'https://deltaexploits.gg/delta-executor-android'
PACKAGE = 'com.roblox.client'


def place_id(value):
    value = str(value or '').strip()
    if not value:
        return ''
    if value.isdecimal() and value.isascii() and 0 < int(value) < 2**63:
        return str(int(value))
    parsed = urlsplit(value)
    match = re.fullmatch(r'/games/([0-9]+)(?:/[^/?#]*)?/?', parsed.path)
    if parsed.scheme == 'https' and parsed.hostname in {'roblox.com', 'www.roblox.com'} and match:
        return place_id(match[1])
    raise ValueError('Режим: числовий Place ID або https://www.roblox.com/games/ID/назва')


def validate_apk(path):
    path = Path(path)
    if not 1024 <= path.stat().st_size <= 1024**3:
        raise RuntimeError('Некоректний розмір APK (ліміт 1 ГБ)')
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        if 'AndroidManifest.xml' not in names or 'classes.dex' not in names:
            raise RuntimeError('Завантажений файл не схожий на Android APK')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def cached_delta(directory):
    target = Path(directory) / 'downloads' / 'delta.apk'
    try:
        if target.exists() and time.time() - target.stat().st_mtime < 86400 and validate_apk(target) == target.with_suffix('.sha256').read_text().strip():
            return target
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile):
        pass
    return None


def _download_delta_direct(directory, stop, stage):
    target = Path(directory) / 'downloads' / 'delta.apk'
    target.parent.mkdir(parents=True, exist_ok=True)
    cached=cached_delta(directory)
    if cached:
        return cached
    from playwright.sync_api import sync_playwright
    temporary = target.with_suffix('.part')
    stage('downloading_apk', 'Завантажую Delta з кнопки на сайті розробника; очікую до 3 хвилин…')
    try:
        with sync_playwright() as pw:
            try:
                browser = pw.chromium.launch(headless=True)
            except Exception as error:
                if "Executable doesn't exist" not in str(error):
                    raise
                import subprocess
                import sys
                stage('browser_setup','Автоматично встановлюю відсутній Chromium…')
                subprocess.run([sys.executable,'-m','playwright','install','chromium'],
                               check=True,timeout=180,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                               creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                browser = pw.chromium.launch(headless=True)
            try:
                context = browser.new_context(accept_downloads=True)
                downloads = []
                context.on('page', lambda page: page.on('download', downloads.append))
                page = context.new_page()
                page.goto(SOURCE, timeout=45000, wait_until='domcontentloaded')
                label=page.get_by_text('Download for Android',exact=True)
                label.first.wait_for(state='visible',timeout=15000)
                button=page.get_by_role('button', name='Download for Android', exact=True)
                if button.count()!=1:
                    button=label
                if button.count()!=1:
                    raise RuntimeError('Не знайдено однозначну кнопку Download for Android на сторінці розробника')
                button.click(timeout=15000)
                deadline = time.monotonic() + 180
                while not downloads and time.monotonic() < deadline:
                    if stop.is_set():
                        raise RuntimeError('Завантаження скасовано')
                    page.wait_for_timeout(250)
                if not downloads:
                    raise RuntimeError('Сайт не віддав APK: можлива зміна кнопки або перевірка браузера. Дзеркала не використовувалися.')
                download = downloads[0]
                url = urlsplit(download.url)
                if url.scheme != 'https' or url.hostname != 'delta.filenetwork.vip' or not re.fullmatch(r'/file/Delta-[0-9.]+\.apk', url.path):
                    download.cancel()
                    raise RuntimeError('Адреса доставки змінилася. Автоматичне встановлення зупинено для перевірки джерела.')
                download.save_as(str(temporary))
                if stop.is_set():
                    raise RuntimeError('Завантаження скасовано')
                digest = validate_apk(temporary)
                temporary.replace(target)
                target.with_suffix('.sha256').write_text(digest + '\n', encoding='ascii')
                # A local digest identifies bytes; it is NOT publisher/signature verification.
                return target
            finally:
                browser.close()
    finally:
        temporary.unlink(missing_ok=True)


def install_delta(panel, serial, apk, stage):
    from androguard.core.apk import APK
    if APK(str(apk)).get_package() != PACKAGE:
        raise RuntimeError('APK має неочікуваний Android package; встановлення скасовано')
    stage('installing_apk', 'Встановлюю APK у ' + serial + '…')
    result = panel.adb('install', '-r', str(apk), serial=serial, timeout=240)
    if b'Success' not in result:
        raise RuntimeError('Android не підтвердив встановлення APK. Попередній додаток не видалявся.')
    if b'package:' not in panel.adb('shell', 'pm', 'path', PACKAGE, serial=serial):
        raise RuntimeError('Очікуваний Android package не знайдений після встановлення')
    dump = panel.adb('shell', 'dumpsys', 'package', PACKAGE, serial=serial).decode('utf-8', 'replace')
    # Special access only if the installed manifest actually requests it.
    requested = dump.split('requested permissions:', 1)
    requested = requested[1].split('install permissions:', 1)[0] if len(requested) == 2 else ''
    if 'android.permission.MANAGE_EXTERNAL_STORAGE' in requested:
        panel.adb('shell', 'appops', 'set', PACKAGE, 'MANAGE_EXTERNAL_STORAGE', 'allow', serial=serial)
        check = panel.adb('shell', 'appops', 'get', PACKAGE, 'MANAGE_EXTERNAL_STORAGE', serial=serial)
        if b'allow' not in check:
            raise RuntimeError('Android не підтвердив доступ до файлів')
    panel.event(serial, 'apk_installed', 'Delta; локальний SHA-256 записаний у downloads/delta.sha256')


def prepare_account(panel, serial, account, stop, stage, timeout=600):
    """Use semantic Android selectors. Unknown UI waits instead of guessing taps.

    Never send credentials through adb shell/input (process arguments). uiautomator2
    sends text over its local device RPC. A visible exact username is required before
    a game link is sent. CAPTCHA/2FA is left for the account owner.
    """
    import uiautomator2 as u2
    import adbutils
    adb = adbutils.AdbClient(host='127.0.0.1', port=5037).device(serial=serial)
    device = u2.connect(adb)
    deadline = time.monotonic() + timeout
    submitted = False
    opened_login = False
    while time.monotonic() < deadline and not stop.is_set():
        current = device.app_current()
        if current.get('package') != PACKAGE:
            stage('waiting_login', serial + ': очікую вікно гри; перевірте відкриті системні запити')
        else:
            root = ET.fromstring(device.dump_hierarchy())
            edits = [n.attrib for n in root.iter('node') if n.get('package') == PACKAGE
                     and n.get('class') == 'android.widget.EditText']
            passwords = [n for n in edits if n.get('password') == 'true']
            users = [n for n in edits if n.get('password') != 'true' and
                     (re.fullmatch(r'(?i)(username|username/email/phone|email/phone/username|логін|имя пользователя)',
                                   n.get('text') or n.get('hint') or n.get('content-desc') or '')
                      or re.search(r'(?i)(username|user_name)$', n.get('resource-id', '')))]
            password_field = device(packageName=PACKAGE, resourceId=passwords[0]['resource-id']) if len(passwords) == 1 and passwords[0].get('resource-id') else None
            fields = device(packageName=PACKAGE, resourceId=users[0]['resource-id']) if len(users) == 1 and users[0].get('resource-id') else None
            submit = device(packageName=PACKAGE, textMatches='(?i)(log in|login|увійти|войти)', clickable=True)
            if not submitted and not edits and not opened_login and submit.count == 1 and not device(packageName=PACKAGE,text=account['login']).exists:
                submit.click()
                opened_login = True
                stop.wait(1)
                continue
            if not submitted and password_field is not None and fields is not None and password_field.count == 1 and fields.count == 1 and submit.count == 1:
                password = panel.vault().get_password('MoyaPanel', account['id'])
                if not password:
                    raise RuntimeError('Для акаунта не збережено пароль у Windows Credential Manager')
                try:
                    fields.set_text(account['login'])
                    password_field.set_text(password)
                    submit.click()
                finally:
                    password = None
                submitted = True
            if not passwords and device(packageName=PACKAGE, text=account['login']).exists:
                game = place_id(account.get('placeId'))
                if game:
                    panel.adb('shell', 'am', 'start', '-W', '-a', 'android.intent.action.VIEW', '-d', 'roblox://placeId=' + game, '-p', PACKAGE, serial=serial, timeout=40)
                    panel.event(serial, 'game_link_sent', 'Place ID ' + game + '; завантаження режиму ще не підтверджено')
                return 'account_visible'
            stage('waiting_login', serial + ': очікую акаунт ' + account['login'] + '. Невідома форма, CAPTCHA або 2FA потребує перевірки у прев’ю.')
        stop.wait(1)
    if stop.is_set():
        return 'cancelled'
    raise RuntimeError(serial + ': за 10 хвилин не підтверджено акаунт. Перевірте форму входу у прев’ю; пароль не надсилався в невідомі поля.')


def download_delta(directory, stop, stage):
    import os
    import signal
    import subprocess
    import sys
    cached=cached_delta(directory)
    if cached:
        stage('apk_cached','Використовую перевірений кеш APK; повторне завантаження не потрібне')
        return cached
    executable=Path(sys.executable)
    if executable.name.lower()=='pythonw.exe': executable=executable.with_name('python.exe')
    status_file=Path(directory)/'downloads/delta-download-status.json'
    status_file.unlink(missing_ok=True)
    stage('downloading_apk','Перевіряю кеш/завантажую APK; браузер належить цьому завданню…')
    process=subprocess.Popen([str(executable),str(Path(__file__).resolve()),'--download',str(Path(directory).resolve())],
                             stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                             creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),start_new_session=os.name!='nt')
    deadline=time.monotonic()+360
    last_stage=None
    try:
        while process.poll() is None:
            try:
                progress=json.loads(status_file.read_text(encoding='utf-8')).get('stage')
                if progress!=last_stage and progress=='browser_setup':
                    stage('browser_setup','Автоматично встановлюю відсутній Chromium. Це одноразова підготовка…')
                last_stage=progress
            except (OSError,ValueError):
                pass
            if stop.wait(.25) or time.monotonic()>deadline:
                raise RuntimeError('Завантаження APK зупинено або перевищено час очікування')
        if stop.is_set(): raise RuntimeError('Завантаження скасовано')
        if process.returncode:
            try:
                code=json.loads(status_file.read_text(encoding='utf-8')).get('code','unknown')
            except (OSError,ValueError):
                code='worker_start'
            raise RuntimeError('APK не отримано: '+DOWNLOAD_ERRORS.get(code,DOWNLOAD_ERRORS['unknown']))
        target=Path(directory)/'downloads/delta.apk'
        validate_apk(target)
        return target
    finally:
        if process.poll() is None:
            if os.name=='nt':
                subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=15,
                               creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            else:
                try: os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError: pass
            process.wait(timeout=15)
        (Path(directory)/'downloads/delta.part').unlink(missing_ok=True)


DOWNLOAD_ERRORS={
    'timeout':'перевищено час завантаження сторінки, кнопки або APK',
    'dependency':'не встановлено залежність Playwright; повторно запустіть Install.bat',
    'browser':'Chromium не вдалося запустити або автоматично встановити',
    'button':'сторінка не показала однозначну кнопку Download for Android',
    'delivery':'адреса доставки APK змінилася; сторонній файл не встановлювався',
    'no_download':'сайт не віддав APK після натискання кнопки',
    'worker_start':'процес завантаження не зміг запуститися або завершився аварійно',
    'unknown':'помилка завантаження або перевірки APK; див. downloads/delta-download-status.json'}


def download_error_code(error):
    text=str(error)
    if isinstance(error,ModuleNotFoundError):return 'dependency'
    if 'Timeout' in type(error).__name__ or 'timed out' in text:return 'timeout'
    if 'Chromium' in text or 'Executable' in text or 'BrowserType.launch' in text:return 'browser'
    if 'кнопку Download' in text:return 'button'
    if 'Адреса доставки' in text:return 'delivery'
    if 'Сайт не віддав' in text:return 'no_download'
    return 'unknown'


if __name__=='__main__':
    import sys
    import threading
    if len(sys.argv)==3 and sys.argv[1]=='--download':
        folder=Path(sys.argv[2])/'downloads';folder.mkdir(parents=True,exist_ok=True)
        def progress(stage,detail):
            (folder/'delta-download-status.json').write_text(json.dumps({'stage':stage},ensure_ascii=False),encoding='utf-8')
        try:
            _download_delta_direct(sys.argv[2],threading.Event(),progress)
        except Exception as error:
            # Never persist URLs, headers, browser storage or raw exception text.
            (folder/'delta-download-status.json').write_text(json.dumps({'code':download_error_code(error)},ensure_ascii=False),encoding='utf-8')
            raise SystemExit(1)
    else:
        raise SystemExit(2)
